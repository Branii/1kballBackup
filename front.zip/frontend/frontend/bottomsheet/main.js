const sheet = document.querySelector("#sheet");
const openSheetButton = document.querySelector("#open-sheet");
const closeSheetButton = document.querySelector(".close-sheet");
const overlay = document.querySelector(".overlay");
const draggableArea = document.querySelector(".draggable-area");
const sheetContents = document.querySelector(".contents");
const windowHeight = window.innerHeight;
let sheetHeight;

// Helper function to set sheet height and toggle fullscreen mode
const setSheetHeight = (value) => {
  sheetHeight = Math.max(0, Math.min(100, value));
  sheetContents.style.height = `${sheetHeight}vh`;

  sheetHeight === 100
    ? sheetContents.classList.add("fullscreen")
    : sheetContents.classList.remove("fullscreen");
};

// Helper function to toggle sheet visibility
const setIsSheetShown = (isShown) => {
  sheet.setAttribute("aria-hidden", String(!isShown));
};

// Open sheet button click event handler
openSheetButton.addEventListener("click", () => {
  setSheetHeight(Math.min(50, 720 / windowHeight * 100));
  setIsSheetShown(true);
});

// Close sheet button click event handler
closeSheetButton.addEventListener("click", () => {
  setIsSheetShown(false);
});

// Click outside of sheet event handler
overlay.addEventListener("click", () => {
  setIsSheetShown(false);
});

// Escape key up event handler to hide sheet when the target is not an input field
window.addEventListener("keyup", (event) => {
  const isSheetElementFocused = sheet.contains(event.target) && document.activeElement === event.target;

  if (event.key === "Escape" && !isSheetElementFocused) {
    setIsSheetShown(false);
  }
});

// Draggable area event handlers for sheet resizing
let dragPosition;

const onDragStart = (event) => {
  dragPosition = event.touches ? event.touches[0].pageY : event.pageY;
  sheetContents.classList.add("not-selectable");
  draggableArea.style.cursor = document.body.style.cursor = "grabbing";
};

const onDragMove = (event) => {
  if (dragPosition === undefined) return;

  const y = event.touches ? event.touches[0].pageY : event.pageY;
  const deltaY = dragPosition - y;
  const deltaHeight = deltaY / windowHeight * 100;

  setSheetHeight(sheetHeight + deltaHeight);
  dragPosition = y;
};

const onDragEnd = () => {
  dragPosition = undefined;
  sheetContents.classList.remove("not-selectable");
  draggableArea.style.cursor = document.body.style.cursor = "";

  if (sheetHeight < 25) {
    setIsSheetShown(false);
  } else if (sheetHeight > 75) {
    setSheetHeight(100);
  } else {
    setSheetHeight(50);
  }
};

draggableArea.addEventListener("mousedown", onDragStart);
draggableArea.addEventListener("touchstart", onDragStart);
window.addEventListener("mousemove", onDragMove);
window.addEventListener("touchmove", onDragMove);
window.addEventListener("mouseup", onDragEnd);
window.addEventListener("touchend", onDragEnd);
