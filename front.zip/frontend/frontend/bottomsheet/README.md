# Bottom Sheet
Bottom sheet, implemented in pure HTML, CSS, and JavaScript

## Features
- There is a draggable area to resize the sheet
- The sheet can be closed using a button in the top right corner or using the `Esc` key
