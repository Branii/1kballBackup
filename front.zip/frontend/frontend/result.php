<!DOCTYPE html>
<html lang="en" oncontextmenu="return false">
<head>
<?php include "header.php";?>
<style>
  .number {
        display: inline-block;
        width: 30px; /* Set the width and height of each number */
        height: 30px;
        text-align: center;
        color:white;
        margin:1px;
        line-height: 30px;
        font-size: 12px;
        background-size: cover;
        background-repeat: no-repeat;
        background-image: url('green.png');
        }

        .dataTables_wrapper .dt-buttons {


</style>
</head>
<body data-spy="scroll" data-target="#navbar" class="static-layout">
	<div id="side-nav" class="sidenav">
	<a href="javascript:void(0)" id="side-nav-close">&times;</a>
	
	<div class="sidenav-content">
		<p>
			
		</p>
		<p>
			<span class="fs-16 primary-color"></span>
		</p>
		<p></p>
	</div>
</div>	
<div id="side-search" class="sidenav">
	<a href="javascript:void(0)" id="side-search-close">&times;</a>
	<div class="sidenav-content">
		<form action="">

			<div class="input-group md-form form-sm form-2 pl-0">
			  <input class="form-control my-0 py-1 red-border" type="text" placeholder="Search" aria-label="Search">
			  <div class="input-group-append">
			    <button class="input-group-text red lighten-3" id="basic-text1">
			    	<span class="lnr lnr-magnifier"></span>
			    </button>
			  </div>
			</div>

		</form>
	</div>
	
</div>	

<!-- Navigation -->
<nav class="navbar navbar-expand-lg static-top" style="background-color: #58197D !important;">
  <div class="container"  style="background-color: transparent !important;">
    <a class="navbar-brand" href="home.html">
      <img src="img/logo.jpg" width="130px" height="40px" style="box-shadow:rgba(0,0,0,0,.16) 0px 1px 4px;border-radius: 8px;border:solid 5px #fff">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link text-white" aria-current="page" href="home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " aria-current="page" href="product">Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " aria-current="page" href="#" style="border-bottom:solid 2px #fff;">Results</a>
        </li>
        <li class="nav-item">
          <a class="nav-link activee" aria-current="page" href="api">Game API</a>
        </li>
        
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron jumbotron-single d-flex align-items-center" style="background-image: url('images/result.jpg');">
  <div class="container text-center">

   <center>

    <div>

        <thead class="" style="border:none">
            <tr style="border:none;">
              <div class="d-flex justify-content-start" scope="col" colspan="4">
                <div><i class='bx bx-info-circle' style='color:#e8741f;font-size: 20px;margin-right: 3px;position: relative;top: 1px;' ></i></div>
                <tr><H6>Title: <span class="title"></span><span class="holder" hidden>1KBALL 5D</span> <span class="currIdd" hidden>10018</span> 
                  <button id="stream" class="hvr-grow" style="display:none;background-color:transparent;width:50px;height:25px;border-radius:20px;border:solid 1px #fff;border-width: thin;cursor: pointer;"> 
                    <i class='bx bx-video hvr-grow' style='font-size:22px;margin-right:-1px;color:#fff'></i> <span style="position:relative;bottom:3px;color:#fff"></span></button></H6></tr>
              </div>
            </tr>
          </thead>
        
          <thead class="" style="border:none">
            <tr style="border:none;">
              <div class="d-flex justify-content-start" scope="col" colspan="4" style="">
                <p style="padding:10px;text-align: left;"  class="details">
                  <!---new info will show here--->
               </p>
              </div>
            </tr>
          </thead>

    </div>

      <div class="row d-flex justify-content-center">
            <div class="col-md-2" style="top:43px;padding:0px;margin:0px;width:200px;height:455px;border:solid 1px #fff;border-top-left-radius: 10px;border-bottom-left-radius: 10px;border-top-right-radius: 10px;border-bottom-right-radius: 10px;">

                
                <div style="border-bottom:solid 1px #fff;height:42px;background-color:#38257E;width:193px;border-top-left-radius: 10px;border-top-right-radius: 10px;">
                    <span style="line-height:50px;"><b>Game Draws</b></span>
                </div>

                <!-- <div class="navigation">
                    <ul>
                     
                      <li class="has-sub hvr-groww"> <a href="#">GAME ONE TWO</a>
                        <ul>
                          <li><a href="#" class="sub">Submenu 2.1</a></li>
                          <li><a href="#" class="sub">Submenu 2.2</a></li>
                        </ul>
                      </li>

                      <li class="has-sub hvr-groww"> <a href="#">GAME ONE TWO</a>
                        <ul>
                          <li><a href="#" class="sub">Submenu 3.1</a></li>
                          <li><a href="#" class="sub">Submenu 3.2</a></li>
                        </ul>
                      </li>

                      <li class="has-sub hvr-groww"> <a href="#">GAME ONE TWO</a>
                        <ul>
                          <li><a href="#" class="sub">Submenu 3.1</a></li>
                          <li><a href="#" class="sub">Submenu 3.2</a></li>
                        </ul>
                      </li>

                      <li class="has-sub hvr-groww"> <a href="#">GAME ONE TWO</a>
                        <ul>
                          <li><a href="#" class="sub">Submenu 3.1</a></li>
                          <li><a href="#" class="sub">Submenu 3.2</a></li>
                        </ul>
                      </li>

                      <li class="has-sub hvr-groww"> <a href="#">GAME ONE TWO</a>
                        <ul>
                          <li><a href="#">Submenu 3.1</a></li>
                          <li><a href="#">Submenu 3.2</a></li>
                        </ul>
                      </li>



                    </ul>
                  </div> -->

              
               
                 <div class=" pure-menu custom-display">
                    <ul class="pure-menu-list">

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                5D GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children class5d">
                               <!--5d items will appear here-->
                            </ul>
                        </li>
                        
                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                               3D GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children class3d">
                               <!--3d items will appear here-->
                            </ul>
                        </li>

                          <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                               FAST 3 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classf3">
                                <!--fast 3 items will appear here-->
                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                KENO GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classkeno">
                                <!--keno 3 items will appear here-->
                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                PK 10 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classpk">

                                <!--pk 10 3 items will appear here-->

                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                PC 28 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classpc">
                              
                               <!--pc 10 3 items will appear here-->

                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                11x5 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children class11">
                              
                               <!--11x5 10 3 items will appear here-->
                            </ul>
                        </li>

                        <li class="pure-menu-item name
                        pure-menu-has-children
                        pure-menu-allow-hover">
                        <a href="#"
                            class="pure-menu-link1 text-white hvr-grow">
                            49x7 GAME SERIES
                        </a>
          
                          <ul class="pure-menu-children class49">
                            <!--49x7 10 3 items will appear here-->
                          </ul>
                        </li>
             
                    </ul>
                </div> 

          
            </div>
         
          <div class="col-md-10">
            
            <div class="d-flex justify-content-end">
             
            <div class="btn-group" role="group" aria-label="Basic outlined">
            <button type="button" class="btn btn-outline-light"><i class='bx bx-save'></i>Save PDF</button>
            <button type="button" class="btn btn-outline-light"><i class='bx bx-save'></i>Save Excel</button>
            </div>

            </div>
            
            <table class="table table-bordered table-hover " id="example">

              <div class='lmask'></div>
    
                <thead class="" style="border-top-left-radius: 20px;border-top-right-radius: 20px;background-image: linear-gradient(to right, #34267D , #BE039F);">
                  <tr>
                    <th scope="col" style="text-align:center">Draw Period</th>
                    <th scope="col" style="text-align:center">Draw Date</th>
                    <th scope="col" style="text-align:center">Draw Number</th>
                    <th scope="col" style="text-align:center">Draw Time</th>
                  </tr>
                </thead>
                <tbody>
                 <!---data will fill here-->
                </tbody>
            </table>
       
            <!--table section-->
            
          </div>
       
      </div>
    </center>  

    <!--table end-->

  </div>
</div>
</div>

<footer class="mastfoot my-3">
    <div class="inner container">
         <div class="row">
         	<div class="col-lg-4 col-md-12 d-flex align-items-center">
         		
         	</div>
         	<div class="col-lg-4 col-md-12 d-flex align-items-center">
         		<p class="mx-auto text-center mb-0">&copy; 1KBALL UI GAME</p>
         	</div>
           
            <!-- <div class="col-lg-4 col-md-12">
            	<nav class="nav nav-mastfoot justify-content-center">
	                <a class="nav-link" href="#">
	                	<i class="fab fa-facebook-f"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-twitter"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-instagram"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-linkedin"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-youtube"></i>
	                </a>
	            </nav>
            </div> -->
            
        </div>
    </div>
</footer>	


<div class="modal in modal-resize modal-drag" id="modal" style="display:none">
  <div class="modal-dialog" id="movableDialog">
    <div class="modal-content" id="resizableContent">
      <div class="modal-header modal-drag-handle" style="height:20px;background-image: linear-gradient(to right, #000 , #000);">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <!-- <div class="modal-body" style="height:350px;">
        <iframe src="http://203.161.53.136/stream/live.m3u8" class="responsive-iframe" frameborder="0" scrolling="false" allow="fullscreen" allowfullscreen="true" width="100%" height="100%" ></iframe>
      </div> -->

      <!-- <div id="player"></div> -->
      <video id="video" controls></video>
      
    </div>
  </div>
</div>

	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>
	<script src="vendor/bootstrap/popper.min.js"></script>
	<script src="vendor/bootstrap/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js "></script>
	<script src="vendor/owlcarousel/owl.carousel.min.js"></script>
	<script src="vendor/stellar/jquery.stellar.js" type="text/javascript" charset="utf-8"></script>
	<script src="vendor/isotope/isotope.min.js"></script>
	<script src="vendor/lightcase/lightcase.js"></script>
	<script src="vendor/waypoints/waypoint.min.js"></script>
  <script src="js/aos.js"></script>

    <!-- BootStrap JS -->

	<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
  <!-- <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
  <script type="text/javascript" src="DataTables/datatables.min.js"></script> -->
  
  /* <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script> */

	<!-- Main JS -->
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->
	<!-- <script src="js/app.min.js "></script> -->
	<!-- <script src="//localhost:35729/livereload.js"></script> -->
    <!-- <script src="dist/js/ckin.min.js"></script> -->
    <script src="lib/nifty.js"></script>
    <script src="js/comp.js"></script>

    <!-- Custom JS -->
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="pop/src/popupwindow.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/hls.js@1"></script>
  
    <script>

      // For Moving
     $('#movableDialog').draggable({
       handle: ".modal-header"
     });

     // For Resizing
     $('#resizableContent').resizable({
       minHeight: 200,
       minWidth: 200
     });
    </script>
   
   <script src="result.js"></script>
   
</body>
</html>
