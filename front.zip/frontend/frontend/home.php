<!DOCTYPE html>
<html lang="en" oncontextmenu="return false">

<head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>1kball</title>
    <meta name="description" content="Roxy">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- External CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/select2/select2.min.css">
    <link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendor/lightcase/lightcase.css">
     <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
     <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400|Work+Sans:300,400,700" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preload" href="images/result.jpg" as="image"/>
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="dist/css/ckin.css">
    <link rel="stylesheet" href="lib/nifty.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- Modernizr JS for IE8 support of HTML5 elements and media queries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

    <link rel="stylesheet" href= "https://unpkg.com/purecss@2.0.6/build/pure-min.css">
    <style>
        .act{
            border-bottom:solid 2px  #ff00cc;
        }
         /* //masker */

    .lmask {
           position: absolute;
           height: 100%;
           width: 100%; 
           background-color: #000;
           bottom: 0;
           left: 0;
           right: 0;
           top: 0;
           z-index: 9999;;
           opacity: 0.4;}
           .lmask {
             position: fixed;
           }
           .lmask:before {
             content: '';
             background-color: rgba(0,0,0,0);
             border: 5px solid rgba(0,183,229,0.9);
             opacity: .9;
             border-right: 5px solid rgba(0,0,0,0);
             border-left: 5px solid rgba(0,0,0,0);
             border-radius: 50px;
             box-shadow: 0 0 35px #2187e7;
             width: 50px;
             height: 50px;
             -moz-animation: spinPulse 1s infinite ease-in-out;
             -webkit-animation: spinPulse 1s infinite linear;
         
             margin: -25px 0 0 -25px;
             position: absolute;
             top: 50%;
             left: 50%;
           }
           .lmask:after {
             content: '';
             background-color: rgba(0,0,0,0);
             border: 5px solid rgba(0,183,229,0.9);
             opacity: .9;
             border-left: 5px solid rgba(0,0,0,0);
             border-right: 5px solid rgba(0,0,0,0);
             border-radius: 50px;
             box-shadow: 0 0 15px #2187e7;
             width: 30px;
             height: 30px;
             -moz-animation: spinoffPulse 1s infinite linear;
             -webkit-animation: spinoffPulse 1s infinite linear;
         
             margin: -15px 0 0 -15px;
             position: absolute;
             top: 50%;
             left: 50%;
           }
         
         @-moz-keyframes spinPulse {
           0% {
             -moz-transform:rotate(160deg);
             opacity: 0;
             box-shadow: 0 0 1px #2187e7;
           }
           50% {
             -moz-transform: rotate(145deg);
             opacity: 1;
           }
           100% {
             -moz-transform: rotate(-320deg);
             opacity: 0;
           }
         }
         @-moz-keyframes spinoffPulse {
           0% {
             -moz-transform: rotate(0deg);
           }
           100% {
             -moz-transform: rotate(360deg);
           }
         }
         @-webkit-keyframes spinPulse {
           0% {
             -webkit-transform: rotate(160deg);
             opacity: 0;
             box-shadow: 0 0 1px #2187e7;
           }
           50% {
             -webkit-transform: rotate(145deg);
             opacity: 1;
           }
           100% {
             -webkit-transform: rotate(-320deg);
             opacity: 0;
           }
         }
         @-webkit-keyframes spinoffPulse {
           0% {
             -webkit-transform: rotate(0deg);
           }
           100% {
             -webkit-transform: rotate(360deg);
           }
         }

    </style>
</head>
<body data-spy="scroll" data-target="#navbar" class="static-layout">
    <div class='lmask'></div>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg static-top" style="background-color: #3D1D7E !important;">
    <div class="container"  style="background-color: transparent !important;">
      <a class="navbar-brand" href="home.html">
        <img src="img/logo.jpg" width="130px" height="40px" style="box-shadow:rgba(0,0,0,0,.16) 0px 1px 4px;border-radius: 8px;border:solid 5px #fff">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto">
  
          <li class="nav-item">
            <a class="nav-link text-white" aria-current="page" href="#" style="border-bottom:solid 2px #fff;">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white " aria-current="page" href="product"  >Products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white " aria-current="page" href="result">Results</a>
          </li>
          <li class="nav-item">
            <a class="nav-link activee" aria-current="page" href="api">Game API</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>
<section id="features" style="background-image: url('images/home.jpg');background-position: center;background-repeat: no-repeat;background-size: cover;z-index:0;">
    <!--img src="img/logo.jpg" width="150px" height="60px" style="border-radius:0px;padding:1px;position: absolute; left:1%;top:8px;box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;"-->
    
    <div class="container" style="position: relative;top: -0px;">
        <div class="section-content">
            <!-- Section Title -->
            <div class="title-wrap mb-5" data-aos="fade-up">
                <br><br><br>
                <h2 class="section-title text-white">
                    1KBall UI  <a href="#o" target="_blank">Video Game</a>
                </h2>
                <p class="section-sub-title text-white">
                    1kball Lottery is a type of digital lottery game that provides real-time lottery results and live video services, <br>allowing users to watch the lottery drawing process through online streaming, <br> increasing user engagement and entertainment. As an innovator in the lottery industry,
                </p>
            </div>
            <!-- End of Section Title -->
            <div class="row">
                <!-- Features Holder-->
          
                <div class="col-md-10 offset-md-1 features-holder" style="position:relative; z-index:555;">
                    <div class="row">
                        <!-- Features Item -->
                        <div class="col-md-6 col-sm-12 text-center mt-4">
                            <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up"  style="background-color: rgb(10,72,177,.1);border: solid 2px #fff;">
                                <div class="my-6">
                                  
                                    <i class='bx bx-table bx-tada'  style='color:#ff00cc;font-size: 80px;' ></i>
                                </div>
                                <h4><b style="color:#fff">Real-time lottery results</b></h4>
                                <p style="color:#eee">The website can provide real-time lottery results, allowing users to stay up-to-date with the latest lottery results.</p>
                            </div>
                            <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up"  style="background-color: rgb(10,72,177,.1);border: solid 2px #fff;">
                                <div class="my-6">
                                    <i class='bx bx-dice-4 bx-tada' style='color:#ff00cc;font-size: 80px;' ></i>
                                </div>
                                <h4><b style="color:#fff">Multiple lottery types</b></h4>
                                <p style="color:#eee">The website covers a variety of lottery types, including 3D, 5D, 11-5, PK10, Mark Six, Fast Three, Keno, PC egg, and global lotteries, allowing users to choose the lottery types they are interested in</p>
                            </div>
                            <!-- <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up">
                                <div class="my-6">
                                <i class="lnr lnr-thumbs-up fs-40"></i>
                                </div>
                                <h4><b>Live video lottery</b></h4>
                                <p>The website provides live video lottery services, allowing users to watch lottery draws live via the internet, increasing user participation and entertainment value.</p>
                            </div> -->
                            </div>
                            <!-- End of Feature Item -->
                            <!-- Features Item -->
                            <!-- <div class="col-md-4 col-sm-12 text-center">
                            <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up">
                                <div class="my-4">
                                    <i class="lnr lnr-bubble fs-40"></i>
                                </div>
                                <h4>Full Support</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
                            </div>
                            <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up">
                                <div class="my-4">
                                    <i class="lnr lnr-magic-wand fs-40"></i>
                                </div>
                                <h4>Clean Design</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
                            </div>
                        </div> -->
                        <!-- End of Feature Item -->
                        <!-- Features Item -->

                        <div class="col-md-6 col-sm-12 text-center mt-4">
                            <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up" style="background-color: rgb(10,72,177,.1);border: solid 2px #fff;">
                                <div class="my-6">
                                    <i class='bx bx-globe bx-tada' style='color:#ff00cc;font-size: 80px;' ></i>
                                </div>
                                <h4><b style="color:#fff">Global data support</b></h4>
                                <p style="color:#eee">The website provides global lottery data support, allowing users to participate in lottery games from around the world and learn about global lottery results</p>
                            </div>
                            <div class="shadow rounded feature-item p-4 mb-4" data-aos="fade-up"  style="background-color: rgb(10,72,177,.1);border: solid 2px #fff;">
                                <div class="my-6">
                                    <i class='bx bx-video bx-tada' style='color:#ff00cc;font-size: 80px;' ></i>
                                </div>
                                <h4><b style="color:#fff">Live video lottery</b></h4>
                                <p style="color:#eee">The website provides live video lottery services, allowing users to watch lottery draws live via the internet, increasing user participation and entertainment value.</p>
                            </div>

                           
                        </div>
                        <!-- End of Feature Item -->
                    </div>
                </div>
                <!-- End of Features Holder-->
            </div>
        </div>
    </div>
</section>


<footer class="mastfoot my-3" style="box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 4px 0px inset;">
    <div class="inner container">
         <div class="row">
          <div class="col-lg-4 col-md-12 d-flex align-items-center">
         		
          </div>
          <div class="col-lg-4 col-md-12 d-flex align-items-center">
            <p class="mx-auto text-center mb-0">&copy; 1KBALL UI GAME</p>
          </div>
         	<!-- <div class="col-lg-4 col-md-12 d-flex align-items-center">
         		<p class="mx-auto text-center mb-0">&copy; 2023 1KBALL UI GAME</a></p>
         	</div>
            -->
            <!-- <div class="col-lg-4 col-md-12">
            	<nav class="nav nav-mastfoot justify-content-center">
	                <a class="nav-link" href="#">
	                	<i class="fab fa-facebook-f"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-twitter"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-instagram"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-linkedin"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-youtube"></i>
	                </a>
	            </nav>
            </div> -->
            
        </div>
    </div>
</footer>	<!-- External JS -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
	<script src="vendor/bootstrap/popper.min.js"></script>
	<script src="vendor/bootstrap/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js "></script>
	<script src="vendor/owlcarousel/owl.carousel.min.js"></script>
	<script src="vendor/stellar/jquery.stellar.js" type="text/javascript" charset="utf-8"></script>
	<script src="vendor/isotope/isotope.min.js"></script>
	<script src="vendor/lightcase/lightcase.js"></script>
	<script src="vendor/waypoints/waypoint.min.js"></script>
	<script src="js/aos.js"></script>
	 
	<!-- Main JS -->
	<script src="js/app.min.js "></script>
	<!-- <script src="//localhost:35729/livereload.js"></script> -->
    <script>
        $(function(){
            $(".lmask").removeClass("lmask")
        })
    </script>
</body>
</html>
