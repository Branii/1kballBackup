$(document).ready(function () {
    let a,
        e = new Map(),
        s = [],
        t = new Map();
        api = {};

        fetch("apis.json")
        .then(Response => Response.json())
        .then(data => {
            console.log("data: " + data);
            api = data;
              // or whatever you wanna do with the data
        });

        console.log("api: " + api);

    if (
        ($("#stream").click(function () {
            $("#modal").css("display", "block");
            var a = document.getElementById("video"),
                s = e.get("streamfile");
            if (a.canPlayType("application/vnd.apple.mpegurl")) a.src = s;
            else if (Hls.isSupported()) {
                var t = new Hls();
                t.loadSource(s), t.attachMedia(a);
            }
        }),
        $(".close").click(function () {
            $("#modal").css("display", "none");
        }),
        localStorage.getItem("currentTable"))
    ) {
        let e = localStorage.getItem("currentTable"),
            s = localStorage.getItem("details"),
            t = localStorage.getItem("currId");
        (a = localStorage.getItem("currId")), (apicall = localStorage.getItem("apiname")), $(".title").text(e), $(".details").text(s), $(".currIdd").text(t);
    } else (apicall = "1kball1min"), $(".currIdd").text("10001"), (a = "10001"), $(".title").text("1KBALL 5D"), $(".details").text("1kball 5D 1min rules: daily 1380 00:00-23:59 1 minute period, maintenance time GMT+8 05:00-06:00 am");
    "live" == localStorage.getItem("vidState") ? $("#stream").show() : (document.getElementById("stream").style.display = "none"),
        fetch("http://69.49.228.42/1kball/dev/api/v1/" + apicall)
            .then((a) => a.json())
            .then((a) => {
                (s = a),
                    $("#example").DataTable({
                        dom: "lrtip",
                        dom: '<"top"i>rt<"bottom"flp><"clear">',
                        data: s,
                        sorting: !1,
                        searching: !1,
                        info: !1,
                        columns: [{ data: "draw_count" }, { data: "draw_date" }, { data: "draw_number",
                        render: function(data){
                            const numbersArray = data.split(',');
                            const newContent = numbersArray.map(number => {
                            return `<span class="number">${number}</span>`;
                            }).join("");
                            return newContent;
                      }
                    
                    }, { data: "draw_time" }],
                    }),
                    $(".lmask").removeClass("lmask");
            }),
        fetch("http://69.49.228.42/1kball/dev/")
            .then((a) => a.json())
            .then((a) => {
                a.forEach((a) => {
                    axios
                        .get(a.data_url)
                        .then(function (e) {
                            t.set(a.game_name, JSON.stringify(e.data));
                        })
                        .catch(function (a) {
                            console.log(a);
                        });
                });
            })
            .catch((a) => console.error(a)),
        Promise.all([
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/1/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/2/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/3/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/4/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/5/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/6/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/7/"),
            fetch("http://69.49.228.42/1kball/dev/api/v1/catgames/8/"),
        ])
            .then(function (a) {
                return Promise.all(
                    a.map(function (a) {
                        return a.json();
                    })
                );
            })
            .then(function (a) {
                let e = a[0],
                    s = a[1],
                    t = a[2],
                    n = a[3],
                    l = a[4],
                    d = a[5],
                    i = a[6],
                    c = a[7];

                    //console.log(n)
                document.getElementsByClassName("class5d");
                e.forEach((a) => {
                    $(".class5d").append(
                        "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                            a.vid_state +
                            "</span><span class='gamename'>" +
                            a.game_name +
                            "</span><span class='gamelink' hidden >" +
                            a.data_url +
                            "</span> <span class='currId' hidden >" +
                            a.game_id +
                            "</span><span class='channel' hidden>" +
                            a.stream_url +
                            "</span><span class='vidstatus' hidden>" +
                            a.notify +
                            "</span><span class='gamedetails' hidden>" +
                            a.game_details +
                            "</span><span class='apiname' hidden>" +
                            a.data_url.split("/")[7] +
                            "</span></li>"
                    );
                }),
                    s.forEach((a) => {
                        $(".class3d").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    }),
                    t.forEach((a) => {
                        $(".classf3").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    }),
                    n.forEach((a) => {
                        $(".classkeno").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    }),
                    l.forEach((a) => {
                        $(".classpk").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    }),
                    d.forEach((a) => {
                        $(".classpc").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    }),
                    i.forEach((a) => {
                        $(".class11").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    }),
                    c.forEach((a) => {
                        $(".class49").append(
                            "<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>" +
                                a.vid_state +
                                "</span><span class='gamename'>" +
                                a.game_name +
                                "</span><span class='gamelink' hidden >" +
                                a.data_url +
                                "</span> <span class='currId' hidden >" +
                                a.game_id +
                                "</span><span class='channel' hidden>" +
                                a.stream_url +
                                "</span><span class='vidstatus' hidden>" +
                                a.notify +
                                "</span><span class='gamedetails' hidden>" +
                                a.game_details +
                                "</span><span class='apiname' hidden>" +
                                a.data_url.split("/")[7] +
                                "</span></li>"
                        );
                    });
            })
            .catch(function (a) {}),
        $(document).on("click", ".listitem", function () {
            let e = $(this).closest("li").find(".gamename").text(),
                s = $(this).closest("li").find(".gamedetails").text(),
                n = $(this).closest("li").find(".currId").text(),
                l = $(this).closest("li").find(".apiname").text(),
                d = $(this).closest("li").find(".vidstate").text(),
                i = JSON.parse(t.get(e));
            (a = n),
                $(".title").text(e.toUpperCase()),
                $(".holder").text(e),
                $(".details").text(s),
                $(".currIdd").text(n),
                "live" == d ? $("#stream").show() : $("#stream").hide(),
                localStorage.setItem("currentTable", e),
                localStorage.setItem("details", s),
                localStorage.setItem("apiname", l),
                localStorage.setItem("currId", n),
                localStorage.setItem("vidState", d),
                $("#example").dataTable().fnClearTable(),
                $("#example").dataTable().fnDestroy(),
                $("#example").DataTable({
                    dom: "lrtip",
                    dom: '<"top"i>rt<"bottom"flp><"clear">',
                    data: i,
                    sorting: !1,
                    searching: !1,
                    info: !1,
                    columns: [{ data: "draw_count" }, { data: "draw_date" }, { data: "draw_number",
                    render: function(data){
                        const numbersArray = data.split(',');
                        const newContent = numbersArray.map(number => {
                        return `<span class="number">${number}</span>`;
                        }).join("");
                        return newContent;
                  }
                }, { data: "draw_time" }],
                });
        }),
        $(".name").on("click", function () {
            $(".name").removeClass("active"), $(this).addClass("active");
        });
    let updateTableEarly = () => {
            setTimeout(function () {
                fetch("http://69.49.228.42/1kball/dev/api/v1/update/" + $(".currIdd").text())
                    .then((a) => a.json())
                    .then((a) => {
                        $("#example").dataTable().fnClearTable(),
                            $("#example").dataTable().fnDestroy(),
                            $("#example").DataTable({
                                dom: "lrtip",
                                dom: '<"top"i>rt<"bottom"flp><"clear">',
                                data: a,
                                sorting: !1,
                                searching: !1,
                                info: !1,
                                columns: [{ data: "draw_count" }, { data: "draw_date" }, { data: "draw_number",
                                render: function(data){
                                    const numbersArray = data.split(',');
                                    const newContent = numbersArray.map(number => {
                                    return `<span class="number">${number}</span>`;
                                    }).join("");
                                    return newContent;
                              }
                            }, { data: "draw_time" }],
                            });
                    })
                    .catch((a) => console.log(a));
            }, 2e3);
        },
        getNewDraws = () => {
            setTimeout(function () {
                fetch("http://69.49.228.42/1kball/dev/")
                    .then((a) => a.json())
                    .then((a) => {
                        a.forEach((a, e) => {
                            axios
                                .get(a.data_url)
                                .then(function (e) {
                                    a.game_name;
                                    t.set(a.game_name, JSON.stringify(e.data));
                                })
                                .catch(function (a) {});
                        });
                    })
                    .catch((a) => console.log(a));
            }, 2e3);
        };
    !(function checkCode() {
        $.post("http://69.49.228.42/1kball/exec/checkStream.php", { gameid: $(".currIdd").text() }, function (a) {
            let s = a.split("=");
            "dead" == s[0].trim() ? (document.getElementById("stream").style.visibility = "hidden") : ((document.getElementById("stream").style.visibility = "visible"), e.set("streamfile", s[1]));
        }),
            fetch("http://69.49.228.42/1kball/dev/api/v1/updatechecker/" + $(".currIdd").text())
                .then((a) => a.json())
                .then((a) => {
                    localStorage.getItem("update") != a[0][1] && (getNewDraws(), updateTableEarly(), localStorage.setItem("update", a[0][1]));
                })
                .catch((a) => console.log(a)),
            setTimeout(checkCode, 3e3);
    })(),
        console.log();
});
