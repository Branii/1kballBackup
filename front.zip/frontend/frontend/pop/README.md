# jQuery PopupWindow

The ultimate popup/dialog/modal jQuery plugin

---

Documentation and examples at http://gasparesganga.com/labs/jquery-popup-window/
