<!DOCTYPE html>
<html lang="en" oncontextmenu="return false">
<head>                                                                                                                                                                                                                                                          

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>1kball</title>
    <meta name="description" content="Roxy">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- External CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/select2/select2.min.css">
    <link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendor/lightcase/lightcase.css">
     <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
     <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400|Work+Sans:300,400,700" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preload" href="images/result.jpg" as="image"/>
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="dist/css/ckin.css">
    <link rel="stylesheet" href="lib/nifty.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- Modernizr JS for IE8 support of HTML5 elements and media queries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <link rel="stylesheet" href= "https://unpkg.com/purecss@2.0.6/build/pure-min.css">
    <link rel="stylesheet" href="video/src/modal-win-component.css">

    <style>
       #wrapper {
     height: 100px;
     width: 500px;
 }
 #wrapper {
     bottom: 50%;
     right: 50%;
     position: absolute;
 }
 #container {
     background: #FFF;
     left: 50%;
     padding: 10px;
     top: 50%;
     margin: 0;
     padding: 0;
     height: 100%;
     border: 1px solid rgb(128, 128, 128);
     height: 100%;
     position: relative;
 }
 #inner1 {
     height: 100%;
     border: 1px solid blue;
 }
 #inner2 {
     height: 100%;
     border: 1px solid green;
 }
 #titlebar {
     cursor: pointer;
     height: 23px;
     width: 100%;
     filter: progid:DXImageTransform.Microsoft.gradient(startColorStr=#0A246A, endColorStr=#A6CAF0, GradientType=1);
     color: white;
     font:13px arial, helvetica;
 }
 #button {
     line-height: 12px;
     width: 18px;
     font-size: 8pt;
     font-family: tahoma;
     margin-top: 1px;
     margin-right: 2px;
     position:absolute;
     top:0;
     right:0;
 }
    </style>

    <style>

          /* //masker */

    .lmask {
           position: absolute;
           height: 100%;
           width: 100%; 
           background-color: #000;
           bottom: 0;
           left: 0;
           right: 0;
           top: 0;
           z-index: 9999;;
           opacity: 0.4;}
           .lmask {
             position: fixed;
           }
           .lmask:before {
             content: '';
             background-color: rgba(0,0,0,0);
             border: 5px solid rgba(0,183,229,0.9);
             opacity: .9;
             border-right: 5px solid rgba(0,0,0,0);
             border-left: 5px solid rgba(0,0,0,0);
             border-radius: 50px;
             box-shadow: 0 0 35px #2187e7;
             width: 50px;
             height: 50px;
             -moz-animation: spinPulse 1s infinite ease-in-out;
             -webkit-animation: spinPulse 1s infinite linear;
         
             margin: -25px 0 0 -25px;
             position: absolute;
             top: 50%;
             left: 50%;
           }
           .lmask:after {
             content: '';
             background-color: rgba(0,0,0,0);
             border: 5px solid rgba(0,183,229,0.9);
             opacity: .9;
             border-left: 5px solid rgba(0,0,0,0);
             border-right: 5px solid rgba(0,0,0,0);
             border-radius: 50px;
             box-shadow: 0 0 15px #2187e7;
             width: 30px;
             height: 30px;
             -moz-animation: spinoffPulse 1s infinite linear;
             -webkit-animation: spinoffPulse 1s infinite linear;
         
             margin: -15px 0 0 -15px;
             position: absolute;
             top: 50%;
             left: 50%;
           }
         
         @-moz-keyframes spinPulse {
           0% {
             -moz-transform:rotate(160deg);
             opacity: 0;
             box-shadow: 0 0 1px #2187e7;
           }
           50% {
             -moz-transform: rotate(145deg);
             opacity: 1;
           }
           100% {
             -moz-transform: rotate(-320deg);
             opacity: 0;
           }
         }
         @-moz-keyframes spinoffPulse {
           0% {
             -moz-transform: rotate(0deg);
           }
           100% {
             -moz-transform: rotate(360deg);
           }
         }
         @-webkit-keyframes spinPulse {
           0% {
             -webkit-transform: rotate(160deg);
             opacity: 0;
             box-shadow: 0 0 1px #2187e7;
           }
           50% {
             -webkit-transform: rotate(145deg);
             opacity: 1;
           }
           100% {
             -webkit-transform: rotate(-320deg);
             opacity: 0;
           }
         }
         @-webkit-keyframes spinoffPulse {
           0% {
             -webkit-transform: rotate(0deg);
           }
           100% {
             -webkit-transform: rotate(360deg);
           }
         }

    
     pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; color:#fff; }
    .string { color: #fff;  font-weight: 100;font-size: 18px;}
    .number { color: #fff; }
    .boolean { color: blue; }
    .null { color: magenta; }
    .key { color: #fff; font-weight: 100;font-size: 18px;}
    .bracket { color:red}

    .ball{
        width: 30px;
        height: 30px;
        border:none;
        padding:0px;
        background-image: url('img/btnbg.png');
        background-size:     cover; 
        border-radius: 100px;
        color:black;
        font-weight: bold;
    }
    /* Grow */
    .hvr-grow {
        display: inline-block;
        vertical-align: middle;
        transform: translateZ(0);
        box-shadow: 0 0 1px rgba(0, 0, 0, 0);
        backface-visibility: hidden;
        -moz-osx-font-smoothing: grayscale;
        transition-duration: 0.3s;
        transition-property: transform;
    }

    .hvr-grow:hover,
    .hvr-grow:focus,
    .hvr-grow:active {
        transform: scale(1.1);
    }

    #stream:hover{
        background-color: #fff;
    }

    /* width */
    ::-webkit-scrollbar {
    width: 0px;
    }

    /* Track */
    ::-webkit-scrollbar-track {
    background: #f1f1f1;
    }

    /* Handle */
    ::-webkit-scrollbar-thumb {
    background: transparent;
    }

    /* Handle on hover */
    ::-webkit-scrollbar-thumb:hover {
    background: #fff;
    }

    .name{
        cursor: pointer;
        width: 100%;
        height: 45px;
        color:#fff;
        line-height: 40px;
        border-bottom: solid 1px #aaa;
    }
    .name:hover{
        background-color: #287475;
    }

    .active{
        background-color: #287475;
    }

    

.pure-menu-children{
    border:solid 0px #287475;
    background-color:rgb(31,106,111,0.3);
    border:solid .5px #fff;
}


.pure-menu-link1{
text-decoration: none;
list-style-type: none;
}

.pure-menu-itemm{
text-decoration: none;
list-style-type: none;
height: 45px;
width: 100%;
background-image: linear-gradient(to right, #619486 , #216A6E) !important;
}

.pure-menu-itemm:hover{
    border-bottom: solid 1px #eee;
   /* // width: 80%; */
}

.pure-menu-children{
    width: 250px;
    padding: 10px;
}

table td{
  text-align: center;
}

    </style>

    

</head>
<body data-spy="scroll" data-target="#navbar" class="static-layout" >
	<div id="side-nav" class="sidenav">
	<a href="javascript:void(0)" id="side-nav-close">&times;</a>
	
</div>	
<!-- Navigation -->
<nav class="navbar navbar-expand-lg static-top" style="background-color: #246266 !important;">
  <div class="container"  style="background-color: transparent !important;">
    <a class="navbar-brand" href="home.html" >
      <img src="img/logo.jpg" width="130px" height="40px" style="box-shadow:rgba(0,0,0,0,.16) 0px 1px 4px;border-radius: 8px;border:solid 5px #fff">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto">

        <li class="nav-item">
          <a class="nav-link text-white" aria-current="page" href="home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " aria-current="page" href="product">Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " aria-current="page" href="result">Results</a>
        </li>
        <li class="nav-item">
          <a class="nav-link activee" aria-current="page" href="#" style="border-bottom:solid 2px #fff;">Game API</a>
        </li>
        
      </ul>
    </div>
  </div>
</nav>


<div class="jumbotron jumbotron-single d-flex align-items-center" style="background-image: url('images/api.jpg')" style="position:relative;top:-50px;">
<div class="container text-center">
    
   <center>

    <div>

        <thead class="" style="border:none">
            <tr style="border:none;">
              <div class="d-flex justify-content-start" scope="col" colspan="4" style="">
                <div><i class='bx bx-info-circle' style='color:#e8741f;font-size: 20px;margin-right: 3px;position: relative;top: 1px;' ></i></div>
                <tr><H6>Title: <span class="title">1kball 1min</span><span class="holder" hidden>1kball 1min</span> <span class="currIdd" hidden>10001</span>
                 </span></button></H6></tr>
              </div>
            </tr>
          </thead>
        
          <thead class="" style="border:none">
            <tr style="border:none;">
              <div class="d-flex justify-content-start" scope="col" colspan="4" style="">
                <p style="padding:10px;text-align: left;" class="details">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia,
                molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborum
                numquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium
               </p>
              </div>
            </tr>
          </thead>

    </div>

      <div class="row d-flex justify-content-center">
       <a href="#" id="apiaddr"><button type="button" class="btn btn-primary btn-sm buy"  style="position:relative;left:43%;width:auto;padding:5px;background-color:transparent;border:solid 1px #fff;top:50px;z-index:5000;">PURCHASE API</button></a> 
      
        <div class="row">

            
          
            <div class="col-md-2" style="padding:0px;margin:0px;width:200px;height:460px;border:solid 1px #fff;border-top-left-radius: 10px;border-bottom-left-radius: 10px;border-top-right-radius: 10px;border-bottom-right-radius: 10px;">

              
                <div style="border-bottom:solid 1px #fff;height:45px;background-color:rgb(10,68,175,0.);width:193px;border-top-left-radius: 10px;border-top-right-radius: 10px;">
                    <span style="line-height:50px;"><b>API Draws</b></span>
                </div>

               
                 <div class=" pure-menu custom-display">
                    <ul class="pure-menu-list">

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                5D GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children class5d">
                               <!--5d items will appear here-->
                            </ul>
                        </li>
                        
                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                               3D GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children class3d">
                               <!--3d items will appear here-->
                            </ul>
                        </li>

                          <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                               FAST 3 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classf3">
                                <!--fast 3 items will appear here-->
                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                KENO GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classfs">
                                <!--fsat 3 items will appear here-->
                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                PK 10 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classpk">

                                <!--pk 10 3 items will appear here-->

                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                PC 28 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children classpc">
                              
                               <!--pc 10 3 items will appear here-->

                            </ul>
                        </li>

                        <li class="pure-menu-item name
                                   pure-menu-has-children
                                   pure-menu-allow-hover">
                            <a href="#"
                               class="pure-menu-link1 text-white hvr-grow">
                                11x5 GAME SERIES
                            </a>
             
                            <ul class="pure-menu-children class11">
                              
                               <!--11x5 10 3 items will appear here-->
                            </ul>
                        </li>

                        <li class="pure-menu-item name
                        pure-menu-has-children
                        pure-menu-allow-hover">
                        <a href="#"
                            class="pure-menu-link1 text-white hvr-grow">
                            49x7 GAME SERIES
                        </a>
          
                          <ul class="pure-menu-children class49">
                            <!--49x7 10 3 items will appear here-->
                          </ul>
                        </li>
             
                    </ul>
                </div> 

          
            </div>
 

          <pre class="col-md-10 " id="apiresult" style="background-color:rgb(15,119,193,0.0) !important;text-align:left;overflow-y:scroll;height:455px;margin:5px;border-radius:10px;">
            <div class='lmask'></div>
            <!---API result will appear here--->
            
          </pre>

       
        </div>
      </div>
    </center>   



      

    <!--table end-->

  </div>
</div>
</div>
<footer class="mastfoot my-3">
    <div class="inner container">
         <div class="row">
         	<div class="col-lg-4 col-md-12 d-flex align-items-center">
         		
         	</div>
         	<div class="col-lg-4 col-md-12 d-flex align-items-center">
         		<p class="mx-auto text-center mb-0">&copy; 1KBALL UI GAME</p>
         	</div>
          
            
        </div>
    </div>
</footer>	<!-- External JS -->


	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>
	<script src="vendor/bootstrap/popper.min.js"></script>
	<script src="vendor/bootstrap/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js "></script>
	<script src="vendor/owlcarousel/owl.carousel.min.js"></script>
	<script src="vendor/stellar/jquery.stellar.js" type="text/javascript" charset="utf-8"></script>
	<script src="vendor/isotope/isotope.min.js"></script>
	<script src="vendor/lightcase/lightcase.js"></script>
	<script src="vendor/waypoints/waypoint.min.js"></script>
  <script src="js/aos.js"></script>
	<script src="js/app.min.js "></script>
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    
   <script>
    $(document).ready(function(){

    //console.clear()

    let arr = [];
    let drawData = []
    let mapData = new Map();

    let apical;
    let gameId;
    if(localStorage.getItem("currentTable")){
    let gamename =localStorage.getItem("currentTable")
    let details = localStorage.getItem("details"); 
    let currId = localStorage.getItem("currId"); 
    gameId = localStorage.getItem("currId"); 
    apicall = localStorage.getItem("apiname"); 
    $(".title").text(gamename)
    $(".details").text(details)
    $(".currIdd").text(currId)
    }else{
      apicall = "1kball1min";
      $(".currIdd").text("10001")
      gameId = "10001";
      $(".title").text("1KBALL 5D")
      $(".details").text("...")
    } // testing ...

 fetch("http://69.49.228.42/1kball/dev/api/v1/apiupdate/" + gameId)
.then(Response => Response.json())
.then(data => {
 $(".lmask").removeClass("lmask")
 const obj = JSON.stringify(data,null,8);
 $("#apiresult").html(syntaxHighlight(obj))
});

//test get live data
//http://69.49.228.42/1kball/dev/
fetch('http://69.49.228.42/1kball/dev/')
.then(response => response.json())
.then(data => {
  //console.log(data)
  data.forEach(elementt => {
    
    axios.get(elementt.last_insertion)
    .then(function (data) {
      //console.log(data)
      // store draw data into compressor
      //JJLC.setItem(elementt.game_name, JSON.stringify(data));
      mapData.set(elementt.game_name,JSON.stringify(data.data))
      //localStorage.setItem(elementt.game_name,JSON.stringify(data.data))
      //console.log(data.data)
     
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })

  })
 
})
.catch(err => console.error(err));

Promise.all([
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/1/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/2/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/3/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/4/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/5/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/6/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/7/'),
  fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/8/')
]).then(function (responses) {
  // Get a JSON object from each of the responses
  return Promise.all(responses.map(function (response) {
    return response.json();
  }));
}).then(function (data) {
  // Log the data to the console
  // You would do something with both sets of data here
  //for 5d game series
  let arr5d = data[0],arr3d = data[1],arrf3 = data[2],arrfs = data[3];
  let arrpk = data[4],arrpc = data[5],arr11 = data[6],arr49 = data[7];

  //console.log(data[0])
  //let list = document.createElement("ul");
  let list =  document.getElementsByClassName("class5d"); 

  arr5d.forEach(element5d => {
  $(".class5d").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element5d.vid_state +"</span><span class='gamename'>"+ element5d.game_name +"</span><span class='gamelink' hidden >"+ element5d.data_url + "</span> <span class='currId' hidden >"+ element5d.game_id + "</span><span class='channel' hidden>"+ element5d.stream_url + "</span><span class='vidstatus' hidden>"+ element5d.notify + "</span><span class='gamedetails' hidden>"+ element5d.game_details + "</span><span class='apiname' hidden>"+ element5d.data_url.split("/")[7] + "</span></li>");
});
arr3d.forEach(element3d => {
  $(".class3d").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element3d.vid_state +"</span><span class='gamename'>"+ element3d.game_name +"</span><span class='gamelink' hidden >"+ element3d.data_url + "</span> <span class='currId' hidden >"+ element3d.game_id + "</span><span class='channel' hidden>"+ element3d.stream_url + "</span><span class='vidstatus' hidden>"+ element3d.notify + "</span><span class='gamedetails' hidden>"+ element3d.game_details + "</span><span class='apiname' hidden>"+ element3d.data_url.split("/")[7]+ "</span></li>");
});

arrf3.forEach(elementf3 => {
  $(".classf3").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementf3.vid_state +"</span><span class='gamename'>"+ elementf3.game_name +"</span><span class='gamelink' hidden >"+ elementf3.data_url + "</span> <span class='currId' hidden >"+ elementf3.game_id + "</span><span class='channel' hidden>"+ elementf3.stream_url + "</span><span class='vidstatus' hidden>"+ elementf3.notify + "</span><span class='gamedetails' hidden>"+ elementf3.game_details + "</span><span class='apiname' hidden>"+ elementf3.data_url.split("/")[7] + "</span></li>");
});

arrfs.forEach(elementfs => {
  $(".classfs").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementfs.vid_state +"</span><span class='gamename'>"+ elementfs.game_name +"</span><span class='gamelink' hidden >"+ elementfs.data_url + "</span> <span class='currId' hidden >"+ elementfs.game_id + "</span><span class='channel' hidden>"+ elementfs.stream_url + "</span><span class='vidstatus' hidden>"+ elementfs.notify + "</span><span class='gamedetails' hidden>"+ elementfs.game_details + "</span><span class='apiname' hidden>"+ elementfs.data_url.split("/")[7] + "</span></li>");
});

arrpk.forEach(elementpk => {
  $(".classpk").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementpk.vid_state +"</span><span class='gamename'>"+ elementpk.game_name +"</span><span class='gamelink' hidden >"+ elementpk.data_url + "</span> <span class='currId' hidden >"+ elementpk.game_id + "</span><span class='channel' hidden>"+ elementpk.stream_url + "</span><span class='vidstatus' hidden>"+ elementpk.notify + "</span><span class='gamedetails' hidden>"+ elementpk.game_details + "</span><span class='apiname' hidden>"+ elementpk.data_url.split("/")[7] + "</span></li>");
});

arrpc.forEach(elementpc => {
  $(".classpc").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementpc.vid_state +"</span><span class='gamename'>"+ elementpc.game_name +"</span><span class='gamelink' hidden >"+ elementpc.data_url + "</span> <span class='currId' hidden >"+ elementpc.game_id + "</span><span class='channel' hidden>"+ elementpc.stream_url + "</span><span class='vidstatus' hidden>"+ elementpc.notify + "</span><span class='gamedetails' hidden>"+ elementpc.game_details + "</span><span class='apiname' hidden>"+ elementpc.data_url.split("/")[7] + "</span></li>");
});

arr11.forEach(element11 => {
  $(".class11").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element11.vid_state +"</span><span class='gamename'>"+ element11.game_name +"</span><span class='gamelink' hidden >"+ element11.data_url + "</span> <span class='currId' hidden >"+ element11.game_id + "</span><span class='channel' hidden>"+ element11.stream_url + "</span><span class='vidstatus' hidden>"+ element11.notify + "</span><span class='gamedetails' hidden>"+ element11.game_details + "</span><span class='apiname' hidden>"+ element11.data_url.split("/")[7] + "</span></li>");
});

arr49.forEach(element49 => {
  $(".class49").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element49.vid_state +"</span><span class='gamename'>"+ element49.game_name +"</span><span class='gamelink' hidden >"+ element49.data_url + "</span> <span class='currId' hidden >"+ element49.game_id + "</span><span class='channel' hidden>"+ element49.stream_url + "</span><span class='vidstatus' hidden>"+ element49.notify + "</span><span class='gamedetails' hidden>"+ element49.game_details + "</span><span class='apiname' hidden>"+ element49.data_url.split("/")[7] + "</span></li>");
});

  }).catch(function (error) {
    // if there's an error, log it
    console.log(error);
  });



  //pretify json in a div
  function syntaxHighlight(json) {
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });
}


$(document).on("click",'.listitem',function(){
  
  let gamename = $(this).closest("li").find(".gamename").text()
  let gamedetails = $(this).closest("li").find(".gamedetails").text()
  let currId = $(this).closest("li").find(".currId").text()
  let gamelink = $(this).closest("li").find(".gamelink").text()
  let drawData = JSON.parse(mapData.get(gamename))
  let apiname = $(this).closest("li").find(".apiname").text()
  //et vidState = $(this).closest("li").find(".vidstate").text()

  gameId = currId;

$(".title").text(gamename.toUpperCase())
$(".holder").text(gamename)
$(".details").text(gamedetails)
$(".currIdd").text(currId)

// if(vidState == "live"){
//   $("#stream").show();
// }else{
//   $("#stream").hide();
// }

// do not refresh the game table on page reload ..
localStorage.setItem("currentTable",gamename); 
localStorage.setItem("details",gamedetails); 
localStorage.setItem("apiname",apiname); 
localStorage.setItem("currId",currId); 
//localStorage.setItem("vidState",vidState); 

  $(".title").text(gamename.toUpperCase())
  $(".holder").text(gamename)
  $(".currIdd").text(currId)
  $(".details").text(gamedetails)

  const obj = JSON.stringify(drawData,null,8);
  $("#apiresult").html(syntaxHighlight(obj))

  //$("#apiaddr").attr("href", gamelink)

})

$(".name").on("click",function(){
    $(".name").removeClass("active")
    $(this).addClass("active")
})

$(".buy").on("click",function(){
    alert("This feature is coming soom!!")
})


let getNewDraws = () => {

//$(".tell").show()
fetch('http://69.49.228.42/1kball/dev/')
.then(response => response.json())
.then(data => {
  let counter = 0;
  data.forEach((elementt, index) => {
    counter++;
    axios.get(elementt.last_insertion)
    .then(function (data) {
  
      //JJLC.setItem(elementt.game_name, JSON.stringify(data));
      let gamename = elementt.game_name;
      mapData.set(elementt.game_name,JSON.stringify(data.data))
      drawData = [{gamename:elementt.game_name, gamemdata:data.data}]

      //console.log(drawData)
      //counter == 18 ? updateTabaleLate() : ""
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })
  })//end of foreach loop
})
.catch(err => console.log(err));
}


let updateTableEarly = () => {

//console.log($(".currIdd").text());
//get the current table and live update
fetch('http://69.49.228.42/1kball/dev/api/v1/apiupdate/' + $(".currIdd").text())
.then(response => response.json())
.then(dataSet => {
  //update the active table first
  const obj = JSON.stringify(dataSet,null,8);
 $("#apiresult").html(syntaxHighlight(obj))

}).catch(err => console.log(err));
  
}

function checkCode(){

//--------check for live update----------

fetch('http://69.49.228.42/1kball/dev/api/v1/apiupdate/' + $(".currIdd").text())
.then(response => response.json())
.then(data => {

  //console.log(data.Data[0].draw_date)

  if(localStorage.getItem("update") == data.Data[0].draw_date){
    console.log("Same data")
  }else{
    updateTableEarly() 
    console.log("Updated => " + data.Data[0].draw_date)
    localStorage.setItem("update", data.Data[0].draw_date);
    
  }

}).catch(err => console.log(err));
setTimeout(checkCode,800);

}
checkCode();
console.clear();

})
   </script>
</body>
</html>
