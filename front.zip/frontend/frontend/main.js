
$(document).ready(function(){

  let stream_file = new Map();
  let streamlink;

    //console.clear()

    let arr = [];
    let drawData = []
    let mapData = new Map();

    $("#stream").click(function(){
    $("#modal").css("display","block");


    var video = document.getElementById('video');
    var videoSrc = stream_file.get("streamfile");

    if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = videoSrc;

    } else if (Hls.isSupported()) {
      var hls = new Hls();
      hls.loadSource(videoSrc);
      hls.attachMedia(video);
    }

    // var player = new Clappr.Player({
    // source: 'http://203.161.53.136/hls/' + stream_file.get("streamfile") + ".m3u8",
    // poster: 'http://clappr.io/poster.png',
    // plugins: [ClapprPIPPlugin],
    // mute: true,
    // height: 360,
    // width: 500
    // });
    // var playerElement = document.getElementById("player");
    // player.attachTo(playerElement);
     
      
    });

    $(".close").click(function(){
      $("#modal").css("display","none");
    })
   

    let apical;
    let gameId;
    if(localStorage.getItem("currentTable")){
    let gamename =localStorage.getItem("currentTable")
    let details = localStorage.getItem("details"); 
    let currId = localStorage.getItem("currId"); 
    gameId = localStorage.getItem("currId"); 
    apicall = localStorage.getItem("apiname"); 
    $(".title").text(gamename)
    $(".details").text(details)
    $(".currIdd").text(currId)
    }else{
      apicall = "1kball1min";
      $(".currIdd").text("10001")
      gameId = "10001";
      $(".title").text("1KBALL 5D")
      $(".details").text("1kball 5D 1min rules: daily 1380 00:00-23:59 1 minute period, maintenance time GMT+8 05:00-06:00 am")
    } // testing ...

    if(localStorage.getItem("vidState") == "live"){
      $("#stream").show();
    }else{
      document.getElementById("stream").style.display = "none";
    }

fetch("http://69.49.228.42/1kball/dev/api/v1/"  +apicall)
.then(Response => Response.json())
.then(data => {

// or whatever you wanna do with the data

arr = data;

$('#example').DataTable({
  "dom": 'lrtip',
  "dom": '<"top"i>rt<"bottom"flp><"clear">',
  data:arr,
  sorting:false,
  searching:false,
  "info":false,
  columns:[
      {data:'draw_count'},
      {data:'draw_date'},
      {data:'draw_number'},
      {data:'draw_time'}
  ]
});

$(".lmask").removeClass("lmask")
//console.clear();

});

//test get live data
//http://69.49.228.42/1kball/dev/
fetch('http://69.49.228.42/1kball/dev/')
.then(response => response.json())
.then(data => {
//console.log(data)
data.forEach(elementt => {
  
  axios.get(elementt.data_url)
  .then(function (data) {
    //console.log(data)
    // store draw data into compressor
    //JJLC.setItem(elementt.game_name, JSON.stringify(data));
    mapData.set(elementt.game_name,JSON.stringify(data.data))
    //localStorage.setItem(elementt.game_name,JSON.stringify(data.data))
    //console.log(data.data)
   
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  })

})

})
.catch(err => console.error(err));
Promise.all([
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/1/'), // 5d
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/2/'), // 3d
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/3/'), // fast 3
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/4/'), // keno
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/5/'), // pk 10
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/6/'), // pc 28
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/7/'), // 11 x 5
fetch('http://69.49.228.42/1kball/dev/api/v1/catgames/8/')  //  
]).then(function (responses) {
// Get a JSON object from each of the responses
return Promise.all(responses.map(function (response) {
  return response.json();
}));
}).then(function (data) {
// Log the data to the console
// You would do something with both sets of data here
//for 5d game series
let arr5d = data[0],arr3d = data[1],arrf3 = data[2],arrfs = data[3];
let arrpk = data[4],arrpc = data[5],arr11 = data[6],arr49 = data[7];

//let list = document.createElement("ul");
let list =  document.getElementsByClassName("class5d"); 

arr5d.forEach(element5d => {
  $(".class5d").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element5d.vid_state +"</span><span class='gamename'>"+ element5d.game_name +"</span><span class='gamelink' hidden >"+ element5d.data_url + "</span> <span class='currId' hidden >"+ element5d.game_id + "</span><span class='channel' hidden>"+ element5d.stream_url + "</span><span class='vidstatus' hidden>"+ element5d.notify + "</span><span class='gamedetails' hidden>"+ element5d.game_details + "</span><span class='apiname' hidden>"+ element5d.data_url.split("/")[7] + "</span></li>");
});
arr3d.forEach(element3d => {
  $(".class3d").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element3d.vid_state +"</span><span class='gamename'>"+ element3d.game_name +"</span><span class='gamelink' hidden >"+ element3d.data_url + "</span> <span class='currId' hidden >"+ element3d.game_id + "</span><span class='channel' hidden>"+ element3d.stream_url + "</span><span class='vidstatus' hidden>"+ element3d.notify + "</span><span class='gamedetails' hidden>"+ element3d.game_details + "</span><span class='apiname' hidden>"+ element3d.data_url.split("/")[7]+ "</span></li>");
});

arrf3.forEach(elementf3 => {
  $(".classf3").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementf3.vid_state +"</span><span class='gamename'>"+ elementf3.game_name +"</span><span class='gamelink' hidden >"+ elementf3.data_url + "</span> <span class='currId' hidden >"+ elementf3.game_id + "</span><span class='channel' hidden>"+ elementf3.stream_url + "</span><span class='vidstatus' hidden>"+ elementf3.notify + "</span><span class='gamedetails' hidden>"+ elementf3.game_details + "</span><span class='apiname' hidden>"+ elementf3.data_url.split("/")[7] + "</span></li>");
});

arrfs.forEach(elementfs => {
  $(".classfs").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementfs.vid_state +"</span><span class='gamename'>"+ elementfs.game_name +"</span><span class='gamelink' hidden >"+ elementfs.data_url + "</span> <span class='currId' hidden >"+ elementfs.game_id + "</span><span class='channel' hidden>"+ elementfs.stream_url + "</span><span class='vidstatus' hidden>"+ elementfs.notify + "</span><span class='gamedetails' hidden>"+ elementfs.game_details + "</span><span class='apiname' hidden>"+ elementfs.data_url.split("/")[7] + "</span></li>");
});

arrpk.forEach(elementpk => {
  $(".classpk").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementpk.vid_state +"</span><span class='gamename'>"+ elementpk.game_name +"</span><span class='gamelink' hidden >"+ elementpk.data_url + "</span> <span class='currId' hidden >"+ elementpk.game_id + "</span><span class='channel' hidden>"+ elementpk.stream_url + "</span><span class='vidstatus' hidden>"+ elementpk.notify + "</span><span class='gamedetails' hidden>"+ elementpk.game_details + "</span><span class='apiname' hidden>"+ elementpk.data_url.split("/")[7] + "</span></li>");
});

arrpc.forEach(elementpc => {
  $(".classpc").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ elementpc.vid_state +"</span><span class='gamename'>"+ elementpc.game_name +"</span><span class='gamelink' hidden >"+ elementpc.data_url + "</span> <span class='currId' hidden >"+ elementpc.game_id + "</span><span class='channel' hidden>"+ elementpc.stream_url + "</span><span class='vidstatus' hidden>"+ elementpc.notify + "</span><span class='gamedetails' hidden>"+ elementpc.game_details + "</span><span class='apiname' hidden>"+ elementpc.data_url.split("/")[7] + "</span></li>");
});

arr11.forEach(element11 => {
  $(".class11").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element11.vid_state +"</span><span class='gamename'>"+ element11.game_name +"</span><span class='gamelink' hidden >"+ element11.data_url + "</span> <span class='currId' hidden >"+ element11.game_id + "</span><span class='channel' hidden>"+ element11.stream_url + "</span><span class='vidstatus' hidden>"+ element11.notify + "</span><span class='gamedetails' hidden>"+ element11.game_details + "</span><span class='apiname' hidden>"+ element11.data_url.split("/")[7] + "</span></li>");
});

arr49.forEach(element49 => {
  $(".class49").append("<li class='pure-menu-itemm listitem'><span class='vidstate' hidden>"+ element49.vid_state +"</span><span class='gamename'>"+ element49.game_name +"</span><span class='gamelink' hidden >"+ element49.data_url + "</span> <span class='currId' hidden >"+ element49.game_id + "</span><span class='channel' hidden>"+ element49.stream_url + "</span><span class='vidstatus' hidden>"+ element49.notify + "</span><span class='gamedetails' hidden>"+ element49.game_details + "</span><span class='apiname' hidden>"+ element49.data_url.split("/")[7] + "</span></li>");
});

}).catch(function (error) {
  // if there's an error, log it
  //console.log(error);
});

// $(".title").text("hello word ..");
// $(".details").text("hello word ..");

$(document).on("click",'.listitem',function(){

let gamename = $(this).closest("li").find(".gamename").text()
let gamedetails = $(this).closest("li").find(".gamedetails").text()
let currId = $(this).closest("li").find(".currId").text()
let apiname = $(this).closest("li").find(".apiname").text()
let vidState = $(this).closest("li").find(".vidstate").text()
let drawData = JSON.parse(mapData.get(gamename))
gameId = currId;

$(".title").text(gamename.toUpperCase())
$(".holder").text(gamename)
$(".details").text(gamedetails)
$(".currIdd").text(currId)

if(vidState == "live"){
  $("#stream").show();
}else{
  $("#stream").hide();
}

// do not refresh the game table on page reload ..
localStorage.setItem("currentTable",gamename); 
localStorage.setItem("details",gamedetails); 
localStorage.setItem("apiname",apiname); 
localStorage.setItem("currId",currId); 
localStorage.setItem("vidState",vidState); 

$('#example').dataTable().fnClearTable()
$('#example').dataTable().fnDestroy()
$('#example').DataTable({
  "dom": 'lrtip',
  "dom": '<"top"i>rt<"bottom"flp><"clear">',
  data:drawData,
  sorting:false,
  searching:false,
  "info":false,
  columns:[
      {data:'draw_count'},
      {data:'draw_date'},
      {data:'draw_number'},
      {data:'draw_time'}
  ]
});

})

$(".name").on("click",function(){
  $(".name").removeClass("active")
  $(this).addClass("active")
})

let updateTableEarly = () => {
setTimeout(function(){

//get the current table and live update
fetch('http://69.49.228.42/1kball/dev/api/v1/update/' + $(".currIdd").text())
.then(response => response.json())
.then(dataSet => {

//update the active table first
$('#example').dataTable().fnClearTable()
$('#example').dataTable().fnDestroy()
$('#example').DataTable({
  "dom": 'lrtip',
  "dom": '<"top"i>rt<"bottom"flp><"clear">',
  data:dataSet,
  sorting:false,
  searching:false,
  "info":false,
  columns:[
      {data:'draw_count'},
      {data:'draw_date'},
      {data:'draw_number'},
      {data:'draw_time'}
  ]
});

}).catch(err => console.log(err));


},2000)
}

let getNewDraws = () => {
  
  setTimeout(function(){

    //$(".tell").show()
  fetch('http://69.49.228.42/1kball/dev/')
  .then(response => response.json())
  .then(data => {
    let counter = 0;
    data.forEach((elementt, index) => {
      counter++;
      axios.get(elementt.data_url)
      .then(function (data) {
        //console.log(data.data)
        //JJLC.setItem(elementt.game_name, JSON.stringify(data));
        let gamename = elementt.game_name;
        mapData.set(elementt.game_name,JSON.stringify(data.data))
        //drawData = [{gamename:elementt.game_name, gamemdata:data.data}]
  
        //console.log(drawData)
        //counter == 18 ? updateTabaleLate() : ""
      })
      .catch(function (error) {
        // handle error
        //console.log(error);
      })
    })//end of foreach loop
  })
  .catch(err => console.log(err));

  },2000);

  }


//----------- get concurrent data
// let eventSource = new EventSource("http://69.49.228.42/1kball/exec/checkStream.php?gameid=" + localStorage.getItem("currId"))
// eventSource.addEventListener('message', function(event) {
//     const eventData = JSON.parse(event.data);
//     console.log('Received event:', eventData);
// });


function checkCode(){

//---------check stream status-----------

$.post("http://69.49.228.42/1kball/exec/checkStream.php",{
  gameid:$(".currIdd").text()
},function(data){

  let datas = data.split("=");
  //console.log(datas[0])

  if(datas[0].trim() == "dead"){
    document.getElementById("stream").style.visibility = "hidden";
  }else{
    document.getElementById("stream").style.visibility = "visible";
    stream_file.set("streamfile",datas[1]);
    //console.log(stream_file.get("streamfile"));
    
  }
})

//--------check for live update----------

fetch('http://69.49.228.42/1kball/dev/api/v1/updatechecker/' + $(".currIdd").text())
.then(response => response.json())
.then(data => {

  //console.log(data[0][1])

  if(localStorage.getItem("update") == data[0][1]){
    //console.log("Same data")
    return
  }else{
    getNewDraws()
    updateTableEarly() 
    //console.log("Updated => " + data[0][1])
    localStorage.setItem("update", data[0][1]);
  }

}).catch(err => console.log(err));
setTimeout(checkCode,3000);

}
checkCode();
console.clear();

})
