<!DOCTYPE html>
<html lang="en" oncontextmenu="return false">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>1kball</title>
    <meta name="description" content="Roxy">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- External CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/select2/select2.min.css">
    <link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendor/lightcase/lightcase.css">
     <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
     <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400|Work+Sans:300,400,700" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>

    <link rel="preload" href="images/result.jpg" as="image"/>

    <!-- CSS -->
    <link rel="stylesheet" href="css/style.min.css">
    <link rel="stylesheet" href="dist/css/ckin.css">
    <link rel="stylesheet" href="lib/nifty.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- Modernizr JS for IE8 support of HTML5 elements and media queries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <link rel="stylesheet" href= "https://unpkg.com/purecss@2.0.6/build/pure-min.css">
    <link rel="stylesheet" href="video/src/modal-win-component.css">
  
    <style>
        
                 /* //masker */

    .lmask {
           position: absolute;
           height: 100%;
           width: 100%; 
           background-color: #000;
           bottom: 0;
           left: 0;
           right: 0;
           top: 0;
           z-index: 9999;;
           opacity: 0.4;}
           .lmask {
             position: fixed;
           }
           .lmask:before {
             content: '';
             background-color: rgba(0,0,0,0);
             border: 5px solid rgba(0,183,229,0.9);
             opacity: .9;
             border-right: 5px solid rgba(0,0,0,0);
             border-left: 5px solid rgba(0,0,0,0);
             border-radius: 50px;
             box-shadow: 0 0 35px #2187e7;
             width: 50px;
             height: 50px;
             -moz-animation: spinPulse 1s infinite ease-in-out;
             -webkit-animation: spinPulse 1s infinite linear;
         
             margin: -25px 0 0 -25px;
             position: absolute;
             top: 50%;
             left: 50%;
           }
           .lmask:after {
             content: '';
             background-color: rgba(0,0,0,0);
             border: 5px solid rgba(0,183,229,0.9);
             opacity: .9;
             border-left: 5px solid rgba(0,0,0,0);
             border-right: 5px solid rgba(0,0,0,0);
             border-radius: 50px;
             box-shadow: 0 0 15px #2187e7;
             width: 30px;
             height: 30px;
             -moz-animation: spinoffPulse 1s infinite linear;
             -webkit-animation: spinoffPulse 1s infinite linear;
         
             margin: -15px 0 0 -15px;
             position: absolute;
             top: 50%;
             left: 50%;
           }
         
         
    </style>
</head>
<body data-spy="scroll" data-target="#navbar" class="static-layout">
  <!-- Navigation -->
<nav class="navbar navbar-expand-lg static-top" style="background-color: #C33A3F !important;">
  <div class="container"  style="background-color: transparent !important;">
    <a class="navbar-brand" href="home.html">
      <img src="img/logo.jpg" width="130px" height="40px" style="box-shadow:rgba(0,0,0,0,.16) 0px 1px 4px;border-radius: 8px;border:solid 5px #fff">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto">

        <li class="nav-item">
          <a class="nav-link text-white" aria-current="page" href="home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " aria-current="page" href="#"  style="border-bottom:solid 2px #fff;">Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " aria-current="page" href="result">Results</a>
        </li>
        <li class="nav-item">
          <a class="nav-link activee" aria-current="page" href="api">Game API</a>
        </li>
        
      </ul>
    </div>
  </div>
</nav>

    <div class='lmask'></div>



<!-- Features Section-->
<section id="features" class="bg-white"  style="background-image: url('resbg.jpg');background-position: center;background-repeat: no-repeat;background-size: cover;z-index:0;">
 
    <div class="container"><br><br><br><br>
        <div class="section-content">
            <!-- Section Title -->
            <div class="title-wrap mb-5" data-aos="fade-up">
                <h2 class="section-title">
                       <a href="#" style="color:#90EE90">Global Lottery</a>
                </h2>
                <p class="section-sub-title" style="padding:20px;color:#fff">
                    Global Lottery is a platform that includes different types of lotteries from around the world, including digital lotteries and dice lotteries from different countries and regions. We are committed to providing the best lottery experience for users and allowing them to enjoy lottery games from around the world on our platform.
                </p>
            </div>
            <!-- End of Section Title -->
            <div class="row">
                <!-- Features Holder-->

                <div class="container">
                    <div class="row">
                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">1</div>
                            </div>
                            <h4><b style="color:#90EE90">3D Lottery</b></h4>
                            <p style="color:#fff">3D Lottery is a number-based lottery game where players need to predict the order of three numbers. It is the earliest digital lottery in China and one of the most popular lotteries</p>
                        </div>
                      </div>

                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">2</div>
                            </div>
                            <h4><b style="color:#90EE90">5D Lottery</b></h4>
                            <p style="color:#fff">5D Lottery is a number-based lottery game where players need to predict the order of five numbers. It is a relatively new lottery game but has become a favorite of many players.</p>
                        </div>
                      </div>

                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">3</div>
                            </div>
                            <h4><b style="color:#90EE90">11 Choose 5 Lottery</b></h4>
                            <p style="color:#fff">11 Choose 5 Lottery is a number-based lottery game where players need to choose five numbers from 1 to 11. It is a very popular lottery game.</p>
                        </div>
                      </div>

                    </div>
                </div>
            
                <div class="container">
                    <div class="row">
                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">4</div>
                            </div>
                            <h4><b style="color:#90EE90">Mark Six Lottery</b></h4>
                            <p style="color:#fff"> Mark Six Lottery is a number-based lottery game where players need to predict the order of seven numbers. It is one of the most popular lottery games in Asia and also one of the largest lottery games in the world.</p>
                        </div>
                      </div>

                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">5</div>
                            </div>
                            <h4><b style="color:#90EE90">Fast Three Lottery</b></h4>
                            <p style="color:#fff">Fast Three Lottery is a dice-based lottery game where players need to predict the number on three dice. It is a very popular lottery game because of its simple rules and high winning rate.</p>
                        </div>
                      </div>

                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">6</div>
                            </div>
                            <h4><b style="color:#90EE90">Keno Lottery</b></h4>
                            <p style="color:#fff">Keno Lottery is a number-based lottery game where players need to choose 20 numbers from 1 to 80. It is a relatively new lottery game but has become a favorite of many players.</p>
                        </div>
                      </div>

                    </div>
                </div>

                <div class="container">
                    <div class="row">
                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">7</div>
                            </div>
                            <h4><b style="color:#90EE90">PC28 Lottery</b></h4>
                            <p style="color:#fff">PC28 Lottery is a number-based lottery game where players need to predict one or more numbers from the numbers 1 to 28. If their numbers match the winning numbers, they will win the corresponding prize money. PC28 Lottery is a very popular lottery game because of its simple rules and very high odds.</p>
                        </div>
                      </div>

                      <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">8</div>
                            </div>
                            <h4><b style="color:#90EE90">PK10 Lottery</b></h4>
                            <p style="color:#fff">PK10 Lottery is a digital lottery game where players need to predict the order of ten numbers. As a leading player in the lottery industry, PK10 Lottery has unique advantages in rules and odds, and is loved by lottery players.</p>
                        </div>
                      </div>

                      <!-- <div class="col-sm">
                        <div class=" rounded feature-item p-4 mb-4" data-aos="fade-up">
                            <div class="my-6">
                                <div style="width:50px;height:50px;background-image: url('green.png');background-size: cover;text-align: center;line-height: 50px;font-size:25px;fon:bold 20px arial;color:#fff;font-weight: 600;">9</div>
                            </div>
                            <h4><b style="color:#90EE90">Global Lottery</b></h4>
                            <p style="color:#fff"></p>
                        </div>
                      </div> -->

                    </div>
                </div>
              
                <!-- End of Features Holder-->
            </div>
        </div>
    </div>
</section>


<footer class="mastfoot my-3" style="box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 4px 0px inset;">
    <div class="inner container">
         <div class="row">
          <div class="col-lg-4 col-md-12 d-flex align-items-center">
         		
          </div>
          <div class="col-lg-4 col-md-12 d-flex align-items-center">
            <p class="mx-auto text-center mb-0">&copy; 1KBALL UI GAME</p>
          </div>
         	<!-- <div class="col-lg-4 col-md-12 d-flex align-items-center">
         		<p class="mx-auto text-center mb-0">&copy; 2023 1KBALL UI GAME</a></p>
         	</div>
            -->
            <!-- <div class="col-lg-4 col-md-12">
            	<nav class="nav nav-mastfoot justify-content-center">
	                <a class="nav-link" href="#">
	                	<i class="fab fa-facebook-f"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-twitter"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-instagram"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-linkedin"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-youtube"></i>
	                </a>
	            </nav>
            </div> -->
            
        </div>
    </div>
</footer>	<!-- External JS -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
	<script src="vendor/bootstrap/popper.min.js"></script>
	<script src="vendor/bootstrap/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js "></script>
	<script src="vendor/owlcarousel/owl.carousel.min.js"></script>
	<script src="vendor/stellar/jquery.stellar.js" type="text/javascript" charset="utf-8"></script>
	<script src="vendor/isotope/isotope.min.js"></script>
	<script src="vendor/lightcase/lightcase.js"></script>
	<script src="vendor/waypoints/waypoint.min.js"></script>
  <script src="js/aos.js"></script>
	 
	<!-- Main JS -->
	<script src="js/app.min.js "></script>
	<!-- <script src="//localhost:35729/livereload.js"></script> -->
    <script>
        $(function(){
            $(".lmask").removeClass("lmask")
        })
    </script>
</body>
</html>
