<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('display_errors',1);
include "model/user.php";
$user = new User;
$user->AddToLogs("Account Sign Out",date("Y-m-d"),date("H:i:s a"),"UserId " . $_SESSION['sessionId'],$_SESSION['sessionId']);
session_destroy();
header("location:index.php");