<?php
session_start();
$_SESSION['sessionId'] = $_SESSION['holder'];
header("location:home.php");
