<?php
ini_set('display_errors', 1);
//session_start();
include "model/user.php";
$new_user = new User;

$date = $_SESSION['date'];
$gamename = $_POST['gamename'];
$gameid = $_POST['gameid'];
$dataFormat = $_POST['format'];
$new_user->AddToLogs("Download Game Draw Histroy",date("Y-m-d"),date("H:i:s a"),"GameName: " . $gamename . " | GameID: " . $gameid . " | DataFormat: " . $dataFormat . " | DrawDate: " . $date,$_SESSION['sessionId']);
echo "KO";
