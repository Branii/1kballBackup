<?php
//ini_set('display_errors', 1);
session_start();
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}
?>

<!DOCTYPE html>
<html lang="en" oncontextmenu="return falsee">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Change password
  </title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />

  <lnk rel="stylesheet" href="assets/toggle/css/toggles.css">
  <lnk rel="stylesheet" href="assets/toggle/css/themes/toggles-light.css">
 
  <style>
    .nav-item{
      margin-right: 5px;
    }
    .nav-tab:active{
      background-color: red;
    }
   
    pre {
        color: var(--code-color);
        font-size: var(--code-font-size);
        line-height: var(--code-line-height);
        background-color: var(--code-bg-color);
    }

    .code-block {
        max-height: 100px;
        overflow: auto;
        padding: 8px 7px 5px 15px;
        margin: 0px 0px 0px 0px;
        border-radius: 7px;
    }

    /* For Webkit browsers */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background-color: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background-color: red;
  border-radius: 50px;
}

</style>


   <link href="assets/css/nifty.min.css" rel="stylesheet" />

</head>

<body class="g-sidenav-show  bg-gray-100">

<?php include "sidebar.php" ?>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
 
    <div class="container-fluid py-4 px-3" style="border-top:solid 1px #ddd;">
 
      <div class="row">
        <div class="col-12">
          <div class="card border shadow-xs mb-4">
            <div class="card-header border-bottom pb-0">
              <div class="d-sm-flex align-items-center mb-3">
                <div>
                  <h6 class="font-weight-semibold text-lg mb-0">Manage Password</h6>
                  <p class="text-sm mb-sm-0">You can change your password using the form below</p>
                </div>
                <div class="ms-auto d-flex">
                 

                  <!-- <button type="button" class="download recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <span class="btn-inner--icon">
                    <i class='bx bx-plus' style='color:#2f2c2c;font-size:20px;' ></i>
                    </span>
                    <span class="btn-inner--text download">Add New User</span>
                  </button> -->
                </div>
              </div>
            </div>
            
            <div class="card-body px-2 py-0">
            
              <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="nav-home-tab" >
                  
                <div class="form-group">
                  <label for="exampleInputEmail1">Enter Old Password</label>
                  <input type="email" class="form-control" id="oldpass" aria-describedby="emailHelp" placeholder="Enter current password">
                  <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Enter New Password</label>
                  <input type="password" class="form-control" id="newpass1" placeholder="Enter new password">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Re-Enter Password</label>
                  <input type="password" class="form-control" id="newpass2" placeholder="Confirm new password">
                </div>
                
                <button type="submit" class="btn btn-secondary btnsubmit">Submit <i class='bx bx-loader bx-spin spin' style="font-size:20px;display:none;margin-left:10px;"></i> </button>
              
              </div>
              
            </div>
          </div>
        </div>
      </div>
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">

            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start">
                Copyright© <script>
                  document.write(new Date().getFullYear())
                </script>
                Enzerhub
                <a href="#" class="text-secondary" target="_blank">Developers</a>.
              </div>
            </div>

          </div>
        </div>
      </footer>
    </div>
  </main>



  <!--   Core JS Files   -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
<script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>
<script src="assets/js/nifty.min.js"></script>
<script src="assets/js/td-message.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>
  $(document).ready(function() {

    $(".password").addClass("active")

    // trigger the update  function
    $(".btnsubmit").click(function() {
 
      let oldpass = $("#oldpass").val();
      let newpass1 = $("#newpass1").val();
      let newpass2 = $("#newpass2").val();

       // do some validation
       if(oldpass == "" || newpass1 == "" || newpass2 == ""){
        alert("All fields are required");
        return
      }else if(newpass1 != newpass2){
        alert("Passwords do not match, check and try again");
        return
      }else{

        $(".bx-spin").show()

        setTimeout(function(){

        $.post("exec/change_password.php",{
      
          oldpass:oldpass,
          newpass:newpass1
        
        },(data)=>{
          $("#showEdit").nifty("hide");
        alert(data)
        $(".bx-spin").hide()
        //window.location.href = ""

        });

       },1000)

    }

  })

})

</script>

</body>
</html>