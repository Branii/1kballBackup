<?php
ini_set('display_errors', 1);
session_start();
isset($_SESSION['date']) ? $_SESSION['date'] : $_SESSION['date'] = date("Y-m-d");
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    1Kball
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- <link href="assets/css/breadcrumb.css" rel="stylesheet" /> -->
  <!-- CSS Files -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/nifty.min.css">
  <lnk rel="stylesheet" href="assets/toggle/css/toggles.css">
  <lnk rel="stylesheet" href="assets/toggle/css/themes/toggles-light.css">
  <script src="assets/js/jquery.min.js"></script>
  <script>
$(function() {
$(".home").addClass("active")
   //check box for incognito 

    $(".fixed-plugin-button").click(function(){
     $(".fixed-plugin").addClass("show");
    })

    $(".chk").click(function(){
      let status;
      if($(this).is(":checked")){

        
        status = "On" // on
          $.post("exec/authenticator_exec.php",{
            status:status
          },function(data){
              console.log(data)
              alert(data)
          })

      
        
      }else{
    
        status = "Off" // on
          $.post("exec/authenticator_exec.php",{
            status:status
          },function(data){
              console.log(data)
              alert(data)
          })

      }

    })



$("#dateInput").change(function(){
      $.post("datesess.php",{
        dateValue: $(this).val()
      },function(){
          window.location.href = "";
      })
 })

})
</script>


  <style>
    /* Grow */
 .hvr-grow {
    display: inline-block;
    vertical-align: middle;
    transform: translateZ(0);
    box-shadow: 0 0 1px rgba(0, 0, 0, 0);
    backface-visibility: hidden;
    -moz-osx-font-smoothing: grayscale;
    transition-duration: 0.3s;
    transition-property: transform;
}

.hvr-grow:hover,
.hvr-grow:focus,
.hvr-grow:active {
    transform: scale(1.1);
}
  </style>
</head>

<body class="g-sidenav-show  bg-gray-100">

 <?php include "sidebar.php" ?>
  
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
   
  <!-- Navbar -->


    <div class="container-fluid py-4 px-3">
      <div class="row">
        <div class="col-md-12">
          <div class="d-md-flex align-items-center mb-3 mx-2">
            <div class="mb-md-0 mb-3">
              <?php
              include "conf/connect.php";
              $uid = $_SESSION['sessionId'];
              $result = mysqli_query($con,"SELECT username FROM users WHERE uid = '$uid'");
              $row = mysqli_fetch_array($result);
              $username = $row['username'];
              ?>
              <h3 class="font-weight-bold mb-0">Hello, <?=$username?></h3>
              <p class="mb-0">Recent daily draws!</p>
            </div>
            
            <button class="btn btn-sm btn-white btn-icon d-flex align-items-center mb-0 ms-md-auto mb-sm-0 mb-2 me-2">
            <input type="date" id="dateInput" value="<?=$_SESSION['date']?>" style="border:none;background-color:#f7f7f7">
            </button>

            <!-- <button type="button" class="profile fixed-plugin-button btn btn-sm btn-dark btn-icon d-flex align-items-center mb-0">
              <i class='bx bx-user fixed-plugin-button' style='font-size:18px;margin-right:5px'></i>
              <span class="btn-inner--text fixed-plugin-button">Profile</span>
            </button> -->
            <button type="button" class="btn btn-outline-secondary fixed-plugin-button btn-sm" style="margin-top:15px;">Settings</button>
            
          </div>
        </div>
      </div>
      <hr class="my-0">
      <div class="row">
        
      </div><p></p>
     
      <div class="row">
        
        <?php
        // ini_set('display_errors', 1);
        // ini_set('display_startup_errors', 1);
        include "model/games.php";
        $games = new Games;
        $data = $games->FetchAllGames();
       
        $missedCount = 0;
        $todaysDate = $_SESSION['date'];
        foreach($data as  $row){

          $gameid = $row['game_id'];
          $drawTable = "draw_" . $gameid;
          $duration = $row['second_per_issue'];
          $gameName = $row['game_name'];

          $passed = $games->FetchGamePassedCount($drawTable,$todaysDate);
          $totCount = $games->FetchGameDrawCount($duration);

          $missed = $totCount - $passed;
          $TotalCount = $row['total_num_issue'];
          $state = $row['command'];

          if($row['command'] == "start"){
            $status = "<i class='bx bxs-circle' style='font-size:15px;color:green'></i>";
          }else{
            $status = "<i class='bx bxs-circle' style='font-size:15px;color:red'></i>";
          }
          //echo $passed . " " . $totCount;

          ?>

          <div class="col-xl-3 col-sm-6 mb-xl-0 hvr-grow">
          <a href="preview.php?gameid=<?=$gameid?>&duration=<?=$duration?>&gamename=<?=$gameName?>">
          <div class="card border shadow-xs mb-4">
          <div class="card-body text-start p-3 w-100">
          <span class=""><?=$status?></span> | <?=$row['game_id']?></span> | <span class=""><?=$row['game_name']?></span><hr>
            
              <div class="row">
                <div class="col-12">
                  <div class="w-100">
                    <p class="text-sm text-secondary mb-1">TOTAL COUNT: <b><?=$TotalCount;?></b></p>
                    <p class="text-sm text-secondary mb-1">PASSED COUNT: <b><span class="badge border border-success text-success bg-success">
                    <svg width="9" height="9" viewBox="0 0 10 9" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" class="me-1">
                      <path d="M1 4.42857L3.28571 6.71429L9 1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg><?=$passed;?></span></b></p>
                    <p class="text-sm text-secondary mb-1">WAITING COUNT: <b>
                    <span class="badge  border border-warning text-warning bg-warning">
                    <svg width="12" height="12" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="me-1">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                    </svg><?=$missed;?></span></b></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </a>
        </div>

          <?php
        }


         ?>

        
      </div>
    
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start"><hr>
                Copyright
                © <script>
                  document.write(new Date().getFullYear())
                </script>
                <a href="#" class="text-secondary" target="_blank">Enzerhub Developers</a>.
              </div>
            </div>
            <div class="col-lg-6">
              <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                
              </ul>
            </div>
          </div>
        </div>
      </footer>

    </div>
  </main>
  <div class="fixed-plugin">
    <!-- <a class="fixed-plugin-button text-dark position-fixed px-3 py-2">
      <i class="fa fa-cog py-2"></i>
    </a> -->
    <div class="card shadow-lg ">
      <div class="card-header pb-0 pt-3 ">
        <div class="float-start d-flex justify-content-center">
        
          <br>
          
        </div>
        <div class="float-end mt-4">
          <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
            <i class="fa fa-close"></i>
          </button>
        </div>

        <p>Scan this QRCODE to use google authenticator login, the next time.</p>
        <!-- End Toggle Button -->
      </div>
      <hr class="horizontal dark my-1">

      <?php

      require "vendor/autoload.php";
      $google2fa = new \PragmaRX\Google2FA\Google2FA();
      $secret = $google2fa->generateSecretKey();
      //echo $secret;
      $_SESSION['code'] = "X5H73KAO2BZPE3RT";//$secret;
      $email = $_SESSION['email'] ;
      $secret_key = "X5H73KAO2BZPE3RT";//$_SESSION['code'];
      $text = $google2fa->getQRCodeUrl(
      '1kBall.Oauth2',
      @strval($email),
      $secret_key
      );
          
      $image_url = 'https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl='.$text;
      echo '<center><img src="'.$image_url.'" width="250px" height="250px"/></center>';


      include "model/user.php";
      $user = new User;
      $check = $user->CheckAuthen($_SESSION['sessionId']);
      $turner;
      $check == "On" ? $turner = "checked" : $turner = "unchecked";
      
      ?>

    <hr>
    <div class="form-check form-switch ps-0 d-flex justify-content-center" style="padding:10px">

      Turn on Google authenticator<input class="form-check-input mt-1 ms-auto chk" type="checkbox" <?=$turner?>>
     </div>
     <!--sign out-->
     <hr>
     <div class="d-flex justify-content-center" style="padding:10px">
      <a href="signout.php"><button type="button" class="btn btn-secondary btn-sm">Sign Out</button></a>

     </div>
  
    </div>

    

  </div>



  <!-- nifty moda;-->
  <div class="nifty-modal fade-in-scale" id="show" style="">
    <div class="md-content" style="border-radius:10px;width:600px;">
    <div class='md-title' style="background-color:#ddd;border-top-left-radius:10px;border-top-right-radius:10px;">
      <span style="font-size:20px;color:#000;">Bet details<i class='bx bxs-x-circle md-close' style='font-size:30px;color:#bbb;cursor:pointer;position:relative;left:35%;' ></i></span>
      </div>
  
      <div class='md-body' style="border-radius:10px;height:auto;overflow-y:scroll;">
  
      
             <div class="mb-3"><br>
  
            <p>
              Nulla quia sint aut enim quam quam officia accusamus. Cupiditate illo perferendis. Tempora beatae voluptatem odio libero aperiam.
              Nulla quia sint aut enim quam quam officia accusamus. Cupiditate illo perferendis. Tempora beatae voluptatem odio libero aperiam.
              Nulla quia sint aut enim quam quam officia accusamus. Cupiditate illo perferendis. Tempora beatae voluptatem odio libero aperiam.
            </p>
             
            </div>
  
  <div class="modal-footer justify-content-center">

    <button type="button" class="md-close btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
      <span class="btn-inner--text download">OK</span>
    </button>  

  
  </div>
  
        
      </div>
    </div>
  </div>
  <div class="md-overlay"></div>
  <!--   Core JS Files   -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="assets/js/plugins/chartjs.min.js"></script>
  <script src="assets/js/plugins/swiper-bundle.min.js" type="text/javascript"></script>
  <script src="assets/js/nifty.min.js"></script>

  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>

  <!-- Github buttons -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>

  <!--flowBite JS-->
  <!--script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script-->
</body>
</html>