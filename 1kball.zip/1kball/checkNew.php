<?php
include "conf/connect.php";
$drawTable = "draw_" . $_POST['gameid'];
$todaysDate = date("Y-m-d");
$result = mysqli_query($con,"SELECT * FROM $drawTable WHERE date_created = '{$todaysDate}' ORDER BY drawid DESC LIMIT 1");
$row = mysqli_fetch_array($result);
echo $row['draw_count'];
mysqli_close();
