<?php
//ini_set('display_errors', 1);
session_start();
isset($_SESSION['date']) ? $_SESSION['date'] : $_SESSION['date'] = date("Y-m-d");
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}

?>

<!DOCTYPE html>
<html lang="en" oncontextmenu = "return false">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Games
  </title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- <link href="assets/css/td-message.css" rel="stylesheet" /> -->
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
 
  <style>
     .lmask {
            position: absolute;
            height: 100%;
            width: 100%; 
            background-color: #000;
            bottom: 0;
            left: 0;
            right: 0;
            top: 0;
            z-index: 9999;;
            opacity: 0.4;}
            .lmask {
              position: fixed;
            }
            .lmask:before {
              content: '';
              background-color: rgba(0,0,0,0);
              border: 5px solid rgba(0,183,229,0.9);
              opacity: .9;
              border-right: 5px solid rgba(0,0,0,0);
              border-left: 5px solid rgba(0,0,0,0);
              border-radius: 50px;
              box-shadow: 0 0 35px #2187e7;
              width: 50px;
              height: 50px;
              -moz-animation: spinPulse 1s infinite ease-in-out;
              -webkit-animation: spinPulse 1s infinite linear;
          
              margin: -25px 0 0 -25px;
              position: absolute;
              top: 50%;
              left: 50%;
            }
            .lmask:after {
              content: '';
              background-color: rgba(0,0,0,0);
              border: 5px solid rgba(0,183,229,0.9);
              opacity: .9;
              border-left: 5px solid rgba(0,0,0,0);
              border-right: 5px solid rgba(0,0,0,0);
              border-radius: 50px;
              box-shadow: 0 0 15px #2187e7;
              width: 30px;
              height: 30px;
              -moz-animation: spinoffPulse 1s infinite linear;
              -webkit-animation: spinoffPulse 1s infinite linear;
          
              margin: -15px 0 0 -15px;
              position: absolute;
              top: 50%;
              left: 50%;
            }
          
          @-moz-keyframes spinPulse {
            0% {
              -moz-transform:rotate(160deg);
              opacity: 0;
              box-shadow: 0 0 1px #2187e7;
            }
            50% {
              -moz-transform: rotate(145deg);
              opacity: 1;
            }
            100% {
              -moz-transform: rotate(-320deg);
              opacity: 0;
            }
          }
          @-moz-keyframes spinoffPulse {
            0% {
              -moz-transform: rotate(0deg);
            }
            100% {
              -moz-transform: rotate(360deg);
            }
          }
          @-webkit-keyframes spinPulse {
            0% {
              -webkit-transform: rotate(160deg);
              opacity: 0;
              box-shadow: 0 0 1px #2187e7;
            }
            50% {
              -webkit-transform: rotate(145deg);
              opacity: 1;
            }
            100% {
              -webkit-transform: rotate(-320deg);
              opacity: 0;
            }
          }
          @-webkit-keyframes spinoffPulse {
            0% {
              -webkit-transform: rotate(0deg);
            }
            100% {
              -webkit-transform: rotate(360deg);
            }
          }

          
  .bottomright {
  position: fixed;
  right: 0px; 
  bottom: 1px;
  width: 420px;
  height:40px;
  padding: 2px;
  z-index:5000px;
}

.ss{
  margin:5px;
}

.f{
  display:none;
}

  </style>
  
</head>

<body class="g-sidenav-show  bg-gray-100">

<div class='lmask'></div>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

    <div class="container-fluid py-4 px-3" style="border-top:solid 1px #ddd;">
 
      <div class="row">
        <div class="col-12">

        
        
        <div class="card border shadow-xs mb-4 fixed">
         <div class="card-header border-bottom pb-0">
        <div class="d-sm-flex align-items-center">

        <a href='home.php'><button type="button" class="btn btn-lg btn-white me-2"><i class="bx bx-left-arrow-alt" style="font-size:20px;margin-right:5px;"></i>Back</button></a>
        <button type="button" class="btn btn-lg btn-white me-2"><?=$_GET['gamename']?></button> 
        
        <div class="ms-auto d-flex">
        <button type="button" class="btn btn-lg btn-white me-2"><input type="date" id="dateInput" value="<?=$_SESSION['date']?>" style="border:none;background-color:#f7f7f7"></button> 
        <button type="button" class="btn btn-lg btn-white me-2 left"><i class="bx bxs-arrow-to-left" style="font-size:20px;margin-right:5px;"></i></button> 
        <button type="button" class="btn btn-lg btn-white me-2 right"><i class="bx bxs-arrow-to-right" style="font-size:20px;margin-right:5px;"></i></button> 
        <button type="button" class="btn btn-lg btn-white me-2 xls"><i class="bx bx-spreadsheet" style="font-size:20px;margin-right:5px;"></i> Save Excel</button>
        <button type="button" class="btn btn-lg btn-white me-2 pdf"><i class="bx bx-printer" style="font-size:20px;margin-right:5px;"></i> Save PDF </button>
        <button type="button" class="btn btn-lg btn-white me-2 btnp"> <i class="bx bx-printer" style="font-size:20px;margin-right:5px;"></i> Print</button>
      </div>
    </div>
  </div>
  <div class="card-body px-0 py-0">
    <div class="border-bottom py-3 px-3 d-sm-flex align-items-center">
      <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
      

                

    </div>
</div>

      <!-- <div class="input-group w-sm-25 ms-auto">
        <span class="input-group-text text-body">
          <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"></path>
          </svg>
        </span>
        <input type="text" class="form-control" placeholder="Search">
      </div> -->

    </div>

    <div class="table-responsive p-0" id="gamedata" style="margin:25px;">
      
    <table id="example" class="table align-items-center mb-0 table-bordered table-striped">

        <thead class="bg-gray-100">
          <tr>
            <th class="text-center text-xs font-weight-semibold opacity-7">Status</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Draw Count</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Date</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Time</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Number</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Date Created</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Time Get</th>
          </tr>
        </thead>
<?php

//ini_set('memory_limit', '2G');
date_default_timezone_set("Asia/Singapore");
//check user for login
include "./model/draws.php";
$getDraws = new Draws;
$gameid = $_GET['gameid'];
$duration = $_GET['duration'];
$todaysDate = $_SESSION['date'];
$drawTable = "draw_" . $gameid;

//echo $gameid . " " . $duration . " " . $todaysDate . " " . $drawTable;

$data = $getDraws->FetchSpecificDraw($gameid,$todaysDate,$drawTable,$duration,$_SESSION['dataMode']);

        
$missed = 0;
$played = 0;
$counter = 0;
foreach ($data as $key):

    $counter++;
    //global counters
    if($key['draw_date'] == null){
      $missed++;
    }
    if ($key['count'] != null) {
      $played++;
    }

    $style = "";
    $info = "";
    $draw_date = "";
    $draw_time = "";
    $draw_number = "";
    $date_created = "";
    $client = "";

    if($key['draw_date'] == null){
      $key['draw_date']  = "<span style='color:#ccc;'>---</span>";
      $draw_date = "null";
    }
    if($key['draw_time'] == null) {
      $draw_time  = "null";
    }
    if ($key['draw_number'] == null) {
      $draw_number = "null";
    }
    if ($key['date_created'] == null) {
      $date_created = "null";
    }
    if ($key['client'] == null) {
      $client = "null";
    }

    if($key['count'] != null && $client == "null"){

      $style = "rgb(253,240,238,0.7)";
      $info = '<span class="badge badge-sm border border-primary text-primary bg-primary">
      <i class="bx bx-loader-alt bx-spin"></i> Waiting </span>';

      $key['draw_date']  = "<span style='color:#257CFD;'>---</span>";
      $key['draw_time']  = "<span style='color:#257CFD;'>---</span>";
      $key['draw_number']  = "<span style='color:#257CFD;'>---</span>";
      $key['date_created']  = "<span style='color:#257CFD;'>---</span>";

    }
    
    if($draw_date != "null" && $draw_time != "null" && $draw_number != "null" && $client != "null"){
      $style = "rgb(0,174,85,0.1)";
      $info = '<span class="badge badge-sm border border-success text-success bg-success">
      <svg width="9" height="9" viewBox="0 0 10 9" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" class="me-1">
        <path d="M1 4.42857L3.28571 6.71429L9 1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
      </svg> Success </span>';
      
    }
    
    if($draw_date === "null" && $key['count'] < $lastRowCount){
      $style = "rgb(252,0,62,0.1)";
      $info = '<span class="badge badge-sm border border-danger text-danger bg-danger">
      <b><i class="bx bx-x" style="color:#da1f1f;"></i></b> Missed </span>';
      
      $key['draw_date']  = "<span style='color:red;'>---</span>";
      $key['draw_time']  = "<span style='color:red;'>---</span>";
      $key['draw_number']  = "<span style='color:red;'>---</span>";
      $key['date_created']  = "<span style='color:red;'>---</span>";
    }

    $draw_date = "";
    $draw_time = "";
    $draw_number = "";
    $date_created = "";
    $client = "";
  
    //draw state

    ?>
      <tr style='background-color:<?=$styles?>'>
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$info?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['count']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><b  style="color:black"><?=$key['draw_date']?></b></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_time']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_number']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['date_created']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><span class="badge badge-sm border border-secondary text-secondary bg-secondary"><?=$key['get_time']?></span></td> 
     </tr>
    <?php
   endforeach;

?>
 </tbody>
</table>
</div>

    <div class="border-top py-3 px-3 d-flex align-items-center">
      <p class="font-weight-semibold mb-0 text-dark text-sm">..</p>
      <div class="ms-auto">
        <!-- <button class="btn btn-sm btn-white mb-0">Previous</button>
        <button class="btn btn-sm btn-white mb-0">Next</button> -->
      </div>
    </div>
  </div>
</div>

  </div>
    </div>
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start">
                Copyright
                © <script>
                  document.write(new Date().getFullYear())
                </script>
                Enzerhub
                <a href="#" class="text-secondary" target="_blank">Developers</a>.
              </div>
            </div>
  
          </div>
        </div>
      </footer>
    </div>
  </main>

  <a class="f" style="border:solid 2px #1c1e1f;">
  <i class="bi bi-list"></i>
  </a>
  
  <div class="fixed-plugin">

    <!-- <a class="" style="border:solid 2px #1c1e1f;">
    <i class="bi bi-list"></i>
    </a> -->

    
    <div class="card shadow-lg ">
      <div class="card-header pb-0 pt-3 ">
        <div class="float-start">
          <h5 class="mt-3 mb-0">Other Available Games</h5>
          <p>See today's draw history</p>
        </div>
        <div class="float-end mt-4">
          <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
            <i class="fa fa-close"></i>
          </button>
        </div>
        <!-- End Toggle Button -->
      </div>
      <div class="card-body pt-sm-3 pt-0" style="overflow-y:scroll;">
        <!-- Sidebar Backgrounds -->
        <ul class="list-group" style="">
        <?php
        include "model/games.php";
        $games = new Games;
        $data = $games->FetchAllGames();
        $missedCount = 0;
        foreach($data as  $row){
          ?>

          <a style="text-decoration:none;" href="preview.php?gameid=<?=$row['game_id']?>&duration=<?=$row['second_per_issue']?>&gamename=<?=$row['game_name'];?>"><li class="list-group-item striped" style="cursor:pointer;width:100%;">
          <?=$row['game_name']?>
          </li></a>

          <?php
        }
        ?>
        </ul>
        
        
      </div>
    </div>
  </div>

  <div class="bottomright" style="border-top-left-radius:10px;">
  <button type="button" class="btn miss ss btn-secondary">Show Missed</button>
  <button type="button" class="btn auto ss btn-secondary">Auto Refresh <i class='bx bx-check-circle ldr' style='display:none'></i></button>
  <button type="button" class="btn ss btn-secondary fixed-plugin-button position-fixed px-3 py-2">All Games</button>
  </div>


  <!--   Core JS Files   -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <!-- <script src="assets/js/core/popper.min.js"></script> -->
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
<script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>
<!-- <script src="assets/js/td-message.min.js"></script> -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>


  <script src="assets/js/jspdf.min.js"></script>
  <script src="assets/js/jspdf.plugin.autotable.min.js"></script>
  <script src="assets/js/jquery.table2ecxel.js"></script>

<script>
  $(document).ready(function() {

    //check
    //console.log("data: "  + localStorage.getItem("miss"));
    if(localStorage.getItem("miss")  == "on"){
      $(".miss").text("Hide Missed")
    }else{
      $(".miss").text("Show Missed")
    }

    const duration  = "<?=$_GET['duration']?>";
    //console.log(duration)

      setInterval(function(){

        if(localStorage.getItem("auto") == "on"){
        $(".ldr").show()

        let currentTime = new Date();
        let currentSecond = currentTime.getSeconds();
        console.log(currentSecond)
        
        duration == "60" && currentSecond == "0" ? window.location.href = "" : 
        duration == "90" && currentSecond == "0" ? window.location.href = "" : 
        duration == "180" && currentSecond == "0" ? window.location.href = "" : 
        duration == "300" && currentSecond == "0" ? window.location.href = "" : 
        duration == "600" && currentSecond == "0" ? window.location.href = "" : "";

      }else{
      localStorage.setItem("auto","off")
      $(".ldr").hide()
      }

      },1000);

    $(".auto").click(function(){
      $(".ldr").is(":visible") 
      ? (localStorage.setItem("auto","off"), $(".ldr").hide()) 
      : (localStorage.setItem("auto","on"), $(".ldr").show());
    })


    $(".miss").click(function(){

     if($(this).text() == "Show Missed"){
      $(".miss").text("Hide Missed")
      localStorage.setItem("miss","on");
      $.post("option.php",{
        state:"showMiss"
      },function(data){
        window.location.href =""
      })
     }else{
      localStorage.setItem("miss","off");
      $(".miss").text("Show Missed")
      console.log(localStorage.getItem("miss"))
      $.post("option.php",{
        state:"hideMiss"
      },function(data){
        window.location.href =""
      })
     }
     
     
      
    })

    // setTimeout(function() {
    //             console.log('Page has finished loading');
                $(".lmask").removeClass("lmask");
    //        },2000);

    $('.left').click(function(){
      let dateValue = $("#dateInput").val();
      let currentDate = new Date(dateValue)
      let newDate = new Date(currentDate.getTime() - 24*60*60*1000)
      $("#dateInput").val(newDate.toISOString().slice(0,10))
      $.post("datesess.php",{
        dateValue: newDate.toISOString().slice(0,10)
      },function(){
        window.location.href = "";
      })
    })

    $('.right').click(function(){
      let dateValue = $("#dateInput").val();
      let currentDate = new Date(dateValue)
      let newDate = new Date(currentDate.getTime() + 24*60*60*1000)
      $("#dateInput").val(newDate.toISOString().slice(0,10))
      $.post("datesess.php",{
        dateValue: newDate.toISOString().slice(0,10)
      },function(){
          window.location.href = "";
      })
    })

    $("#dateInput").change(function(){
      $.post("datesess.php",{
        dateValue: $(this).val()
      },function(){
          window.location.href = "";
      })
    })

    $('.pdf').click(function(){

      let gamename = "<?= $_GET['gamename']?>";
      let gameid = "<?= $_GET['gameid']?>";

      $.post("logprint.php",{

        gamename:gamename,
        gameid:gameid,
        format:"Pdf"

      },function(data){

        var doc = new jsPDF()   
    doc.autoTable({ html: '#example' })
    doc.save(gamename+ '.pdf')

      })

   
    })

    $(".xls").click(function(){
   
      let gamename = "<?= $_GET['gamename']?>";
      let gameid = "<?= $_GET['gameid']?>";

      $.post("logprint.php",{

        gamename:gamename,
        gameid:gameid,
        format:"xls"

      },function(data){

        $("#example").table2excel({
        exclude: ".excludeThisClass",
        name: "1Kball Game",
        filename: gamename + ".xls", 
        preserveColors: false 
        });

      })

    })


    $('.btnp').click(function(){

      let gamename = "<?= $_GET['gamename']?>";
      let gameid = "<?= $_GET['gameid']?>";

      $.post("logprint.php",{

        gamename:gamename,
        gameid:gameid,
        format:"txt"

      },function(data){

        alert(data)

        $(".header").hide();
    $("#datt").show();
    $('.btnp').hide();
    $('.pdf').hide();
    $('.xls').hide();
    $('.btnback').hide();
    print();
    $(".header").show();
    $("#datt").hide();
    $('.btnp').show();
    $('.pdf').show();
    $('.xls').show();
    $('.btnback').show();

      })
    
    })
  

    // setInterval(() => {
    //   let gameid = "<?=$_GET['gameid'];?>";
    //   $.post("checkNew.php",{
    //     gameid:gameid
    //   },function(result){
    //     console.log(result);
    //     if(localStorage.getItem("count") == result){
    //       //console.log("waiting")
    //     }else{
    //       localStorage.setItem("count",result);
    //       window.location.href = "";
    //     }
        
    //   })
    // }, 50000);


  })
</script>

</body>
</html>