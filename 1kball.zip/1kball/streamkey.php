<?php
ini_set('display_errors', 1);
session_start();
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    1kball
  </title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />

  <lnk rel="stylesheet" href="assets/toggle/css/toggles.css">
  <lnk rel="stylesheet" href="assets/toggle/css/themes/toggles-light.css">
 
  <style>
    
    #keyholder{
    height:50px;
    border-radius:5px;
    background-color:whitesmoke;
    }

    .code-block {
        max-height: 100px;
        overflow: auto;
        padding: 8px 7px 5px 15px;
        margin: 0px 0px 0px 0px;
        border-radius: 7px;
    }

    /* For Webkit browsers */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background-color: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background-color: red;
  border-radius: 50px;
}

</style>


   <link href="assets/css/nifty.min.css" rel="stylesheet" />

</head>

<body class="g-sidenav-show  bg-gray-100">

<?php include "sidebar.php" ?>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
 
    <div class="container-fluid py-4 px-3" style="border-top:solid 1px #ddd;">
 
      <div class="row">
        <div class="col-12">
          <div class="card border shadow-xs mb-4">
            <div class="card-header border-bottom pb-0">
              <div class="d-sm-flex align-items-center mb-3">
                <div>
                  <h6 class="font-weight-semibold text-lg mb-0">Streaming keys</h6>
                  <p class="text-sm mb-sm-0">List of game keys</p>
                </div>
                <div class="ms-auto d-flex">
                  <button type="button" class=" recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <?php
                    include "model/games.php";
                    $keyCounter = (new Games)->FetchAllStreamKeys();
                    ?>
                    <span class="btn-inner--text ">Total Keys: <?=count($keyCounter)?> </span>
                  </button>

                  <button type="button" class="download recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <span class="btn-inner--icon">
                    <i class='bx bx-plus' style='color:#2f2c2c;font-size:20px;' ></i>
                    </span>
                    <span class="btn-inner--text download">Generate Keys</span>
                  </button>
                </div>
              </div>
            </div>
            
            <div class="card-body px-2 py-0">
            
              <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="nav-home-tab" >
                  
                  
                   <div class="table-responsive p-0">
                <table class="table align-items-center justify-content-center mb-0 table-bordered table-striped">
                  <thead class="bg-gray-100">
                    <tr>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">#NO</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game ID</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game Name</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game Hash</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Rtmp Url</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Stream Key</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Date Added</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php
                  //require_once "model/games.php";
                   $fetchObject = new Games;
                   $data = $fetchObject->FetchAllStreamKeys();
                
                    $counter = 0;
                    foreach($data as $row):
                    $counter++;
                    
                    //$game_hasgh = strlen($row["game_hash"]) > 15 ? substr($row["game_hash"],0,15)."..." : $row["game_hash"];
                  

                    ?>
                        <tr class="datarow">
                          <td><?=$counter?>
                          <input type="hidden" class="id" value="<?=$row["sid"]?>">
                
                          </td>
                          <td><?=$row["gameid"]?></td>
                          <td><?=$row["gamename"]?></td>
                          <td><?=$row["gamehash"]?></td>
                          <td><?=$row["gameurl"]?></td>
                          <td><?=$row["streamkey"]?></td>
                          <td><?=$row["dated"]?></td>

                          <td>
                          <button type="button" class="btn btn-white btn-icon px-2 py-2 delbtn">
                          <i class='bx bxs-trash' style='color:#2f2c2c'  ></i>
                          </button>
                          </td>
                        </tr>
                    <?php

                   endforeach;

                  ?>
           
                  </tbody>
                </table>

                
                    </div>
             

                </div>

              <div class="border-top py-3 px-3 d-flex align-items-center">
                <!-- <button class="btn btn-sm btn-white d-sm-block d-none mb-0">Previous</button>
                <nav aria-label="..." class="ms-auto">
                  <ul class="pagination pagination-light mb-0">
                    <li class="page-item active" aria-current="page">
                      <span class="page-link font-weight-bold">1</span>
                    </li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">2</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold d-sm-inline-flex d-none" href="javascript:;">3</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">...</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold d-sm-inline-flex d-none" href="javascript:;">8</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">9</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">10</a></li>
                  </ul>
                </nav>
                <button class="btn btn-sm btn-white d-sm-block d-none mb-0 ms-auto">Next</button> -->
              </div>
              
            </div>
          </div>
        </div>
      </div>
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">

            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start">
                Copyright© <script>
                  document.write(new Date().getFullYear())
                </script>
                Enzerhub
                <a href="#" class="text-secondary" target="_blank">Developers</a>.
              </div>
            </div>

          </div>
        </div>
      </footer>
    </div>
  </main>
  
 

   <!-- nifty moda;-->
   <div class="nifty-modal fade-in-scale" id="showDel" style="">
    <div class="md-content" style="border-radius:10px;width:600px;">
    <div class='md-title' style="background-color:#ddd;border-top-left-radius:10px;border-top-right-radius:10px;">
      <span style="font-size:20px;color:#000;">Delete stream key<i class='bx bxs-x-circle md-close' style='font-size:25px;color:#bbb;cursor:pointer;position:relative;left:30%;'></i></span>
      </div>
  
      <div class='md-body' style="border-radius:10px;height:auto;overflow-y:scroll;">
                   <input type="hidden" class="delid">
        <div class="mb-3 d-flex justify-content-center"><br>
        <i class='bx bx-trash' style='color:#aaa;font-size:30px;position:relative;right:10px;top:10px;'></i>
      <p>
        This stream key will be permanently removed from this system and can no longer be used for streaming.
        Please do you really wants to delete this key?
      </p>
        
      </div>
  
   <div class="modal-footer justify-content-center">


    <button type="button" class="md-close btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2"  style="position:relative;left:25%;">
      <span class="btn-inner--text cancel text-success">No, Cancel</span>
    </button>  

    <button type="button" class="delete btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
      <span class="btn-inner--text text-danger">Yes, Delete <i class='bx bx-loader bx-spin dll' style="font-size:20px;display:none;"></i></span>
    </button>  

  
  </div>
  
        
      </div>
    </div>
  </div>
  <div class="md-overlay"></div>

  <!-- nifty moda;-->
  <div class="nifty-modal fade-in-scale" id="showAdd">
    <div class="md-content" style="border-radius:10px;width:600px;"> 
    <div class='md-title' style="background-color:#ddd;border-top-left-radius:10px;border-top-right-radius:10px;">
      <span style="font-size:20px;color:#000;">Generate keys<i class='bx bxs-x-circle md-close' style='font-size:25px;color:#bbb;cursor:pointer;position:relative;left:35%;' ></i></span>
    </div>
  
      <div class='md-body' style="border-radius:10px;max-height:500px;overflow-y:scroll;">
  
      
             <div class="mb-3"><br>
  
              <form>
                
                <div class="form-group">
                  <label for="exampleInputPassword1">Select Game</label>
                  <select type="text" class="form-control games" id="">
                  <?php
                    require_once "model/games.php";
                    $allGames = new Games;
                    $data = $allGames->FetchAllGames();
                    foreach ($data as $row):
                    ?>
                        <option value='<?=$row['game_id'] . "#" . $row['game_name'] ;?>'><?='['.$row['game_id'].'] '.$row['game_name'];?></option>
                    <?php
                    endforeach;
                    ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Stream Key</label>
                  <div class="form-control" id="keyholder"></div>
                </div>

              </form>
            </div>

      </div>

      <div class='md-footer d-flex justify-content-center' style="background-color:#fff;border-bottom-left-radius:10px;border-bottom-right-radius:10px;box-shadow: rgba(0, 0, 0, 0.08) 0px 1.5px 1px 0px inset;">
       
        <button type="button" class="savegame btn btn-sm" style="border:solid 1px #aaa">
          <span class="btn-inner--text">Generate<i class='bx bx-loader bx-spin' style="font-size:15px;display:none;"></i></span>
        </button>

      </div>

    </div>
  </div>
  <div class="md-overlay"></div>


  <!--   Core JS Files   -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
<script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>
<script src="assets/js/nifty.min.js"></script>
<script src="assets/js/td-message.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>
  $(document).ready(function() {

    $(".streamkey").addClass("active")

    // trigger the del function
    $(".delete").click(function() {
      let keyid = $(".delid").val()

      let deleteThis = $(this).closest("tr")
      $(".dll").show();
      $.post("exec/delete_key.php",{
        keyid:keyid
      },function(data){
        $("#showDel").nifty("hide");
        alert(data)
        $(".dll").hide();
        window.location.href = ""
      })
    })

    // trigger the del modal
    $(".delbtn").click(function() {
      $(".delid").val($(this).closest("tr").find(".id").val());
      $("#showDel").nifty("show");
    })

    // trigger the add modal
    $(".download").click(function() {
      $("#showAdd").nifty("show");
    })

    // trigger the edit modal
    $(".games").change(function() {
        $("#keyholder").html("")
    })


    $(".savegame").click(()=>{
      //get all the values from the form

      let gameinfo = $(".games").val();
      let spil = gameinfo.split("#");
      let gameid = spil[0];
      let gamename = spil[1];

      // do some validation
      $(".bx-spin").show()

    setTimeout(function(){

    $.post("exec/add_streamkey.php",{
    
        gameid:gameid,
        gamename:gamename
    
    },(data)=>{
        $("#keyholder").html(data)
    $(".bx-spin").hide()

    });

    },1000)
      
   })

})

</script>

</body>
</html>