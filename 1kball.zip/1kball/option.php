<?php
session_start();
$state = $_POST['state'];
$_SESSION['dataMode'] = $state;