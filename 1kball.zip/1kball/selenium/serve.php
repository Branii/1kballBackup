<?php
ini_set('display_errors',1);
require "../model/draws.php";
$clientData = file_get_contents("php://input");
$data = json_decode($clientData,true);
$TableName = $data['TableName'];
$DrawDate = $data['DrawDate'];
$DrawTime = $data['DrawTime'];
$DrawNumber = $data['DrawNumber'];
$DrawCount = $data['DrawCount'];
$DateCreated = $data['DateCreated'];
$DrawGet = $data['DrawGet'];
$Client = "box";
(new Draws())->insertDraws($TableName,$DrawDate,$DrawTime,$DrawNumber,$DrawCount,$DateCreated,$Client,$DrawGet);