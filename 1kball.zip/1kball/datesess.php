<?php
session_start();
$_SESSION['date'] = $_POST['dateValue'];