<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="1">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php
date_default_timezone_set("Asia/Shanghai");
$date = new DateTime();

$xplode = explode(":", $date->format("H:i:s"));

//echo $xplode[0] . ":" . $xplode[1]-10 . ":" . ($xplode[2]);

echo date("H:i:s");

// $serverDateTime = new DateTime();

// $userTimezone = new DateTimeZone('Asia/Shanghai');

// $userDateTime = $serverDateTime->setTimezone($userTimezone);

// $xplode = explode(":", $userDateTime->format("H:i:s"));

// echo $xplode[0] . ":" . $xplode[1] . ":" . ($xplode[2]);