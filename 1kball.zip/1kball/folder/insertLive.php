<?php

error_reporting(E_ALL);
ini_set('display_errors', 'On');

require_once "model.php";
$model = new model();

$gameid = $_GET['gameid'];
$gentype = $_GET['gentype'];
$duration = $_GET['duration'];
$server  = "box";
$drawTable = "draw_" . $gameid;

//echo $gameid . " " . $gentype . " " . $duration  . " " .$server. " " . $drawTable;
//"10001","5d","server","60"
//exit;

$model->insertLive($gameid,$gentype,$server,$duration,$drawTable);

