
<?php

require_once "Conf.php";
class model extends Conf{

	private $str_drawNumber;
	private $CurrentHour;
	private $CurrentMin;
	private $str_drawCount;
	private $str_drawTime;
	private $str_drawDate;
	private $str_nowdate;

	// public function __construct(){
	// 	echo "hello";
	// }

#get category
public function getCategoy(){
	try {
		$sql = "SELECT catid,category_name FROM game_category";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		echo $data['catid'] . "#" . $data['category_name'];
		$this->close();
	} catch (\Throwable $th) {
		echo $th;
	}
}

#observer custom method
public function observe($hash){
	try {
		$sql = "SELECT command,second_per_issue,rand_num_type,notify FROM games WHERE game_hash = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindParam(1,$hash);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		echo $data['command'] . "#" . $data['second_per_issue']. "#" . $data['rand_num_type'] . "#" . $data['notify'];
		$this->close();
	} catch (\Throwable $th) {
		echo $th;
	}
}

public function observeVideo($gameid){
	try {
		$sql = "SELECT game_hash,command,second_per_issue,notify,rand_num_type,game_hash,sessionId FROM games WHERE game_id = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindParam(1,$gameid);
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_ASSOC);
		//echo $data['command'] . "#" . $data['second_per_issue']. "#" . $data['notify']. "#" . $data['rand_num_type']. "#" . $data['game_hash']. "#" . $data['sessionId'];
		echo $data['command'] . "#"  . $data['notify']. "#"  . $data['sessionId'];
		
		$this->close();
	} catch (\Throwable $th) {
		echo $th;
	}
}

//get random draw numbmes
public function GetDraw($hash,$drawTable){
	try {
		$sql = "SELECT game_hash,draw_number,draw_date,draw_count FROM $drawTable WHERE game_hash = :game_hash ORDER BY drawid DESC LIMIT 1";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindParam(":game_hash",$hash);
		$stmt->execute();
		$data = $stmt->fetch();
		if($stmt->rowCount() > 0){
			echo $data['draw_number'] . "#" . $data['draw_date'] . "#" . $data['draw_count'];
		}else{
			echo "No data";
		}
		$this->close();
	} catch (\Throwable $th) {
		echo $th;
	}
}

//add game channel to session
public function addSession($gamehash){

	try {

		$sql = "UPDATE games SET sessionId = :sessionId WHERE game_hash = :game_hash";

		$stmt = $this->connect()->prepare($sql);
		$stmt->bindValue(":sessionId","online");
		$stmt->bindValue(":game_hash",$gamehash);
		if($stmt->execute()){
			echo "Session Saved Successfully";
		}else{
			echo "Some error occured";
		}

		$this->close();

	} catch (\Throwable $th) {

		echo $th;

	}

}

//del game channel from session
public function delSession($gamehash){

	try {

		$sql = "UPDATE games SET sessionId = :sessionId WHERE game_hash = :game_hash";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindValue(":sessionId","offline");
		$stmt->bindValue(":game_hash",$gamehash);
		if($stmt->execute()){
		echo "Session deleted Successfully";
		}else{
		echo "some error occured";
		}

		$this->close();

	} catch (\Throwable $th) {

		echo $th;

	}

}

//check if draw number exist;
public function checkDraws($drawTable,$drawDate,$drawTime){

	try {

		$sql = "SELECT * FROM $drawTable WHERE draw_date = :draw_date AND draw_time = :draw_time";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindValue(":draw_date",$drawDate);
		$stmt->bindValue(":draw_time",$drawTime);
		$stmt->execute();
		if($stmt->rowCount() > 0){
			return "exist";
		}else{
			return "clean";
		}
		$this->close();

	} catch (\Throwable $th) {

		echo $th;

	}

}

//get video game hash code
public function GetGameHash($gamehash,$show){
	try {
		$sql = "SELECT id, game_hash, game_hash, notify FROM games WHERE game_hash = :game_hash AND notify = :notify ORDER BY id DESC LIMIT 1";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindParam(":game_hash",$gamehash);
		$stmt->bindParam(":notify",$show);
		$stmt->execute();
		$data = $stmt->fetch();
		if($stmt->rowCount() > 0){
			echo $data['game_hash'];
		}else{
			echo "notfound";
		}
		$this->close();
	} catch (\Throwable $th) {
		echo $th;
	}
}

//insert into draw table after game draw animation
public function insert($gameid,$drawDate,$drawTime,$drawNumber,$drawCount,$client,$drawTable){
	//exit;
	date_default_timezone_set("Asia/Shanghai");

	$sql = "SELECT * FROM games WHERE game_id = :game_id AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
	$stmt = $this->connect()->prepare($sql);
	$stmt->bindValue(":game_id",$gameid);
	$stmt->bindValue(":command","start");
	$stmt->bindValue(":notify","show");
	$stmt->bindValue(":sessionId","online");
	$stmt->execute();

	if($stmt->rowCount() > 0){

	$str_nowTime = date("H:i:s");
	$str_nowDate = date("Y-m-d");
	$sql = "SELECT draw_count,draw_date,draw_time FROM $drawTable WHERE draw_count = ? AND draw_date = ? AND draw_time = ? LIMIT 1";
	$stmt = $this->connect()->prepare($sql);
	$stmt->bindParam(1,$drawCount);
	$stmt->bindParam(2,$drawDate);
	$stmt->bindParam(3,$drawTime);
	$stmt->execute();

	if($stmt->rowCount() > 0){
		echo "exist";
		exit;
	}else{

	$sql = "INSERT IGNORE INTO $drawTable(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)VALUES(?,?,?,?,?,?,?)";
	$stmt = $this->connect()->prepare($sql);
	$stmt->bindParam(1,$drawDate);
	$stmt->bindParam(2,$drawTime);
	$stmt->bindParam(3,$drawNumber);
	$stmt->bindParam(4,$drawCount);
	$stmt->bindParam(5,$str_nowDate);
	$stmt->bindParam(6,$client);
	$stmt->bindParam(7,$str_nowTime);
	if($stmt->execute()){
		echo "Inserted";
	}else{
		echo "Not Inserted";
	}
	$this->close();
	$this->closes();
	exit;
	}

	}else{
		//do not double insert draw record
		exit;
	}

	
}

//get random draw numbmes
public function getGameDraw($genType,$hash,$duration,$javaTime,$gameid){

	date_default_timezone_set('Asia/Singapore');

    switch ($genType) {

		case '5d':{#----------------------------------5d auto gen----------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			
			if($stmtt->rowCount() > 0){
			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();

			if($stmt->rowCount() > 0){

			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];
			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$number = str_shuffle(rand(00000,99999));
			$length = 5;
			$string = substr(str_repeat(0, $length).$number, - $length);
			$this->str_drawNumber = sprintf("%05d", $string);
			$numArr = str_split($this->str_drawNumber);
			$drawNumber = implode(",",$numArr);

			//include "../folder/Connection.php";
		    //mysqli_query($con,"INSERT INTO listing (gameId,datee,timee,numberr)VALUES('10001','$drawDate','$drawTime','$drawNumber')");
			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;

			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{
			echo "0#0#0#0#0#0";
			}

			}else{
			echo "0#0#0#0#0#0";
			}

			

			break;
		}

		case '3d':{#-------------------------------3d auto gen-------------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			if($stmtt->rowCount() > 0){

			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();
			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];

			if($stmt->rowCount() > 0){

			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$number = str_shuffle(rand(000,999));
			$length = 3;
			$string = substr(str_repeat(0, $length).$number, - $length);
			$this->str_drawNumber = sprintf("%03d", $string);
			$numArr = str_split($this->str_drawNumber);
			$drawNumber = implode(",",$numArr);

			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;
			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{
			echo "0#0#0#0#0#0";
			}
		}else{
			echo "0#0#0#0#0#0";
		}

			break;
		}


		case 'fast_3':{#-----------------------------------fast_3 auto gen---------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			if($stmtt->rowCount() > 0){

			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();
			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];

			if($stmt->rowCount() > 0){

			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$ArrNumber = array("1","2","3","4","5","6");
			shuffle($ArrNumber);
			$drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2];

			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;
			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{
			echo "0#0#0#0#0#0";
			}
		}else{
			echo "0#0#0#0#0#0";
		}

			break;
		}


		case 'pc_28':{#-----------------------------------pc_28 auto gen---------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			if($stmtt->rowCount() > 0){

			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();
			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];

			if($stmt->rowCount() > 0){

			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$number = str_shuffle(rand(000,999));
			$length = 3;
			$string = substr(str_repeat(0, $length).$number, - $length);
			$this->str_drawNumber = sprintf("%03d", $string);
			$numArr = str_split($this->str_drawNumber);
			$drawNumber = implode(",",$numArr);

			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;
		
			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{ 
			echo "0#0#0#0#0#0";
			}
		}else{
			echo "0#0#0#0#0#0";
		}

			break;
		}


		case 'pk_10':{#---------------------------------pk_10 auto gen-----------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			if($stmtt->rowCount() > 0){

			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();
			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];

			if($stmt->rowCount() > 0){

			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$ArrNumber = array("1","2","3","4","5","6","7","8","9","10");
			shuffle($ArrNumber);
			$drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6] . "," . $ArrNumber[7] . "," . $ArrNumber[8] . "," . $ArrNumber[9];

			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;
			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{
			echo "0#0#0#0#0#0";
			}
		}else{
			echo "0#0#0#0#0#0";
		}

			break;
		}

		case '11x5':{#----------------------------------11x5 auto gen----------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			if($stmtt->rowCount() > 0){

			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();
			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];

			if($stmt->rowCount() > 0){

			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$ArrNumber = array("01","02","03","04","05","06","07","08","09","10","11");
			shuffle($ArrNumber);
			$drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4];

			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;
			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{
			echo "0#0#0#0#0#0";
			}
		}else{
			echo "0#0#0#0#0#0";
		}

			break;
		}

		case '47x9':{#----------------------------------47x9 auto gen----------------------------------------#

			$timerTbl = "";
			if($duration == "60"){
				$timerTbl = "time1x0";
			}elseif($duration == "90"){
				$timerTbl = "time1x5";
			}elseif($duration == "180"){
				$timerTbl = "time3x0";
			}elseif($duration == "300"){
				$timerTbl = "time5x0";
			}elseif($duration == "600"){
				$timerTbl = "time10x0";
			}

			$sqll = "SELECT * FROM games WHERE game_hash = :game_hash AND command = :command AND notify = :notify AND sessionId = :sessionId LIMIT 1";
			$stmtt = $this->connect()->prepare($sqll);
			$stmtt->bindValue("game_hash",$hash);
			$stmtt->bindValue("command","start");
			$stmtt->bindValue("notify","show");
			$stmtt->bindValue("sessionId","online");
			$stmtt->execute();
			if($stmtt->rowCount() > 0){

			
			$sql = "SELECT id,count,timeset FROM $timerTbl WHERE timeset = :timeset ORDER BY id DESC LIMIT 1";
			$stmt = $this->conn()->prepare($sql);
			$stmt->bindParam(":timeset",$javaTime);
			$stmt->execute();
			$data = $stmt->fetch();
			$getCount =  $data['count'];
			$TheTimer =  $data['timeset'];

			if($stmt->rowCount() > 0){

			$drawTime   = $TheTimer;
			$drawDate   = date("Ymd") . $getCount;
			$str_nowdate   = date("Y-m-d");
			$drawCount = $getCount;

			$ArrNumber = array("01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49");
			shuffle($ArrNumber);
			$drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6];

			echo $drawNumber . "#" . $drawDate . "#" . $drawCount . "#" . $drawTime . "#" . $hash . "#" . $gameid;
			//echo "1 row inserted";
			$this->close();
			$this->closes();
			}else{
			echo "0#0#0#0#0#0";
			}
		}else{
			echo "0#0#0#0#0#0";
		}

		break;
		}

	}
    
  }

}

