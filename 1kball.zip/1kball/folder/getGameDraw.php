<?php
error_reporting(E_ERROR | E_PARSE);
require_once "model.php";
$model = new model();
$gentype = $_GET['gentype'];

//echo $gentype;
$model->getGameDraw("5d");
