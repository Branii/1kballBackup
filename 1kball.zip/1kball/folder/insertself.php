<?php

require_once "model.php";
$model = new model();

$gameid = $_GET['gameid'];
$gentype = $_GET['gentype'];
$duration = $_GET['duration'];
$server  = "server";
$drawTable = "draw_" . $gameid;

//echo $gameid . " " . $gentype . " " . $duration  . " " .$server;
//"10001","5d","server","60"
//exit;

$model->insert($gameid,$gentype,$server,$duration,$drawTable);
