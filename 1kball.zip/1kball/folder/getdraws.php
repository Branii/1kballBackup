<?php
//ini_set('display_errors',1);
require_once "model.php";
require_once "../conf/connect.php";
$model = new model();

$gameHash = $_GET['gameHash'];
$javaTime = $_GET['time'];
$rr = mysqli_query($con,"SELECT * FROM games WHERE game_hash = '{$gameHash}'");
$rows = mysqli_fetch_array($rr);
$genType = $rows['rand_num_type'];
$hash = $rows['game_hash'];
$duration = $rows['second_per_issue'];
$gameId = $rows['game_id'];

//echo $genType . "#" . $hash . "#" . $duration . "#" . "" . "#" . "";
//execute the get game draw method
//$model->GetGameDraw("5d","8b3fb44d4bc2d5c5d8cd25891ba6e32c1","60");
$model->GetGameDraw($genType,$hash,$duration,$javaTime,$gameId);