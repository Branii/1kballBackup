<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
$con = mysqli_connect("localhost", "enzerhub", "enzerhub", "lottery");

$res = mysqli_query($con,"SELECT * FROM games");
while($row = mysqli_fetch_array($res)){

    $data_url = $row['data_url'] . "Last";
    $id = $row['id'];

    $data = [0,1,2,3,4,5,6,7,8,9];
    shuffle($data);
    $draw = $data[0] ."," . $data[1] . "," . $data[2];
   mysqli_query($con,"UPDATE games SET last_insertion = '{$data_url}' WHERE id = '$id'");

}




/*

mysqli_query($con,"ALTER TABLE draw_10001 AUTO_INCREMENT = 1 MAXVALUE 1380 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10002 AUTO_INCREMENT = 1 MAXVALUE 276 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10003 AUTO_INCREMENT = 1 MAXVALUE 1380 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10004 AUTO_INCREMENT = 1 MAXVALUE 460 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10005 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10006 AUTO_INCREMENT = 1 MAXVALUE 490 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10007 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10008 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10009 AUTO_INCREMENT = 1 MAXVALUE 460 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10010 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10011 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10012 AUTO_INCREMENT = 1 MAXVALUE 276 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10013 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10014 AUTO_INCREMENT = 1 MAXVALUE 460 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10015 AUTO_INCREMENT = 1 MAXVALUE 920 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10016 AUTO_INCREMENT = 1 MAXVALUE 460 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10017 AUTO_INCREMENT = 1 MAXVALUE 276 CYCLE");
mysqli_query($con,"ALTER TABLE draw_10018 AUTO_INCREMENT = 1 MAXVALUE 1380 CYCLE");
echo "Done";
// date_default_timezone_set('Asia/Singapore');
// echo date_default_timezone_get();
// echo date("H:i:i a");

*/