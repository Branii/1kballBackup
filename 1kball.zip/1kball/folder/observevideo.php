<?php
ini_set('display_errors',1);
include_once "model.php";
$model = new model();

$gameID = isset($_GET['gameId']) ? $_GET['gameId'] : "No gameId found";

// echo $gameID;
// exit;

$model->observeVideo("$gameID");