<?php
ini_set("error_reporting", 1);
ini_set("startup_errors", 1);
include "../conf/connect.php";
date_default_timezone_set('Asia/Singapore');

$time = $_GET['time'];


$result = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND second_per_issue = '300'");

// echo "<pre>";
// print_r($result);
// exit;
while ($row = mysqli_fetch_array($result)):

$gameTime = $row['second_per_issue'];
$gemeType = $row['rand_num_type'];
$gameId   = $row['game_id'];
$tableName = 'draw_' . $gameId;
$timeTable = "time5x0"; 

    switch ($gemeType) {

        case '5d':{#----------------------------------5d auto gen----------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt) > 0){
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $number = str_shuffle(rand(00000,99999));
            $length = 5;
            $string = substr(str_repeat(0, $length).$number, - $length);
            $str_drawNumber = sprintf("%05d", $string);
            $numArr = str_split($str_drawNumber);
            $drawNumber = implode(",",$numArr);
            $server = "box";
            $dated = date("Y-m-d");
    
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected " . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
                
            }
            }
    
            }else{
                // dont do anything wai ofui
    
            }
        
            }
    
            break;
        }
    
        case '3d':{#-------------------------------3d auto gen-------------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt) > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $number = str_shuffle(rand(000,999));
            $length = 3;
            $string = substr(str_repeat(0, $length).$number, - $length);
            $str_drawNumber = sprintf("%03d", $string);
            $numArr = str_split($str_drawNumber);
            $drawNumber = implode(",",$numArr);
            $server = "box";
            $dated = date("Y-m-d");
    
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected " . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
                echo "Waiting for game";
            }
            
            }//timer not found
    
            break;
        }
    
        case 'fast_3':{#-----------------------------------fast_3 auto gen---------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt)  > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $ArrNumber = array("1","2","3","4","5","6");
            shuffle($ArrNumber);
            $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2];
            $server = "box";
            $dated = date("Y-m-d");
    
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected "  . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
            }
    
            }
    
            break;
        }
    
        case 'pc_28':{#-----------------------------------pc_28 auto gen---------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt)  > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $number = str_shuffle(rand(000,999));
            $length = 3;
            $string = substr(str_repeat(0, $length).$number, - $length);
            $str_drawNumber = sprintf("%03d", $string);
            $numArr = str_split($str_drawNumber);
            $drawNumber = implode(",",$numArr);
            $server = "box";
            $dated = date("Y-m-d");
    
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected "  . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
            }
    
            }
    
            break;
        }
    
        case 'pk_10':{#---------------------------------pk_10 auto gen-----------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt) > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $ArrNumber = array("1","2","3","4","5","6","7","8","9","10");
            shuffle($ArrNumber);
            $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6] . "," . $ArrNumber[7] . "," . $ArrNumber[8] . "," . $ArrNumber[9];
            $server = "box";
            $dated = date("Y-m-d");
    
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected "  . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
            }
    
            }
    
            break;
        }
    
        case '11x5':{#----------------------------------11x5 auto gen----------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt) > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $ArrNumber = array("01","02","03","04","05","06","07","08","09","10","11");
            shuffle($ArrNumber);
            $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4];
            $server = "box";
            $dated = date("Y-m-d");
    
            
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected "  . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
            }
    
            }
    
            break;
        }
    
        case '49x7':{#----------------------------------47x9 auto gen----------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt) > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            $ArrNumber = array("01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49");
            shuffle($ArrNumber);
            $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6];
            $server = "box";
            $dated = date("Y-m-d");
    
    
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected "  . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
            }
    
            }
    
            break;
        }
    
        case 'keno':{#----------------------------------keno auto gen----------------------------------------#
            include "../conf/connect.php";
            $Currtime = $time;
            $sql = "SELECT id,count,timeset FROM $timeTable WHERE timeset = '{$Currtime}' ORDER BY id DESC LIMIT 1";
            $stmt = mysqli_query($con,$sql);
            $data = mysqli_fetch_array($stmt);
            $getCount =  $data['count'];
            $TheTimer =  $data['timeset'];
    
            if(mysqli_num_rows($stmt) > 0){
    
            $drawTime   = $TheTimer;
            $drawDate   = date("Ymd") . $getCount;
            $str_nowdate   = date("Y-m-d");
            $drawCount = $getCount;
    
            //$ArrNumber = array("01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54",
            //"55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","77","78","79","80");
    
            $ArrNumber = shuffle80Get20();
    
            //shuffle($ArrNumber);
            $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6]. "," . $ArrNumber[7]. "," . $ArrNumber[8]
            . "," . $ArrNumber[9]. "," . $ArrNumber[10]. "," . $ArrNumber[11]. "," . $ArrNumber[12]. "," . $ArrNumber[13]. "," . $ArrNumber[14]. "," . $ArrNumber[15]. "," . $ArrNumber[16]. "," . $ArrNumber[17]
            . "," . $ArrNumber[18]. "," . $ArrNumber[19];
    
            $server = "box";
            $dated = date("Y-m-d");
            
            $checkit = mysqli_query($con,"SELECT * FROM games WHERE command = 'start' AND notify = 'hide' AND sessionId = 'offline' AND game_id = '$gameId'");
            if(mysqli_num_rows($checkit) > 0){
    
            $resul10x0 = mysqli_query($con,"SELECT * FROM {$tableName} WHERE draw_count = '{$count}' AND draw_time = '{$time}' AND date_created = '{$dated}'");
            if(mysqli_num_rows($resul10x0) > 0){
                exit;
            }else{
                $insert = "INSERT INTO $tableName(draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)
                values('{$drawDate}','{$TheTimer}','{$drawNumber}','{$drawCount}','{$str_nowdate}','{$server}','{$Currtime}')";
            if(mysqli_query($con,$insert)){
            echo "1 row affected "  . $tableName;
            }else{
                echo $drawDate . "#" . $TheTimer . "#" . $drawNumber . "#" . $drawCount . "#" . $str_nowdate;
            }
            }
    
            }else{
                // dont do anything wai ofui
            }
    
            }
    
            break;
        }
    
    }

endwhile;


function shuffle80Get20() 
{ 
   // Create an array with numbers 1 to 80 
   $numbers = range(1, 80); 
   
   // Add leading zeros to the numbers 
   $numbers = array_map(function($n) { return sprintf('%02d', $n); }, $numbers); 
  
   // Shuffle the array 
   shuffle($numbers); 
  
   // Select the first 20 numbers from the shuffled array 
   $selectedNumbers = array_slice($numbers, 0, 20); 
  
   return $selectedNumbers; 
}

echo "Done ::";
