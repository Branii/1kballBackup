<?php

class Connection{

	private $dsn;
	private $use;
	private $pas;
	private $con;

	public function connect(){

	try {

	$this->dsn = "mysql:host=localhost;dbname=lottery";
	$this->use = "enzerhub";
	$this->pas = "enzerhub";

	$this->con = new PDO($this->dsn,$this->use,$this->pas);
	return $this->con;
		
	} catch (Exception $ex) {
		echo $ex;
	}

	}

	public function close(){
		unset($this->con);
	}

}

$conf = new Connection();
echo $conf->connect();

