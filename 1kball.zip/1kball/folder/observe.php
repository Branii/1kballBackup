<?php
//ini_set('display_errors',1);
include_once "model.php";
$model = new model();

$gameID = $_GET['gameID'];
$model->observe($gameID);