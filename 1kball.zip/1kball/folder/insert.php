<?php
 error_reporting(E_ERROR | E_PARSE);
 error_reporting(E_ALL);
 ini_set('display_errors', 1);
require_once "model.php";
$model = new model();

$gameid = $_GET['gameid'];
$drawDate = $_GET['drawDate'];
$drawTime = $_GET['drawTime'];
$drawCount = $_GET['drawCount'];
$drawNumber = strrev($_GET['drawNumber']);
$drawTable = "draw_" . $gameid;
$server = "box";

//echo $gameid . " " . $drawDate . " " . $drawTime . " " . $drawCount . ' ' . $drawNumber . '' . $drawTable . '' . $server;
//exit;

$result = $model->checkDraws($drawTable,$drawDate,$drawTime);
if ($result == "exist") {
    # code...
    echo "Game is disconnected";
    exit;
} else {
    # code...
    $model->insert("{$gameid}","{$drawDate}","{$drawTime}","{$drawNumber}","{$drawCount}","{$server}","{$drawTable}");

}

