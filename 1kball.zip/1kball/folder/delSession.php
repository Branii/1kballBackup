<?php
ini_set('display_errors',1);
require_once "model.php";
$model = new model();
$hashcode  = $_GET['gamehash'];
$model->delSession($hashcode);