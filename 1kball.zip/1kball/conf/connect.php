<?php
$con = mysqli_connect("localhost","enzerhub","enzerhub","lottery");