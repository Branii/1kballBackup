<?php
require 'vendor/autoload.php';
use Medoo\Medoo;
class Conn{

public function MedooCon(){

   try {

    $database = new Medoo([
    
        'type' => 'mysql',
        'host' => 'localhost',
        'database' => 'lottery',
        'username' => 'root',
        'password' => 'root'
        
    ]);
    echo "<pre>";
    var_dump($database);

   } catch (\Throwable $th) {

        echo $th->getMessage();

   }
    

}

}
