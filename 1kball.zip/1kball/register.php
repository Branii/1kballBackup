<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <link rel="stylesheet" href="assets/css/ladda-themeless.min.css">
</head>
<body>
<div class="login-page">
  <div class="form">
  <img src="assets/img/logo_white.png" height="70px" width="70px">
  <br><br>
    <div class="login-form" >
      <input type="username" placeholder="Username" id="username"/>
      <input type="email" placeholder="Email" id="email"/>
      <input type="number" placeholder="Mobile" id="mobile"/>
      <input type="password" placeholder="Password" id="password1"/>
      <input type="password" placeholder="Confirm password" id="password2"/>
      <button class="register ladda-button" data-style="zoom-in" data-size="s" data-spinner-color="#fff">Register</button>
      <p class="message">Already registered? <a href="../home/login">Login</a></p>
</div>
  </div>
</div>
</body>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/spin.min.js"></script>
<script src="assets/js/ladda.min.js"></script>
<script src="assets/js/axios.min.js"></script>

<script>
$(()=>{
  $(document).on("click",".register",function(){
   
    const $username  = $("#username").val();
    const $email     = $("#email").val();
    const $mobile    = $("#mobile").val();
    const $password1 = $("#password2").val();
    const $password2 = $("#password2").val();

    if($username == "" || $email == "" || $mobile == "" || $password1 == "" || $password2 == ""){
      console.log("All fields are required");
      return;
    }else if($password1 != $password2){
      console.log("passwords do not match");
      return;
    }else{

    var ladda = Ladda.create( document.querySelector( '.register' ) );
    ladda.start();
    
    setTimeout(()=>{

      // axios.post("../home/register_exec",{
      //   username:$username,
      //   email:$email,
      //   mobile:$mobile,
      //   password:$password2
      // }).then(function(response){
      //   console.log(response);
      //   ladda.stop();
      // }).catch(function(error){
      //   console.log(error);
      //   ladda.stop();
      // })

      $.post("../home/register_exec",{
        username:$username,
        email:$email,
        mobile:$mobile,
        password:$password2
      },(data)=>{
        console.log(data);
        ladda.stop(); 
      })

    },1000);


    }
   

  })
})
</script>
</html>