<?php

$con = mysqli_connect("localhost","enzerhub","enzerhub","lottery");

// Define the start and end times
$start_time = strtotime('00:00:00');
$end_time = strtotime('23:55:00');

// Define the time interval (3 minutes and 30 seconds)
$interval = 5 * 60; // 3 minutes and 30 seconds in seconds
// $interval = 4 * 60 ; // 3 minutes and 30 seconds in seconds
// Initialize an empty array to store the SQL INSERT statements
$sql_statements = array();

// Generate the rows
$count = 1;

while ($start_time <= $end_time) {
    // Format the current time as HH:MM:SS
    $timeset = date('H:i:s', $start_time);

    // Create the SQL INSERT statement and add it to the array
    $sql_statement = "INSERT INTO time5x0 (count, timeset) VALUES ('" . sprintf('%04d', $count) . "', '$timeset');";
    $sql_statements[] = $sql_statement;
    mysqli_query($con, $sql_statement);

    // Increment the count and time by the interval
    $count++;
    $start_time += $interval;
}

echo "Done";