<?php
// include "conf/connect.php";
// $pattern = '%draw_100%'; // Replace with your desired pattern
// $result = mysqli_query($con,"SHOW TABLES LIKE '$pattern'");

// $drawTables = [];
// if(mysqli_num_rows($result ) > 0){
//     foreach($result as $databaseTables){
//         echo "<pre>";
//         $drawTables[] = $databaseTables['Tables_in_lottery (%draw_100%)'];
//     }
// }

// //conunt he
// print_r($drawTables);