<?php
ini_set('display_errors',0);
session_start();
require_once "Conf.php";
class User extends Conf{    

public $con;

public function __construct() {
  $this->connect();
}

#check if user keeps logging in
function checkbrute($uid) {
    // Get timestamp of current time 
    $now = time();
 
    // All login attempts are counted from the past 2 hours. 
    $valid_attempts = $now - (2 * 60 * 60);
 
    $sql = "SELECT time FROM login_attempts WHERE uid = ? AND time > '$valid_attempts'";
    if ($stmt = $this->connect()->prepare($sql)) {
        $stmt->bindParam(1, $uid);
 
        // Execute the prepared query. 
        $stmt->execute();
   
        // If there have been more than 5 failed logins 
        if ($stmt->rowCount() > 4) {
            // "More that 5 login attemps";
            return true;
        } else {
            // "Not more that 5 login attemps";
            return false;
        }
    }
}

function getUID($str){
    $sql = "SELECT uid FROM users WHERE email = ? LIMIT 1";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1,$str);
    $stmt->execute();
    $data = $stmt->fetch();
    echo  $data['uid'];
}

#login to authenticate existing user
function Login($email, $password) {

    try {
   
    // Using prepared statements means that SQL injection is not possible. 
    $email = addslashes($email);
    $password = addslashes($password);

    $sql = "SELECT uid, username, email, mobile, pwd, oauth, account FROM users WHERE email = ? LIMIT 1";
    
    if ($stmt = $this->connect()->prepare($sql)) {
        $stmt->bindParam(1,$email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {

            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $uid = $row['uid'];
            $username = $row['username'];
            $email = ['email'];
            $mobile = $row['mobile'];
            $db_password = $row['pwd'];
            $oauth = $row['oauth'];
            $account = $row['account'];
                
                if (password_verify($password,$db_password)) {
                    // Password is correct!
                    session_start();
                    // Get the user-agent string of the user.
                    $user_browser = $_SERVER['HTTP_USER_AGENT'];
                    // XSS protection as we might print this value
                    $uid = preg_replace("/[^0-9]+/", "", $uid);
                    $_SESSION['userid'] = $uid;
                    // XSS protection as we might print this value
                    $username = preg_replace("/[^a-zA-Z0-9_\-]+/","",$username);
                    $_SESSION['username'] = $username;
                    //$_SESSION['sessionId'] = $uid;
                    $_SESSION['login_string'] = hash('sha512',$password . $user_browser);
                    //echo  "Login successful";
                    
                    $_SESSION['holder'] = $uid;
                    $_SESSION['email'] = $email;
                    $_SESSION['mail'] = $email;
                    $_SESSION['secret'] = $db_password;
                    $_SESSION['oauth'] = $oauth;
                    $_SESSION['account'] = $account;

                    $this->AddToLogs("Account Sign In",date("Y-m-d"),date("H:i:s a"),"UserId: " . $uid,$_SESSION['holder']);

                    return  "1" . $oauth;

                } else {
                    // Password is not correct
                    // We record this attempt in the database
                   
                    $this->disconnect();

                    return false;
                }
            
        } else {
            // No user exists.
            $this->disconnect();
            return false;
        }
    }

} catch (\Throwable $th) {
    //throw $th;
    echo $th->getMessage();
}

}



#register a new user
public function Register($username,$email,$mobile,$password){

    try {

    // Sanitize and validate the data passed
    $username = addslashes($username);
    $password = addslashes($password);
    $email = addslashes($email);
    $mobile = addslashes($mobile);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Not a valid email
        echo 'The email address you entered is not valid';
        exit;
    }

    // Username validity and password validity have been checked client side.
    // This should should be adequate as nobody gains any advantage from
    // breaking these rules.
    
    $sql = "SELECT uid FROM users WHERE email = ? OR mobile = ? LIMIT 1";
    $stmt = $this->connect()->prepare($sql);

    $stmt->bindParam(1, $email);
    $stmt->bindParam(2, $mobile);
    $stmt->execute();
 
    if ($stmt->fetchColumn() > 0) {
    // A user with this email address already exists
    echo 'This user already exist';
    $this->disconnect();
    exit;
    }

    // We'll also have to check account for the situation where the user doesn't have
    // rights to do registration, by checking what type of user is attempting to
    // perform the operation.

        //Create a random salt
        //$random_salt = hash('sha512', uniqid(openssl_random_pseudo_bytes(16), TRUE)); // optional salting
        $random_salt = hash('sha512', uniqid(mt_rand(1, mt_getrandmax()), true));
 
        // Create salted password 
        $password = hash('sha512', $password . $random_salt);

        if (strlen($password) != 128) {
            // The hashed pwd should be 128 characters long.
            // If it's not, something really odd has happened
            echo 'Invalid password configuration.';
            exit;
        }

        // Insert the new user into the database 
        $stmt_insert = "INSERT INTO users (username, email, mobile, pwd, salt) VALUES (?, ?, ?, ?, ?)";
        $insert_stmt = $this->connect()->prepare($stmt_insert);
        $insert_stmt->bindParam(1, $username,PDO::PARAM_STR);
        $insert_stmt->bindParam(2, $email,PDO::PARAM_STR);
        $insert_stmt->bindParam(3, $mobile,PDO::PARAM_INT);
        $insert_stmt->bindParam(4, $password,PDO::PARAM_STR);
        $insert_stmt->bindParam(5, $random_salt,PDO::PARAM_STR);

        // Execute the prepared query.
        if ($insert_stmt->execute()) {
            echo "Registration successful";
		} else {
            echo "Registration failed";
		}


    } catch (\Throwable $th) {
        //throw $th;
        echo $th->getMessage();
    }
   
}

function sec_session_start() {
    $session_name = 'sec_session_id';   // Set a custom session name
    $secure = SECURE;
    // This stops JavaScript being able to access the session id.
    $httponly = true;
    // Forces sessions to only use cookies.
    if (ini_set('session.use_only_cookies', 1) === FALSE) {
        header("Location: ../error.php?err=Could not initiate a safe session (ini_set)");
        exit();
    }
    // Gets current cookies params.
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params($cookieParams["lifetime"],
        $cookieParams["path"], 
        $cookieParams["domain"], 
        $secure,
        $httponly);
    // Sets the session name to the one set above.
    session_name($session_name);
    session_start();            // Start the PHP session 
    session_regenerate_id(true);    // regenerated the session, delete the old one. 
}

//usere management
function AddNewUser($username,$email,$mobile,$usertype,$password,$oauth){

    $username = addslashes($username);
    $email = addslashes($email);
    $mobile = addslashes($mobile);
    $usertype = addslashes($usertype);
    $password = addslashes($password);

    $sql = "SELECT uid FROM users WHERE email = ? OR mobile = ? LIMIT 1";
    $stmt = $this->connect()->prepare($sql);

    $stmt->bindParam(1, $email);
    $stmt->bindParam(2, $mobile);
    $stmt->execute();
 
    if ($stmt->fetchColumn() > 0) {
    // A user with this email address already exists
    echo 'This user already exist';
    $this->disconnect();
    exit;
    }
    
    if (strlen($password) != 128) {
        // The hashed pwd should be 128 characters long.
        // If it's not, something really odd has happened
        //echo 'Invalid password configuration.';
        //exit;
    }

    $hash = password_hash($password,PASSWORD_DEFAULT);
    $todayDate = date("Y-m-d");
    // Insert the new user into the database 
    $stmt_insert = "INSERT INTO users (username, email, mobile, account, pwd, oauth, dated) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $insert_stmt = $this->connect()->prepare($stmt_insert);
    $insert_stmt->bindParam(1, $username,PDO::PARAM_STR);
    $insert_stmt->bindParam(2, $email,PDO::PARAM_STR);
    $insert_stmt->bindParam(3, $mobile,PDO::PARAM_STR);
    $insert_stmt->bindParam(4, $usertype,PDO::PARAM_STR);
    $insert_stmt->bindParam(5, $hash ,PDO::PARAM_STR);
    $insert_stmt->bindParam(6, $oauth,PDO::PARAM_STR);
    $insert_stmt->bindParam(7, $todayDate ,PDO::PARAM_STR);

    // Execute the prepared query.
    if ($insert_stmt->execute()) {
        echo "Registration successful";

          //add to logs
          $this->AddToLogs("Add New User",date("Y-m-d"),date("H:i:s a"),"UserEmail: " . $email,$_SESSION['sessionId']);

    } else {
        echo "Registration failed";
    }

}

function FetchAllUsers(){
    $sql = "SELECT * FROM users";
    $stmt = $this->connect()->prepare($sql);
    $stmt->execute();
    $data = $stmt->fetchAll();
    return $data;
}

function FetchAllUsersLogs($uid){
    $sql = "SELECT * FROM logs WHERE userid = ? ORDER BY logid DESC";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $uid);
    $stmt->execute();
    $data = $stmt->fetchAll();
    return $data;
}

function FetchAllLogCount(){
    $sql = "SELECT * FROM logs ORDER BY logid DESC";
    $stmt = $this->connect()->prepare($sql);
    //$stmt->bindParam(1, $uid);
    $stmt->execute();
    $stmt->fetchAll();
    return $data = $stmt->rowCount();
}

function GetUserCount(){
    $sql = "SELECT * FROM users";
    $stmt = $this->connect()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetchAll();
    return count($row);
}

function UpdateUserDetails($uid,$username,$email,$mobile,$account){
    $sql = "UPDATE users SET username = ?, email = ?, mobile = ?, account = ? WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $username);
    $stmt->bindParam(2, $email);
    $stmt->bindParam(3, $mobile);
    $stmt->bindParam(4, $account);
    $stmt->bindParam(5, $uid);
    $stmt->execute();
    echo "User details updated";

      //add to logs
      $this->AddToLogs("Update User Detais",date("Y-m-d"),date("H:i:s a"),"UserId: " . $uid,$_SESSION['sessionId']);
}

function DeleteUser($uid){
    $sql = "DELETE FROM users WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $uid);
    $stmt->execute();
    echo "User deleted successfully";

    //add to logs
    $this->AddToLogs("Delete User",date("Y-m-d"),date("H:i:s a"),"UserId: " . $uid,$_SESSION['sessionId']);

}

function UpdateAuthen($uid,$oauth){

    $sql = "UPDATE users SET oauth = ? WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $oauth);
    $stmt->bindParam(2, $uid);
    $stmt->execute();
    echo "Authentictor Turned " . $oauth;
    //add to logs
    $this->AddToLogs("Turn " . $oauth . " Authenticator",date("Y-m-d"),date("H:i:s a"),"Authentictor",$_SESSION['sessionId']);

}

function CheckAuthen($uid){

    $sql = "SELECT oauth FROM users WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $uid);
    $stmt->execute();
    $row  = $stmt->fetchAll();
    return $row[0]['oauth'];

}

function AddToLogs($operation,$date,$time,$subject,$userid){
    
    $sql = "INSERT INTO logs (operation,date,time,subject,userid)VALUES(?,?,?,?,?)";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $operation);
    $stmt->bindParam(2, $date);
    $stmt->bindParam(3, $time);
    $stmt->bindParam(4, $subject);
    $stmt->bindParam(5, $userid);
    $stmt->execute();

}

function ChangePassword($uid,$oldpass,$newpass){

    $sql = "SELECT * FROM users WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $uid);
    $stmt->execute();
    $data  = $stmt->fetchAll();
    $dbPassword =  $data[0]['pwd'];
    //chck for pass
    if(password_verify($oldpass,$dbPassword)){

    $passwordHash = password_hash($newpass,PASSWORD_DEFAULT);
    $sql = "UPDATE users SET pwd = ? WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $passwordHash);
    $stmt->bindParam(2, $uid);
    $stmt->execute();
    echo "Password Changed Successfully";
    //add to logs
    $this->AddToLogs("Password Update",date("Y-m-d"),date("H:i:s a"),"UserId: " . $uid,$_SESSION['sessionId']);

    }else{

    echo "Current password is wrong";
    exit;

    }

}

function UserRole($uid){
    $sql = "SELECT account FROM users WHERE uid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1, $uid);
    $stmt->execute();
    $row  = $stmt->fetchAll();
    return $row[0]['account'];
}


}