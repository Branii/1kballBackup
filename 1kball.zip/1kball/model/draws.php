<?php
session_start();
require_once "Conf.php";
class Draws extends Conf{

    // insert data from selenium
    function insertDraws($TableName,$DrawDate,$DrawTime,$DrawNumber,$DrawCount,$DateCreated,$Client,$DrawGet){
        $sql = "INSERT INTO " . $TableName . " (draw_date,draw_time,draw_number,draw_count,date_created,client,get_time)VALUES(?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(1,$DrawDate);
        $stmt->bindParam(2,$DrawTime);
        $stmt->bindParam(3,$DrawNumber);
        $stmt->bindParam(4,$DrawCount);
        $stmt->bindParam(5,$DateCreated);
        $stmt->bindParam(6,$Client);
        $stmt->bindParam(7,$DrawGet);
        if($stmt->execute()){
            echo "Pushed successfully "  . $TableName;
        }else{
            echo "Some error occured "  . $TableName;
        }
    }

    //get all drawn numbers
    function FetchAllDraws(){

        $sql = "SELECT * FROM draws_tbl";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetchAll();
        return $row;

    }

    //get last insert id from fly table
    function getLastInsertId($todaysDate,$duration){

        date_default_timezone_set("Asia/Singapore");

        $holderTbl = "";
        if($duration == "60"){
            $holderTbl = "time1x0";
        }elseif($duration == "90"){
            $holderTbl = "time1x5";
        }elseif($duration == "180"){
            $holderTbl = "time3x0";
        }elseif($duration == "210"){
            $holderTbl = "time3x5";
        }elseif($duration == "240"){
            $holderTbl = "time4x0";
        }elseif($duration == "300"){
            $holderTbl = "time5x0";
        }elseif($duration == "600"){
            $holderTbl = "time10x0";
        }

        $todaysDate = date("Y-m-d");
        $time = date("H:i:s");
        $sql = "SELECT * FROM $holderTbl WHERE timeset = '{$time}' ORDER BY count DESC LIMIT 1";
        $stmt = $this->connect()->prepare($sql);
        //$stmt->bindValue(":drawdatee",$todaysDate);
        $stmt->execute();
        $data = $stmt->fetch();
        return !empty($data['count']) ? $data['count'] : "";
    }

    //get specific game draws  FetchSpecificDraw
    function FetchSpecificDraw($gameid,$todaysDate,$drawTable,$duration,$dataOption){

        date_default_timezone_set("Asia/Singapore");

        $holderTbl = "";
        if($duration == "60"){
            $holderTbl = "time1x0";
        }elseif($duration == "90"){
            $holderTbl = "time1x5";
        }elseif($duration == "120"){
            $holderTbl = "time2x0";
        }elseif($duration == "180"){
            $holderTbl = "time3x0";
        }elseif($duration == "210"){
            $holderTbl = "time3x5";
        }elseif($duration == "240"){
            $holderTbl = "time4x0";
        }elseif($duration == "300"){
            $holderTbl = "time5x0";
        }elseif($duration == "600"){
            $holderTbl = "time10x0";
        }

        //$todaysDate = date("Y-m-d");
        $hideSQL = "SELECT $holderTbl.count, $drawTable.* FROM $holderTbl LEFT JOIN $drawTable ON $holderTbl.count = $drawTable.draw_count WHERE $drawTable.date_created = '$todaysDate' ORDER BY $holderTbl.count DESC";
        $showSQL = "SELECT t.*, d.* FROM $holderTbl t LEFT JOIN (SELECT * FROM $drawTable WHERE date_created = '{$todaysDate}') d ON t.count = d.draw_count ORDER BY t.id DESC";
        //$sqll = "SELECT $holderTbl.drawcountt, $drawTable.* FROM $holderTbl LEFT JOIN $drawTable ON $holderTbl.drawcountt = $drawTable.draw_count AND $holderTbl.drawdatee = $drawTable.date_created WHERE $holderTbl.drawdatee = '$todaysDate' ORDER BY $holderTbl.drawcountt DESC";
        //$sql = "SELECT drawid,gameid,draw_date,draw_time,draw_count,draw_number,client FROM $drawTable WHERE gameid = :gameid AND date_created  = :date_created ORDER BY drawid DESC" ;
        

        $this->AddToLogs("View Game Draw History",date("Y-m-d"),date("H:i:s a"),"GameId: " . $gameid,$_SESSION['sessionId']);

        $render = "";
        if($dataOption == "showMiss"){
        $render = $showSQL;
        }else{
        $render = $hideSQL;
        }
        
        $stmt = $this->connect()->prepare($render);
        //$stmt->bindValue(":gameid", $gameid);
        //$stmt->bindValue(":date_created", $todaysDate);
        $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }

    //get specific game draws
    function FetchSpecificDrawWithDate($gameid,$todaysDate,$drawTable,$duration){
        
        date_default_timezone_set("Asia/Singapore");

        $holderTbl = "";
        if($duration == "60"){
            $holderTbl = "time1x0";
        }elseif($duration == "90"){
            $holderTbl = "time1x5";
        }elseif($duration == "180"){
            $holderTbl = "time3x0";
        }elseif($duration == "300"){
            $holderTbl = "time5x0";
        }elseif($duration == "600"){
            $holderTbl = "time10x0";
        }

        $this->AddToLogs("View Game Draw History",date("Y-m-d"),date("H:i:s a"),"GameId: " . $gameid,$_SESSION['sessionId']);
     
        $sqll = "SELECT $holderTbl.count, $drawTable.* FROM $holderTbl LEFT JOIN $drawTable ON $holderTbl.count = $drawTable.draw_count WHERE $drawTable.date_created = '$todaysDate' ORDER BY $holderTbl.count DESC";
        //$sql = "SELECT drawid,gameid,draw_date,draw_time,draw_count,draw_number,client FROM $drawTable WHERE gameid = :gameid AND date_created  = :date_created ORDER BY drawid DESC" ;
        $stmt = $this->connect()->prepare($sqll);
        //$stmt->bindValue(":gameid", $gameid);
        //$stmt->bindValue(":date_created", $todaysDate);
        $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $row;

    }

    //get specific game draws
    function AddToLogs($operation,$date,$time,$subject,$userid){
    
        $sql = "INSERT INTO logs (operation,date,time,subject,userid)VALUES(?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(1, $operation);
        $stmt->bindParam(2, $date);
        $stmt->bindParam(3, $time);
        $stmt->bindParam(4, $subject);
        $stmt->bindParam(5, $userid);
        $stmt->execute();
    
    }

}