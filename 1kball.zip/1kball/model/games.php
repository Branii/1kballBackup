<?php
//session_start();
require_once "Conf.php";
class Games extends Conf{

  function FetchGameHash($gameid){
    $sql = "SELECT game_hash FROM games WHERE game_id = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1,$gameid);
    $stmt->execute();
    $data = $stmt->fetchAll();
    return $data[0]['game_hash'];
  }

  public function rtmp_auth($stream_key){

    try {
      $sql = "SELECT * FROM streamkeys WHERE streamkey = ?";
      $stmt = $this->connect()->prepare($sql);
      $stmt->bindParam(1,$stream_key);
      $stmt->execute();
      $data = $stmt->fetch(PDO::FETCH_ASSOC);
      if($stmt->rowCount() > 0){

        http_response_code(201);
        $this->updateStream($data[0]['gamehash']);
        die();
      }else{
        http_response_code(402);
        die();
      }
    } catch (\Throwable $th) {
      echo $th;
    }
  
  }

  public function updateStream(?string $gamehash){
    $sql = "UPDATE games SET vid_state = 'live' WHERE game_hash = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1,$gamehash);
    $stmt->execute();
  }
  
  public function addStreamKey($gameid,$gamename,$gameurl,$gamehash,$streamkey){
  
    try {
      $dated = date("Y-m-d");

      // echo $gameid;exit;
      //check key
      $sqlx = "SELECT * FROM streamkeys WHERE gameid = ?";
      $stmtx = $this->connect()->prepare($sqlx);
      $stmtx->bindParam(1,$gameid);
      $stmtx->execute();
      if($stmtx -> rowCount() > 0){
        $sqlupdate = "UPDATE streamkeys SET streamkey = ? WHERE gameid = ?";
        $stmtx = $this->connect()->prepare($sqlupdate);
        $stmtx->bindParam(1,$streamkey);
        $stmtx->bindParam(2,$gameid);
        if($stmtx->execute()){
          echo $streamkey;
          $this->AddToLogs("Generate stream key",date("Y-m-d"),date("H:i:s a"),"Game ID: " . $gameid, $_SESSION['sessionId']);
        };
        exit;
      }
      $sql = "INSERT INTO streamkeys(gameid,gamename,gameurl,gamehash,streamkey,dated)VALUES(?,?,?,?,?,?)";
      $stmt = $this->connect()->prepare($sql);
      $stmt->bindParam(1,$gameid);
      $stmt->bindParam(2,$gamename);
      $stmt->bindParam(3,$gameurl);
      $stmt->bindParam(4,$gamehash);
      $stmt->bindParam(5,$streamkey);
      $stmt->bindParam(6,$dated);
      if($stmt->execute()){
        echo $streamkey;
        $this->AddToLogs("Generate stream key",date("Y-m-d"),date("H:i:s a"),"Game ID: " . $gameid,$_SESSION['sessionId']);
      };
    } catch (\Throwable $th) {
      echo $th;
    }
  
  }
  
  function generateStreamKey($length){
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $charactersLength = strlen($characters);
    $streamKey = '';
    for ($i = 0; $i < $length; $i++) {
      $streamKey .= $characters[rand(0, $charactersLength - 1)];
    }
    return $streamKey;
  }

  public function DeleteStreamKey($keyid){
    $sql = "DELETE FROM streamkeys WHERE sid = ?";
    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(1,$keyid);
    if($stmt->execute()){
      echo "Stream key deleted successfully";
      $this->AddToLogs("Delete stream key",date("Y-m-d"),date("H:i:s a"),"Key ID: " . $keyid,$_SESSION['sessionId']);
    }else{
      echo $stmt->errorInfo;
    }
  }

  public function FetchAllStreamKeys(){
    $sql = "SELECT * FROM streamkeys ORDER BY sid DESC";
    $stmt = $this->connect()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetchAll();
    return $row;
  }

  // Create new game table
  function createGameTable($gameTable){
  $sql = "CREATE TABLE IF NOT EXISTS $gameTable(
    drawid INT NOT NULL AUTO_INCREMENT,
    draw_date VARCHAR(50),
    draw_time VARCHAR(50),
    draw_number VARCHAR(100),
    draw_count VARCHAR(10),
    date_created VARCHAR(50),
    client VARCHAR(10),
    get_time VARCHAR(50),
    PRIMARY KEY (drawid)
  )";
  $stmt = $this->connect()->prepare($sql);
  //$stmt->bindParam(1,$gameTable);
  $stmt->execute();
  }

  function AddNewGame($param1,$param2,$param3,$param4,$param5,$param6,$param7,$param8,$param9,$param10,$param11,$param12,$param13,$gameTable){
      
      try {

          $query = "SELECT * FROM games WHERE game_id = ?";
          $stmt = $this->connect()->prepare($query);
          $stmt->bindParam(1,$param1);
          $stmt->execute();
          if($stmt->rowCount() > 0){
            exit("Game with the same ID already exist.");
          }
          
          $sql = "INSERT INTO games(
              game_id,	
              game_hash,	
              game_ip,	
              game_name,	
              game_alias,	
              game_port,	
              second_per_issue,	
              total_num_issue,	
              game_status,	
              stop_time,	
              start_time,	
              rand_num_type,	
              category_id
          
            )VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
      
              $stmt = $this->connect()->prepare($sql);
              $stmt -> bindParam(1,$param1);
              $stmt -> bindParam(2,$param2);
              $stmt -> bindParam(3,$param3);
              $stmt -> bindParam(4,$param4);
              $stmt -> bindParam(5,$param5);
              $stmt -> bindParam(6,$param6);
              $stmt -> bindParam(7,$param7);
              $stmt -> bindParam(8,$param8);
              $stmt -> bindParam(9,$param9);
              $stmt -> bindParam(10,$param10);
              $stmt -> bindParam(11,$param11);
              $stmt -> bindParam(12,$param12);
              $stmt -> bindParam(13,$param13);
              if($stmt -> execute()){

              echo "New game added successfully";
              self::createGameTable($gameTable);
              $this->AddToLogs("Add New Game",date("Y-m-d"),date("H:i:s a"),"GameID: " . $param1,$_SESSION['sessionId']);

              }

              

      } catch (\Throwable $th) {
          echo $th->getMessage();
      }

  }

  // fetch all games
  function FetchAllGames(){
      $sql = "SELECT * FROM games ORDER BY game_id ASC";
      $stmt = $this->connect()->prepare($sql);
      $stmt->execute();
      $row = $stmt->fetchAll();
      return $row;
  }

  //update game
  function UpdateGame($param1,$param2,$param3,$param4,$param5,$param6,$param7,$param8,$param9,$param10,$param11,$param12,$param13,$param14){
    $sql = "UPDATE games SET
    game_id = ?,
    game_hash = ?,
    game_ip = ?,
    game_name = ?,
    game_alias = ?,
    game_port = ?,
    second_per_issue = ?,
    total_num_issue = ?,
    game_status = ?,
    stop_time = ?,
    start_time = ?,
    rand_num_type = ?,
    game_details = ? WHERE id = ?";

    $stmt = $this->connect()->prepare($sql);
    $stmt -> bindParam(1,$param1);
    $stmt -> bindParam(2,$param2);
    $stmt -> bindParam(3,$param3);
    $stmt -> bindParam(4,$param4);
    $stmt -> bindParam(5,$param5);
    $stmt -> bindParam(6,$param6);
    $stmt -> bindParam(7,$param7);
    $stmt -> bindParam(8,$param8);
    $stmt -> bindParam(9,$param9);
    $stmt -> bindParam(10,$param10);
    $stmt -> bindParam(11,$param11);
    $stmt -> bindParam(12,$param12);
    $stmt -> bindParam(13,$param13);
    $stmt -> bindParam(14,$param14);
    $stmt->execute();
    echo "Game info updated successfully";

    $this->AddToLogs("Update Game Details",date("Y-m-d"),date("H:i:s a"),"GameID: " . $param1,$_SESSION['sessionId']);

  }

  //get total game count
  function GetGameCount(){
      $sql = "SELECT * FROM games";
      $stmt = $this->connect()->prepare($sql);
      $stmt->execute();
      $row = $stmt->fetchAll();
      return count($row);
  }

  //start the game
  function StartGame($duration,$status,$command,$gameId){
          
          $sql = "UPDATE games SET second_per_issue = :second_per_issue, game_status = :game_status, command = :command WHERE game_id = :game_id";
          $stmt = $this->connect()->prepare($sql);
          $stmt -> bindValue(":second_per_issue",$duration);
          $stmt -> bindValue(":game_status",$status);
          $stmt -> bindValue(":command",$command);
          $stmt -> bindValue(":game_id",$gameId);
          $stmt->execute();
          echo  "Game Started Successfully";

          $this->AddToLogs("Start Game",date("Y-m-d"),date("H:i:s a"),"GameID: " . $gameId,$_SESSION['sessionId']);

  }

  //stop the game
  function StopGame($duration,$status,$command,$gameId){
    try {
      $sql = "UPDATE games SET second_per_issue = :second_per_issue, game_status = :game_status, command = :command WHERE game_id = :game_id";
      $stmt = $this->connect()->prepare($sql);
      $stmt -> bindValue(":second_per_issue",$duration);
      $stmt -> bindValue(":game_status",$status);
      $stmt -> bindValue(":command",$command);
      $stmt -> bindValue(":game_id",$gameId);
      $stmt->execute();
      echo "Game Stopped Successfully";

      $this->AddToLogs("Stop Game",date("Y-m-d"),date("H:i:s a"),"GameId: " . $gameId,$_SESSION['sessionId']);

    } catch (\Throwable $th) {
      echo $th;
    }
  }

  //put game into incorgnito
  function StartIncognito($gameState,$gameId,$sessionId){

      try {
        $sql = "UPDATE games SET notify = :notify, sessionId = :sessionId WHERE game_id = :game_id";
        $stmt = $this->connect()->prepare($sql);
        $stmt -> bindValue(":notify",$gameState);
        $stmt -> bindValue(":sessionId",$sessionId);
        $stmt -> bindValue(":game_id",$gameId);
        if($stmt->execute()){
          echo "Incognito Mode Activated";

          $this->AddToLogs("show Game video",date("Y-m-d"),date("H:i:s a"),"VideoID: " . $gameId,$_SESSION['sessionId']);

        }else{
          echo $stmt->erroInfo();
        }
        
      } catch (\Throwable $th) {
        echo $th;
      }
  }
  
  //put game into incorgnito
  function StopIncognito($gameState,$gameId,$sessionId){

    try {
      $sql = "UPDATE games SET notify = :notify, sessionId = :sessionId WHERE game_id = :game_id";
        $stmt = $this->connect()->prepare($sql);
        $stmt -> bindValue(":notify",$gameState);
        $stmt -> bindValue(":sessionId",$sessionId);
        $stmt -> bindValue(":game_id",$gameId);
        if($stmt->execute()){
          echo "Incognito Mode deactivated";

          $this->AddToLogs("Hide Game video",date("Y-m-d"),date("H:i:s a"),"VideoID: " . $gameId,$_SESSION['sessionId']);

        }else{
          echo $stmt->erroInfo();
        }
    } catch (\Throwable $th) {
      echo $th;
    }
  }

    //get total game passed
    function FetchGamePassedCount($drawTable,$todaysDate){
      date_default_timezone_set("Asia/Singapore");
      //$todaysDate = date("Y-m-d");
      $sql = "SELECT * FROM $drawTable WHERE date_created = :date_created";
      $stmt = $this->connect()->prepare($sql);
      $stmt->bindValue(":date_created", $todaysDate);
      $stmt->execute();
      $stmt->fetch(PDO::FETCH_ASSOC);
      return $stmt->rowCount();
    }

     //get total game count
    function FetchGameDrawCount($duration){
      date_default_timezone_set("Asia/Singapore");

        $holderTbl = "";
        if($duration == "60"){
            $holderTbl = "time1x0";
        }elseif($duration == "90"){
            $holderTbl = "time1x5";
        }elseif($duration == "120"){
          $holderTbl = "time2x0";
        }elseif($duration == "180"){
            $holderTbl = "time3x0";
        }elseif($duration == "210"){
          $holderTbl = "time3x5";
        }elseif($duration == "240"){
            $holderTbl = "time4x0";
        }elseif($duration == "300"){
          $holderTbl = "time5x0";
        }elseif($duration == "600"){
            $holderTbl = "time10x0";
        }

        
        $todaysDate = date("Y-m-d");
        $sql = "SELECT * FROM $holderTbl ORDER BY id DESC LIMIT 1";
        $stmt = $this->connect()->prepare($sql);
        //$stmt->bindValue(":drawdatee", $todaysDate);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['count'];
    }

    //add to log
    function AddToLogs($operation,$date,$time,$subject,$userid){
    
      $sql = "INSERT INTO logs (operation,date,time,subject,userid)VALUES(?,?,?,?,?)";
      $stmt = $this->connect()->prepare($sql);
      $stmt->bindParam(1, $operation);
      $stmt->bindParam(2, $date);
      $stmt->bindParam(3, $time);
      $stmt->bindParam(4, $subject);
      $stmt->bindParam(5, $userid);
      $stmt->execute();
  
    }

     //push to live video
    function ShowLive($state,$gameId){

      $sql = "UPDATE games SET vid_state = :vid_state WHERE game_id = :game_id";
      $stmt = $this->connect()->prepare($sql);
      $stmt -> bindValue(":vid_state",$state);
      $stmt -> bindValue(":game_id",$gameId);
      $stmt->execute();
      echo  "Show live video";
      $this->AddToLogs("Push live video",date("Y-m-d"),date("H:i:s a"),"vidoeID: " . $gameId,$_SESSION['sessionId']);
    }

    
    //pull from live vidoe
    
    function HideLive($state,$gameId){
    $sql = "UPDATE games SET vid_state = :vid_state WHERE game_id = :game_id";
    $stmt = $this->connect()->prepare($sql);
    $stmt -> bindValue(":vid_state",$state);
    $stmt -> bindValue(":game_id",$gameId);
    $stmt->execute();
    echo "Hide live video";
    $this->AddToLogs("Pull live video",date("Y-m-d"),date("H:i:s a"),"vidoeID: " . $gameId,$_SESSION['sessionId']);
    }

    public function IsStreaming($gameid){
      try {
        $sql = "SELECT vid_state,game_hash FROM games WHERE game_id = ?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(1,$gameid);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        $sqll = "SELECT * FROM streamkeys WHERE gameid = ?";
        $stmtt = $this->connect()->prepare($sqll);
        $stmtt->bindParam(1,$gameid);
        $stmtt->execute();
        $datas = $stmtt->fetch(PDO::FETCH_ASSOC);

        // $eventData = [
        //   'vidstate' => $data['vid_state'],
        //   'vidlink'  => "http://203.161.53.136/" . $datas['streamkey'] . ".m3u8"
        // ];

        // $sseMessage = "data:" . json_encode($eventData) . "\n\n";
        // echo $sseMessage;
        // ob_flush();
        // flush();
        

        echo $data['vid_state'] . "=http://203.161.53.136/hls/" . $datas['streamkey'] . ".m3u8";
      } catch (\Throwable $th) {
        echo $th;
      }
    }

    // public function getStream($gameid){
    //   try {
    //     $sql = "SELECT vid_state FROM games WHERE game_id = ?";
    //     $stmt = $this->connect()->prepare($sql);
    //     $stmt->bindParam(1,$gameid);
    //     $stmt->execute();
    //     $data = $stmt->fetch(PDO::FETCH_ASSOC);
    //     echo $data['vid_state'];
    //   } catch (\Throwable $th) {
    //     echo $th;
    //   }
    // }
    

}