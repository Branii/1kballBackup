<?php

class Conf{

#database connection variables
    private $dbuser;
    private $dbpass;
    private $charset;
    public $con;

#sql connection 
public function connect(){
    
    $dsn = "mysql:host=localhost;dbname=lottery";
    $this->dbuser = "enzerhub";
    $this->dbpass = "enzerhub";
    $this->charset = "utf8mb4";

    try {
        
        #Open Main PDO connection
        $this->con = new PDO($dsn, $this->dbuser, $this->dbpass);
        $this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->con->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $this->con->setAttribute(PDO::ATTR_AUTOCOMMIT, 1);
        return $this->con;

    } catch (\Throwable $th) {
        //throw $th;
        echo $th->getMessage();
    }

}

#Close PDO disconnection
public function disconnect(){
    $this->con = null;
}
 

}
