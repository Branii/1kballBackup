<?php
session_start();
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}
?>
<!DOCTYPE html>
<html lang="en" oncontextmenu="return false">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Games
  </title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- <link href="assets/css/td-message.css" rel="stylesheet" /> -->
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />

  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
 
  <style>
     .lmask {
            position: absolute;
            height: 100%;
            width: 100%; 
            background-color: #000;
            bottom: 0;
            left: 0;
            right: 0;
            top: 0;
            z-index: 9999;;
            opacity: 0.4;}
            .lmask {
              position: fixed;
            }
            .lmask:before {
              content: '';
              background-color: rgba(0,0,0,0);
              border: 5px solid rgba(0,183,229,0.9);
              opacity: .9;
              border-right: 5px solid rgba(0,0,0,0);
              border-left: 5px solid rgba(0,0,0,0);
              border-radius: 50px;
              box-shadow: 0 0 35px #2187e7;
              width: 50px;
              height: 50px;
              -moz-animation: spinPulse 1s infinite ease-in-out;
              -webkit-animation: spinPulse 1s infinite linear;
          
              margin: -25px 0 0 -25px;
              position: absolute;
              top: 50%;
              left: 50%;
            }
            .lmask:after {
              content: '';
              background-color: rgba(0,0,0,0);
              border: 5px solid rgba(0,183,229,0.9);
              opacity: .9;
              border-left: 5px solid rgba(0,0,0,0);
              border-right: 5px solid rgba(0,0,0,0);
              border-radius: 50px;
              box-shadow: 0 0 15px #2187e7;
              width: 30px;
              height: 30px;
              -moz-animation: spinoffPulse 1s infinite linear;
              -webkit-animation: spinoffPulse 1s infinite linear;
          
              margin: -15px 0 0 -15px;
              position: absolute;
              top: 50%;
              left: 50%;
            }
          
          @-moz-keyframes spinPulse {
            0% {
              -moz-transform:rotate(160deg);
              opacity: 0;
              box-shadow: 0 0 1px #2187e7;
            }
            50% {
              -moz-transform: rotate(145deg);
              opacity: 1;
            }
            100% {
              -moz-transform: rotate(-320deg);
              opacity: 0;
            }
          }
          @-moz-keyframes spinoffPulse {
            0% {
              -moz-transform: rotate(0deg);
            }
            100% {
              -moz-transform: rotate(360deg);
            }
          }
          @-webkit-keyframes spinPulse {
            0% {
              -webkit-transform: rotate(160deg);
              opacity: 0;
              box-shadow: 0 0 1px #2187e7;
            }
            50% {
              -webkit-transform: rotate(145deg);
              opacity: 1;
            }
            100% {
              -webkit-transform: rotate(-320deg);
              opacity: 0;
            }
          }
          @-webkit-keyframes spinoffPulse {
            0% {
              -webkit-transform: rotate(0deg);
            }
            100% {
              -webkit-transform: rotate(360deg);
            }
          }
  </style>
  
  
</head>

<body class="g-sidenav-show  bg-gray-100">

<div class='mask'></div>

<?php include "sidebar.php" ?>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

    <div class="container-fluid py-4 px-3" style="border-top:solid 1px #ddd;">
 
      <div class="row">
        <div class="col-12">
        
        <div class="card border shadow-xs mb-4">
  <div class="card-header border-bottom pb-0">
    <div class="d-sm-flex align-items-center">
      <div>
        <h6 class="font-weight-semibold text-lg mb-0">Recent Draws</h6>
        <p class="text-sm">List of all game draws</p>
      </div>
      <div class="ms-auto d-flex">
      <button type="button" class="btn btn-lg btn-white me-2 btnp"> <i class="bx bx-printer" style="font-size:20px;margin-right:5px;"></i> Print</button>
        
      </div>
    </div>
  </div>
  <div class="card-body px-0 py-0">
    <div class="border-bottom py-3 px-3 d-sm-flex align-items-center">
      <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
      <div class="dropdown">
  
  <select class="games  p-1" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border:solid 1px #ddd;position:relative;top:-6px;border-radius:5px;outline:0 !important">
  <option>Select Game</option>
    <?php
    require_once "model/games.php";
    $allGames = new Games;
    $data = $allGames->FetchAllGames();
    foreach ($data as $row):
      ?>
        <option value='<?=$row['game_id'] . "#" . $row['second_per_issue']  . "#" . $row['game_name'] ;?>'><?='['.$row['game_id'].'] '.$row['game_name'];?></option>
      <?php
    endforeach;
    ?>
  </select>
<?php
$currDate = date("Y-m-d");
?>
  <input type="date" class="datetoday" style="height:33px;border-radius:5px;padding:5px;border:solid 1px #ddd;position:relative;top:-5px;" value="<?=$currDate?>">
  <button type="button" class="fetch-draws btn btn-sm btn-white me-2"> Fetch Draws <i class='bx bx-loader bx-spin fff' style="font-size:15px;display:none;"></i></button>
</div>
</div>

      <!-- <div class="input-group w-sm-25 ms-auto">
        <span class="input-group-text text-body">
          <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"></path>
          </svg>
        </span>
        <input type="text" class="form-control" placeholder="Search">
      </div> -->

    </div>
    <div class="table-responsive p-0" id="gamedata" style="margin:25px;">
    <i class='bx bx-info-circle' style='color:#e6b314;font-size:25px;position:relative;top:5px;'  ></i> Select game to show draws
    </div>
    <div class="border-top py-3 px-3 d-flex align-items-center">
      <p class="font-weight-semibold mb-0 text-dark text-sm">..</p>
      <div class="ms-auto">
        <!-- <button class="btn btn-sm btn-white mb-0">Previous</button>
        <button class="btn btn-sm btn-white mb-0">Next</button> -->
      </div>
    </div>
  </div>
</div>

        </div>
      </div>
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start">
                Copyright
                © <script>
                  document.write(new Date().getFullYear())
                </script>
                Enzerhub
                <a href="#" class="text-secondary" target="_blank">Developers</a>.
              </div>
            </div>
  
          </div>
        </div>
      </footer>
    </div>
  </main>
  


  <!--   Core JS Files   -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <!-- <script src="assets/js/core/popper.min.js"></script> -->
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
<script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>
<script src="assets/js/nifty.min.js"></script>
<!-- <script src="assets/js/td-message.min.js"></script> -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script>
  $(document).ready(function() {

    $(".draw").addClass("active")

    if (window.performance && window.performance.navigation.type === window.performance.navigation.TYPE_BACK_FORWARD) {
    // The page is being loaded from the cache, prevent the refresh
    window.location.replace(window.location.href);
    }

   // trigger the add modal
    $(".btnp").click(function() {
      
      let gameinfo = $(".games").val();
      let selectedDate = $(".datetoday").val();

      if(gameinfo == "Select Game"){

        alert("Nothing to print.\nFetch draw numbers to print")
        return

      }else{
      
        let spil = gameinfo.split("#");
      let gameid = spil[0];
      let duration = spil[1];
      let gamename = spil[2];
      window.location.href = "print.php?gameid=" + gameid +"&duration=" + duration + "&gamename=" + gamename + "&date=" + selectedDate;

      }

      
    })
    
    $(".fetch-draws").click(function() {

      
      let gameinfo = $(".games").val();
      let dateToday = $(".datetoday").val();

      let spil = gameinfo.split("#");
      let gameid = spil[0];
      let gameduration = spil[1];



      if(gameid == "Select Game"){
        //$("#gamedata").html("<i class='bx bx-info-circle' style='color:#e6b314'></i> Select game to show draws")
      return
      }else{

        $(".mask").addClass("lmask");

        $(".fff").show()
        setTimeout(()=>{

          $.post("exec/get_draw_exec.php",{
          gameid:gameid,
          gameduration:gameduration,
          dateToday:dateToday
          
          },(data)=>{
            $(".fff").hide()
            $(".mask").removeClass("lmask");
              $("#gamedata").html(data) // some data came back
              //console.log(JSON.stringify(data))
          });

         },1000);

      }
      
    })

})

</script>

</body>
</html>