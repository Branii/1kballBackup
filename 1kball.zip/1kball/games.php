<?php
session_start();
ini_set('display_errors',1);
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Games
  </title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />

  <lnk rel="stylesheet" href="assets/toggle/css/toggles.css">
  <lnk rel="stylesheet" href="assets/toggle/css/themes/toggles-light.css">
 
  <style>

    .cck{
      transform: scale(1.2);
      margin-left: 2px;
      cursor: pointer;
    }
    .nav-item{
      margin-right: 5px;
    }
    .nav-tab:active{
      background-color: red;
    }
   
    pre {
        color: var(--code-color);
        font-size: var(--code-font-size);
        line-height: var(--code-line-height);
        background-color: var(--code-bg-color);
    }

    .code-block {
        max-height: 100px;
        overflow: auto;
        padding: 8px 7px 5px 15px;
        margin: 0px 0px 0px 0px;
        border-radius: 7px;
    }

    /* For Webkit browsers */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background-color: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background-color: red;
  border-radius: 50px;
}





  </style>


   <link href="assets/css/nifty.min.css" rel="stylesheet" />

</head>

<body class="g-sidenav-show  bg-gray-100">


<?php include "sidebar.php" ?>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
 
    <div class="container-fluid py-4 px-3" style="border-top:solid 1px #ddd;">
 
      <div class="row">
        <div class="col-12">
          <div class="card border shadow-xs mb-4">
            <div class="card-header border-bottom pb-0">
              <div class="d-sm-flex align-items-center mb-3">
                <div>
                  <h6 class="font-weight-semibold text-lg mb-0">Recent Games</h6>
                  <p class="text-sm mb-sm-0">List of available games</p>
                </div>
                <div class="ms-auto d-flex">
                  <button type="button" class=" recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <?php
                    include "model/games.php";
                    $gameCounter = new Games;
                    ?>
                    <span class="btn-inner--text ">Total Games: <?=$gameCounter->GetGameCount()?> </span>
                  </button>

                  <button type="button" class="download recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <span class="btn-inner--icon">
                    <i class='bx bx-plus' style='color:#2f2c2c;font-size:20px;' ></i>
                    </span>
                    <span class="btn-inner--text download">Add New game</span>
                  </button>
                </div>
              </div>
            </div>
            
            <div class="card-body px-2 py-0">
            
              <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="nav-home-tab" >
                  
                  
                   <div class="table-responsive p-0">
                <table class="table align-items-center justify-content-center mb-0 table-bordered table-striped">
                  <thead class="bg-gray-100">
                    <tr>
                      <!-- <th class="text-secondary text-xs font-weight-semibold opacity-7">Date Created</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7 ps-2">Last Modified Date</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7 ps-2">Created By</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7 ps-2">Last Modified By</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7 ps-2">Row ID</th> -->
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game ID</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Hash</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game IP</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game Name</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game Alias</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game Port</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Seconds Per Issue</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Total Num Of Issue</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Start Time</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Stop Time</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Rand Num Type</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Game Status</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Show</th>
                      <th class="text-secondary text-xs font-weight-semibold opacity-7">Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php
                  require_once "model/games.php";
                   $fetchObject = new Games;
                   $data = $fetchObject->FetchAllGames();

                   foreach($data as $row):

                    
                  $game_hasgh = strlen($row["game_hash"]) > 15 ? substr($row["game_hash"],0,15)."..." : $row["game_hash"];
                  $game_status = $row["game_status"];

                  $info = "";
                  if($game_status == "Game Started"){
                    $info = '<span class="badge badge-sm border border-success text-success bg-success">
                    <svg width="9" height="9" viewBox="0 0 10 9" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" class="me-1">
                      <path d="M1 4.42857L3.28571 6.71429L9 1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg> Started </span>';
                  }else{
                    $info = '<span class="badge badge-sm border border-danger text-danger bg-danger">
                    <svg width="12" height="12" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="me-1">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                    </svg> Stopped </span>';
                  }

                  $gameState = $row['notify'];
                  $check;
                  if($gameState == "show"){
                    $check = "checked";
                  }else{
                    $check = "unchecked";
                  }

                  $vidoeS = $row["vid_state"];
                  $vidoeState;
                  $shoot;
                  if($vidoeS == "live"){
                    $vidoeState = "checked";
                    $shoot = "<i class='bx bx-camera-movie bx-flashing shoot' style='color:orangered;font-size:18px;'></i>";
                  }else{
                    $vidoeState = "unchecked";
                    $shoot = "";
                  }

                    ?>
                        <tr class="datarow">
                          <td><?=$row["game_id"]?>
                          <input type="hidden" class="id" value="<?=$row["id"]?>">
                          <input type="hidden" class="game_id" value="<?=$row["game_id"]?>">
                          <input type="hidden" class="game_hash" value="<?=$row["game_hash"]?>">
                          <input type="hidden" class="game_ip" value="<?=$row["game_ip"]?>">
                          <input type="hidden" class="game_name" value="<?=$row["game_name"]?>">
                          <input type="hidden" class="game_alias" value="<?=$row["game_alias"]?>">
                          <input type="hidden" class="game_port" value="<?=$row["game_port"]?>">
                          <input type="hidden" class="second_per_issue" value="<?=$row["second_per_issue"]?>">
                          <input type="hidden" class="total_num_issue" value="<?=$row["total_num_issue"]?>">
                          <input type="hidden" class="game_status" value="<?=$row["game_status"]?>">
                          <input type="hidden" class="stop_time" value="<?=$row["stop_time"]?>">
                          <input type="hidden" class="start_time" value="<?=$row["start_time"]?>">
                          <input type="hidden" class="rand_num_type" value="<?=$row["rand_num_type"]?>">
                          <input type="hidden" class="details" value="<?=$row["game_details"]?>">
                          <input type="hidden" class="vidval" value="<?=$row["vid_state"]?>">
                          </td>

                          <td><?=$game_hasgh?></td>
                          <td><?=$row["game_ip"]?></td>
                          <td><?=$row["game_name"]?></td>
                          <td><?=$row["game_alias"]?></td>
                          <td><?=$row["game_port"]?></td>
                          <td><?=$row["second_per_issue"]?></td>
                          <td><?=$row["total_num_issue"]?></td>
                          <td><?=$row["stop_time"]?></td>
                          <td><?=$row["start_time"]?></td>
                          <td><?=$row["rand_num_type"]?></td>
                          <td><?=$info?></td>
                          <td>

                          
                          <div>
                          <!-- <input type="checkbox" class=" chk toggles toggle-light" style="width:20px;height:20px;" <?=$check?>> -->
                          <div class="form-check form-switch ps-0">
                          <input class="form-check-input mt-1 ms-auto chk" type="checkbox" <?=$check?>>
                          </div>

                         
                          <button type="button" class="btn btn-white btn-icon px-2 py-2 videox ssx" style="cursor:pointer">
                          <?=$shoot;?>
                          <i class='bx bx-camera-movie bx-flashing shoot' style='color:orangered;font-size:18px;display:none;'></i>
                          <input class="form cck" type="checkbox" <?=$vidoeState?>>
                          </button>
                          

                          </div>
                          
                          
                            
                          </td>

                          <td>

                          
                          
                          <button type="button" class="btn btn-white btn-icon px-2 py-2 editbtn">
                          <i class='bx bxs-pencil' style='color:#2f2c2c;font-size:18px;'  ></i>
                          </button>

                          <button type="button" class="btn btn-white btn-icon px-2 py-2 startbtn">
                          <i class='bx bx-play' style='color:#21c52b;font-size:18px;'  ></i>
                          </button>

                          <button type="button" class="btn btn-white btn-icon px-2 py-2 stopbtn">
                          <i class='bx bx-stop' style='color:#ea3017;font-size:18px;' ></i>
                          </button>



                          </td>
                        </tr>
                    <?php

                   endforeach;

                  ?>
           
                  </tbody>
                </table>

                
                    </div>
             

                </div>

              <div class="border-top py-3 px-3 d-flex align-items-center">
                <!-- <button class="btn btn-sm btn-white d-sm-block d-none mb-0">Previous</button>
                <nav aria-label="..." class="ms-auto">
                  <ul class="pagination pagination-light mb-0">
                    <li class="page-item active" aria-current="page">
                      <span class="page-link font-weight-bold">1</span>
                    </li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">2</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold d-sm-inline-flex d-none" href="javascript:;">3</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">...</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold d-sm-inline-flex d-none" href="javascript:;">8</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">9</a></li>
                    <li class="page-item"><a class="page-link border-0 font-weight-bold" href="javascript:;">10</a></li>
                  </ul>
                </nav>
                <button class="btn btn-sm btn-white d-sm-block d-none mb-0 ms-auto">Next</button> -->
              </div>
              
            </div>
          </div>
        </div>
      </div>
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start">
                Copyright
                © <script>
                  document.write(new Date().getFullYear())
                </script>
                Enzerhub
                <a href="#" class="text-secondary" target="_blank">Developers</a>.
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </main>
  
 

  <!-- nifty moda;-->
  <div class="nifty-modal fade-in-scale" id="showAdd">
    <div class="md-content" style="border-radius:10px;width:600px;"> 
    <div class='md-title' style="background-color:#ddd;border-top-left-radius:10px;border-top-right-radius:10px;">
      <span style="font-size:20px;color:#000;">Add new game<i class='bx bx-x-circle md-close' style='font-size:30px;color:#bbb;cursor:pointer;position:relative;left:35%;' ></i></span>
    </div>
  
      <div class='md-body' style="border-radius:10px;max-height:500px;overflow-y:scroll;">
  
      
             <div class="mb-3"><br>
  
              <form>
                <div class="form-group">
                  <label for="exampleInputEmail1">Game ID</label>
                  <input type="number" class="form-control" id="gameid" aria-describedby="emailHelp" placeholder="Game ID">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Hash Code</label>
                  <input type="text" class="form-control" id="hash" placeholder="Hash Code">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">IP Address</label>
                  <input type="text" class="form-control" id="ip" placeholder="IP Address">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Name</label>
                  <input type="text" class="form-control" id="gamename" placeholder="Game Name">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Alias</label>
                  <input type="text" class="form-control" id="gamealias" placeholder="Game Alias">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Server Port</label>
                  <input type="number" class="form-control" id="port" placeholder="Game Server Port">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Seconds Per Issue</label>
                  <input type="number" class="form-control" id="sec_per_issue" placeholder="Seconds Per Issue">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Total Num Of Issues:</label>
                  <input type="number" class="form-control" id="tot_num_issue" disabled placeholder="Total Number Of Issues">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Status:</label>
                  <input type="text" class="form-control" id="enable" value="stop" disable placeholder="Enable or disable">
                </div>
              
                <div class="form-group">
                  <label for="exampleInputPassword1">Start Stop Time:</label>
                  <input type="text" class="form-control" id="start_time" placeholder="05:00:00">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">End Stop Time:</label>
                  <input type="text" class="form-control" id="end_time" placeholder="05:59:00">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Rand Num Type:</label>
                  <select type="text" class="form-control" id="rand_num" placeholder="Rand Num Type">
                    <option value="5d">5D</option>
                    <option value="3d">3D</option>
                    <option value="fast_3">FAST 3</option>
                    <option value="keno">KENO</option>
                    <option value="pc_28">PC 28</option>
                    <option value="pk_10">PK 10</option>
                    <option value="11x5">11X5</option>
                    <option value="49x7">49X7</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="exampleInputPassword1">Choose game series:</label>
                  <select type="text" class="form-control" id="category">
                    <option value="1">5D GAME SERIES</option>
                    <option value="2">3D GAME SERIES</option>
                    <option value="3">FAST 3 GAME SERIES</option>
                    <option value="4">KENO GAME SERIES</option>
                    <option value="5">PK 10 GAME SERIES</option>
                    <option value="6">PC 28 GAME SERIES</option>
                    <option value="7">11X5 GAME SERIES</option>
                    <option value="9">49X7 GAME SERIES</option>
                  </select>
                </div>

                <!-- <div class="form-group">
                  <label for="exampleInputPassword1">Run Incognito Mode</label>
                  <input type="checkbox" class="chk" id="min_intervalx" placeholder="Min Intevals" style="width:15px;height:15px;border:solid 1px #eee;">
                </div> -->
               
              </form>
             
            </div>
  
 
  
        
      </div>

      <div class='md-footer d-flex justify-content-center' style="background-color:#fff;border-bottom-left-radius:10px;border-bottom-right-radius:10px;box-shadow: rgba(0, 0, 0, 0.08) 0px 1.5px 1px 0px inset;">
       
        <button type="button" class="savegame btn btn-sm" style="border:solid 1px #aaa">
          <span class="btn-inner--text">Save Game <i class='bx bx-loader bx-spin' style="font-size:15px;display:none;"></i></span>
        </button>

      </div>

    </div>
  </div>
  <div class="md-overlay"></div>

    <!-- nifty moda;-->
    <div class="nifty-modal fade-in-scale" id="showEdit">
    <div class="md-content" style="border-radius:10px;width:600px;">
    <div class='md-title' style="background-color:#ddd;border-top-left-radius:10px;border-top-right-radius:10px;">
      <span style="font-size:20px;color:#000;">Edit game info<i class='bx bxs-x-circle md-close' style='font-size:30px;color:#bbb;cursor:pointer;position:relative;left:30%;' ></i></span>
    </div>
  
      <div class='md-body' style="border-radius:10px;max-height:500px;overflow-y:scroll;">
  
      
             <div class="mb-3"><br>
  
              <form>
                <div class="form-group">
                  <label for="exampleInputEmail1">Game ID</label>
                  <input type="hidden" class="form-control" id="gid" aria-describedby="emailHelp">
                  <input type="text" class="form-control" id="gameidx" aria-describedby="emailHelp" placeholder="Game ID">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Hash Code</label>
                  <input type="text" class="form-control" id="hashx" placeholder="Hash Code">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">IP Address</label>
                  <input type="text" class="form-control" id="ipx" placeholder="IP Address">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Name</label>
                  <input type="text" class="form-control" id="gamenamex" placeholder="Game Name">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Alias</label>
                  <input type="text" class="form-control" id="gamealiasx" placeholder="Game Alias">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Server Port</label>
                  <input type="text" class="form-control" id="portx" placeholder="Game Server Port">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Seconds Per Issue</label>
                  <input type="text" class="form-control" id="sec_per_issuex" placeholder="Seconds Per Issue">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Total Num Of Issues:</label>
                  <input type="text" class="form-control" id="tot_num_issuex" placeholder="Total Number Of Issues">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Enable:</label>
                  <input type="text" class="form-control" id="enablex" placeholder="Enable or disable">
                </div>
              
                <div class="form-group">
                  <label for="exampleInputPassword1">Start Stop Time:</label>
                  <input type="text" class="form-control" id="start_timex" placeholder="00:00:00">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">End Stop Time:</label>
                  <input type="text" class="form-control" id="end_timex" placeholder="00:00:00">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Rand Num Type:</label>
                  <select type="text" class="form-control" id="rand_numx" placeholder="Rand Num Type">
                  <option value="5d">5D</option>
                    <option value="3d">3D</option>
                    <option value="fast_3">FAST 3</option>
                    <option value="keno">KENO</option>
                    <option value="pc_28">PC 28</option>
                    <option value="pk_10">PK 10</option>
                    <option value="11x5">11X5</option>
                    <option value="49x7">49X7</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="exampleInputPassword1">Game Description</label>
                  <textarea type="text" class="form-control" id="detailsx" placeholder="Game Details"></textarea>
                </div>

                <!-- <div class="form-group">
                  <label for="exampleInputPassword1">Run Incognito Mode</label>
                  <input type="checkbox" class="" id="min_intervalx" placeholder="Min Intevals" style="width:25px;height:25px;">
                </div> -->

                
               
              </form>
             
            </div>

      </div>

      <div class='md-footer d-flex justify-content-center' style="background-color:#fff;border-bottom-left-radius:10px;border-bottom-right-radius:10px;box-shadow: rgba(0, 0, 0, 0.08) 0px 1.5px 1px 0px inset;">
       
        <button type="button" class="updategame btn btn-sm" style="border:solid 1px #aaa">
          <span class="btn-inner--text">Update Game <i class='bx bx-loader bx-spin upp' style="font-size:15px;display:none;"></i></span>
        </button>

      </div>

    </div>
  </div>
  <div class="md-overlay"></div>

  <!--   Core JS Files   -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
<script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>
<script src="assets/js/nifty.min.js"></script>
<script src="assets/js/td-message.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>
  $(document).ready(function() {
    $(".game").addClass("active")
    //$('.toggles').toggles();

    //check box for incognito 
    $(".chk").click(function(){

   
      let gameState;
     
    
        if($(this).is(":checked")){

          if(confirm("This will run in incognito mode")){
            let gameid = $(this).closest(".datarow").find(".game_id").val();
            gameState = "show" // show/pause video mode
            $.post("exec/video_show_exec.php",{
              gameid:gameid,
              gameState:gameState
            },function(data){
                console.log(data)
                alert(data)
            })

          }else{

            
            $(this).attr("checked",false)
           

          }

        
          
        }else{
       
          let gameid = $(this).closest(".datarow").find(".game_id").val();
          gameState = "hide" // no video mode
          $.post("exec/video_hide_exec.php",{
              gameid:gameid,
              gameState:gameState
            },function(data){
              console.log(data)
              alert(data)
            })
        }
    
    })

    $(".cck").click(function(){
      let vidoeshoot = $(this).closest(".datarow").find(".shoot")
      if($(this).is(":checked")){
        let gameid = $(this).closest(".datarow").find(".game_id").val();
        $.post("exec/showvidstate.php",{
          gameid: gameid,
          vidState:"live"
        },function(data){
          vidoeshoot.show()
          
        })
      }else{
        let gameid = $(this).closest(".datarow").find(".game_id").val()
        $.post("exec/hidevidstate.php",{
          gameid: gameid,
          vidState:"dead"
        },function(data){
          vidoeshoot.hide()
        })
        
      }
    })

    // $(".video").on("click",function(event){
    //   event.stopPropagation();
    //   let vidval = $(this).closest("tr").find(".vidval").val();
    //   let gameid = $(this).closest(".datarow").find(".game_id").val();

    //   if(vidval == "dead"){
    //     $(this).closest("tr").find(".vidval").val("live")
    //     $.post("exec/showvidstate.php",{
    //       gameid: gameid,
    //       vidState:"live"
    //     },function(data){
    //       alert(data)
    //       $(this).closest("tr").find(".ss").text("nii")
    //       $(this).closest("tr").find(".hh").hide()
    //     })
    //   }else{
    //     $(this).closest("tr").find(".vidval").val("dead")
    //     $.post("exec/hidevidstate.php",{
    //       gameid: gameid,
    //       vidState:"dead"
    //     },function(data){
    //       alert(data)
    //       $(this).closest("tr").find(".hh").show()
    //       $(this).closest("tr").find(".ss").hide()
    //     })
    //   }
    // })


    let totalDays = 1380;
    let drawTimes;
     $("#sec_per_issue").keyup(function(){
        let calC = $(this).val()/60;
        drawTimes = totalDays / calC;
        $("#tot_num_issue").val(drawTimes);
     })


    //start button clicked
    $(".startbtn").click(function(){
        let gameid = $(this).closest(".datarow").find(".game_id").val();
        let duration = $(this).closest("tr").find(".second_per_issue").val();
        let status = "Game Started";
        let command = "start";

        //alert(gameid + " " + duration + " " + status + " " + command)

        if(confirm("Do you want to start this game?")){

          $.post("exec/start_game_exec.php",{
            game_id:gameid,
            duration:duration,
            status:status,
            command:command
          },function(response){
            window.location.href = ""
          })

        }
    })

    //stop button clicked
    $(".stopbtn").click(function(){
      var gameid = $(this).closest("tr").find(".game_id").val();
        var duration = $(this).closest("tr").find(".second_per_issue").val();
        var status = "Game Stopped";
        var command = "stop";
        if(confirm("Do you want to stop this game?")){

          $.post("exec/stop_game_exec.php",{
            game_id:gameid,
            duration:duration,
            status:status,
            command:command
          },function(response){
            window.location.href = ""
          })

        }
    })

   // trigger the add modal
    $(".download").click(function() {
      $("#showAdd").nifty("show");
    })

    // trigger the edit modal
    $(".editbtn").click(function() {
      $("#gid").val($(this).closest("tr").find(".id").val());
      $("#gameidx").val($(this).closest("tr").find(".game_id").val());
      $("#hashx").val($(this).closest("tr").find(".game_hash").val());
      $("#ipx").val($(this).closest("tr").find(".game_ip").val());
      $("#gamenamex").val($(this).closest("tr").find(".game_name").val());
      $("#gamealiasx").val($(this).closest("tr").find(".game_alias").val());
      $("#portx").val($(this).closest("tr").find(".game_port").val());
      $("#sec_per_issuex").val($(this).closest("tr").find(".second_per_issue").val());
      $("#tot_num_issuex").val($(this).closest("tr").find(".total_num_issue").val());
      $("#enablex").val($(this).closest("tr").find(".game_status").val());
      $("#start_timex").val($(this).closest("tr").find(".start_time").val());
      $("#end_timex").val($(this).closest("tr").find(".stop_time").val());
      $("#rand_numx").val($(this).closest("tr").find(".rand_num_type").val());
      $("#detailsx").val($(this).closest("tr").find(".details").val());

      $("#showEdit").nifty("show");
    })

    $(".savegame").click(()=>{
      //get all the values from the form
  
      let gameid = $("#gameid").val();
      let hash = $("#hash").val();
      let ip = $("#ip").val();
      let gamename = $("#gamename").val();
      let gamealias = $("#gamealias").val();
      let port = $("#port").val();
      let sec_per_issue = $("#sec_per_issue").val();
      let tot_num_issue = $("#tot_num_issue").val();
      let enable = $("#enable").val();
      let start_time = $("#start_time").val();
      let end_time = $("#end_time").val();
      let rand_num = $("#rand_num").val();
      let category = $("#category").val();

      // do some validation
      if(gameid == "" || hash == "" || ip == "" || gamename == "" || gamealias == "" || port == "" || sec_per_issue == "" || tot_num_issue == "" || enable == "" || start_time == "" || end_time == ""){
        alert("All fields are required")
        return
      }else{

        $(".bx-spin").show()

        setTimeout(()=>{

        $.post("exec/add_game_exec.php",{
      
        gameid:gameid,
        hash:hash,
        ip:ip,
        gamename:gamename,
        gamealias:gamealias,
        port:port,
        sec_per_issue:sec_per_issue,
        tot_num_issue:tot_num_issue,
        enable:enable,
        //last_date:last_date,
        //last_time:last_time,
        start_time:start_time,
        end_time:end_time,
        rand_num:rand_num,
        category:category
        
        },(data)=>{

        alert(data)
        $(".bx-spin").hide()

        });

       },2000)

    }

   })

   //update game button
   $(".updategame").click(()=>{
      //get all the values from the form
      let gid = $("#gid").val();
      let gameid = $("#gameidx").val();
      let hash = $("#hashx").val();
      let ip = $("#ipx").val();
      let gamename = $("#gamenamex").val();
      let gamealias = $("#gamealiasx").val();
      let port = $("#portx").val();
      let sec_per_issue = $("#sec_per_issuex").val();
      let tot_num_issue = $("#tot_num_issuex").val();
      let enable = $("#enablex").val();
      let start_time = $("#start_timex").val();
      let end_time = $("#end_timex").val();
      let rand_num = $("#rand_numx").val();
      let details = $("#detailsx").val();


      // do some validation
      if(gameid == "" || hash == "" || ip == "" || gamename == "" || gamealias == "" || port == "" || sec_per_issue == "" || tot_num_issue == "" || enable == "" || start_time == "" || end_time == ""){
        alert("All fields are required")
        return
      }else{

        $(".upp").show()

        setTimeout(()=>{

        $.post("exec/update_game_exec.php",{
        gid:gid,
        gameid:gameid,
        hash:hash,
        ip:ip,
        gamename:gamename,
        gamealias:gamealias,
        port:port,
        sec_per_issue:sec_per_issue,
        tot_num_issue:tot_num_issue,
        enable:enable,
        //last_date:last_date,
        //last_time:last_time,
        start_time:start_time,
        end_time:end_time,
        rand_num:rand_num,
        details:details
        
        },(data)=>{

        alert(data)
        console.log(data)
        $(".upp").hide()

        });

       },2000)

    }

   })

})

</script>

</body>
</html>