<?php
//ini_set('display_errors', 1);
session_start();
if(!isset($_SESSION['sessionId'])){
header("location:index.php");
exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Activity Logs
  </title>

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Noto+Sans:300,400,500,600,700,800|PT+Mono:300,400,500,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/349ee9c857.js" crossorigin="anonymous"></script>
  <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/corporate-ui-dashboard.css?v=1.0.0" rel="stylesheet" />

  <lnk rel="stylesheet" href="assets/toggle/css/toggles.css">
  <lnk rel="stylesheet" href="assets/toggle/css/themes/toggles-light.css">
 


<link href="assets/css/nifty.min.css" rel="stylesheet" />

</head>

<body class="g-sidenav-show  bg-gray-100">

<?php include "sidebar.php" ?>

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
 
    <div class="container-fluid py-4 px-3" style="border-top:solid 1px #ddd;">
 
      <div class="row">
        <div class="col-12">
          <div class="card border shadow-xs mb-4">
            <div class="card-header border-bottom pb-0">
              <div class="d-sm-flex align-items-center mb-3">
                <div>
                  <h6 class="font-weight-semibold text-lg mb-0">Recent Logs</h6>
                  <p class="text-sm mb-sm-0">User Activity loggings</p>
                </div>
                <div class="ms-auto d-flex">
                  <button type="button" class=" recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <?php
                    include "model/user.php";
                    $userCounter = new User;
                    ?>
                    <span class="btn-inner--text ">Total Logs: <?=$userCounter->FetchAllLogCount()?> </span>
                  </button>

                  <button type="button" class="download recent btn btn-sm btn-light btn-icon d-flex align-items-center mb-0 me-2">
                    <span class="btn-inner--icon">
                    <i class='bx bx-plus' style='color:#2f2c2c;font-size:20px;' ></i>
                    </span>
                    <span class="btn-inner--text download">Delete all logs</span>
                  </button>
                </div>
              </div>
            </div>
            
            <div class="card-body px-2 py-0">
            
              <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="nav-home-tab" >

                   <?php

                    require_once "model/user.php";
                    $fetchObject = new User;
                    $data = $fetchObject->FetchAllUsers();
                
                    $counterr = 0;
                    foreach($data as $row):
                    
                        $uid = $row['uid'];
                        $username = $row['username'];

                    
                    ?>

                    <div class="mx-auto col-md-12">
                    <div class="accordion" id="accordionRental">

                        <div class="mb-3 accordion-item">
                        <h5 class="accordion-header" id="headingTwo">
                            <button class="accordion-button border-bottom font-weight-bold" type="button" data-bs-toggle="collapse" data-bs-target="#content<?=$uid?>" aria-expanded="false" aria-controls="collapseTwo">
                            <i class='bx bx-user-circle' style="font-size:30px;color:#aaa;margin-right:10px"></i> <?= $username;?>
                            <i class="pt-1 text-xs collapse-close fa fa-plus position-absolute end-0 me-3"></i>
                            <i class="pt-1 text-xs collapse-open fa fa-minus position-absolute end-0 me-3"></i>
                            </button>
                        </h5>
                        <div id="content<?=$uid?>" class="border-0 accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionRental">
                            <div class="text-sm accordion-body text-dark opacity-8" style="max-height:500px;overflow-y:scroll;">
                                
                    <table class="table align-items-center justify-content-center mb-0 table-bordered table-striped">
                    <thead class="bg-gray-100">
                        <tr>
                        
                        <th class="text-secondary text-xs font-weight-semibold opacity-7">#No</th>
                        <th class="text-secondary text-xs font-weight-semibold opacity-7">Operation</th>
                        <th class="text-secondary text-xs font-weight-semibold opacity-7">Date Acted</th>
                        <th class="text-secondary text-xs font-weight-semibold opacity-7">Time Acted</th>
                        <th class="text-secondary text-xs font-weight-semibold opacity-7">Subject</th>
                        <th class="text-secondary text-xs font-weight-semibold opacity-7">Action</th>

                        </tr>
                    </thead>
                    <tbody>

                    <?php
                    require_once "model/user.php";
                    $fetchObject = new User;
                    $data = $fetchObject->FetchAllUsersLogs($uid);
                    
                        $counter = 0;
                        foreach($data as $row):
                        $counter++;

                        ?>
                            <tr class="datarow">
                            <td><?=$counter?>
                            <input type="hidden" class="id" value="<?=$row["uid"]?>">
                            <input type="hidden" class="username" value="<?=$row["username"]?>">
                            <input type="hidden" class="email" value="<?=$row["email"]?>">
                            <input type="hidden" class="mobile" value="<?=$row["mobile"]?>">
                            <input type="hidden" class="account" value="<?=$row["account"]?>">
                    
                            </td>
                            <td><?=$row["operation"]?></td>
                            <td><?=$row["date"]?></td>
                            <td><?=$row["time"]?></td>
                            <td><?=$row["subject"]?></td>

                            <td>
                            <button type="button" class="btn btn-white btn-icon px-2 py-2 delbtn">
                            <i class='bx bxs-trash' style='color:#2f2c2c'  ></i>
                            </button>
                            </td>
                            </tr>
                        <?php

                    endforeach;

                    ?>
           
                    </tbody>
                    </table>

                            </div>
                        </div>
                        </div>
                    
                    </div>
                    </div>
                   </div>

                    <?php
                    endforeach;
                    ?>

              
            </div>
          </div>
        </div>
      </div>
      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">

            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-xs text-muted text-lg-start">
                Copyright© <script>
                  document.write(new Date().getFullYear())
                </script>
                Enzerhub
                <a href="#" class="text-secondary" target="_blank">Developers</a>.
              </div>
            </div>

          </div>
        </div>
      </footer>
    </div>
  </main>
  
 

   <!-- nifty moda;-->
   <div class="nifty-modal fade-in-scale" id="showDel" style="">
    <div class="md-content" style="border-radius:10px;width:600px;">
    <div class='md-title' style="background-color:#ddd;border-top-left-radius:10px;border-top-right-radius:10px;">
      <span style="font-size:20px;color:#000;">Delete this activity<i class='bx bxs-x-circle md-close' style='font-size:25px;color:#bbb;cursor:pointer;position:relative;left:30%;'></i></span>
      </div>
  
      <div class='md-body' style="border-radius:10px;height:auto;">
                   <input type="hidden" class="delid">
        <div class="mb-3 d-flex justify-content-center"><br>
        <i class='bx bx-trash' style='color:#aaa;font-size:30px;position:relative;right:12px;top:10px;'></i>
      <p>
        This user activity will be permanently removed from the syetem activity tray.
        Please do you really wants to continue?
      </p>
        
      </div>
  
      <div class="modal-footer justify-content-center">


    <button type="button" class="md-close btn btn-sm btn-outline-light btn-icon d-flex align-items-center mb-0 me-2"  style="position:relative;left:25%;">
      <span class="btn-inner--text cancel text-danger">No, Cancel</span>
    </button>  

    <button type="button" class="delete btn btn-sm btn-outline-light btn-icon d-flex align-items-center mb-0 me-2">
      <span class="btn-inner--text text-success">Yes, Delete <i class='bx bx-loader bx-spin dll' style="font-size:20px;display:none;"></i></span>
    </button>  

  
     </div>
  
        
      </div>
    </div>
  </div>
  <div class="md-overlay"></div>
  <!--   Core JS Files   -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Corporate UI Dashboard: parallax effects, scripts for the example pages etc -->
<script src="assets/js/corporate-ui-dashboard.min.js?v=1.0.0"></script>
<script src="assets/js/nifty.min.js"></script>
<script src="assets/js/td-message.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>
  $(document).ready(function() {

    $(".logs").addClass("active")

    // trigger the update  function
    $(".updateuser").click(function() {
      let userid = $("#userid").val();
      let username = $("#usernamee").val();
      let email = $("#emaill").val();
      let mobile = $("#mobilee").val();

       // do some validation
       if(username == "" || email == "" || mobile == ""){
        alert("All fields are required")
        return
      }else{

        $(".bx-spin").show()

        setTimeout(function(){

        $.post("exec/update_user.php",{
      
        uid:userid,
        username:username,
        email:email,
        mobile:mobile
        
        },(data)=>{
          $("#showEdit").nifty("hide");
        alert(data)
        $(".bx-spin").hide()
        window.location.href = ""

        });

       },1000)

    }

    })

    // trigger the del function
    $(".delete").click(function() {
      let userid = $(".delid").val()
      let deleteThis = $(this).closest("tr")
      $(".dll").show();
      $.post("exec/delete_user.php",{
        uid:userid
      },function(data){
        $("#showDel").nifty("hide");
        alert(data)
        $(".dll").hide();
        window.location.href = ""
      })
    })

    // trigger the del modal
    $(".delbtn").click(function() {
      $(".delid").val($(this).closest("tr").find(".id").val());
      $("#showDel").nifty("show");
    })

    
   // trigger the add modal
    $(".download").click(function() {
      $("#showAdd").nifty("show");
    })

    // trigger the edit modal
    $(".editbtn").click(function() {
      $("#userid").val($(this).closest("tr").find(".id").val());
      $("#usernamee").val($(this).closest("tr").find(".username").val());
      $("#emaill").val($(this).closest("tr").find(".email").val());
      $("#mobilee").val($(this).closest("tr").find(".mobile").val());
      $("#accountt").val($(this).closest("tr").find(".account").val());

      $("#showEdit").nifty("show");
    })


    $(".savegame").click(()=>{
      //get all the values from the form
  
      let username = $("#username").val();
      let email = $("#email").val();
      let mobile = $("#mobile").val();
      let account = $("#account").val();
      let password1 = $("#password1").val();
      let password2 = $("#password2").val();
      

      // do some validation
      if(username == "" || email == "" || mobile == "" || account == "" || password1 == "" || password2 == ""){
        alert("All fields are required")
        return
      }else if(password1 != password2){
        alert("Password do not match")
        return
      }else{

        $(".bx-spin").show()

        setTimeout(function(){

        $.post("exec/add_new_user.php",{
      
        username:username,
        email:email,
        mobile:mobile,
        account:account,
        password:password1
        
        },(data)=>{
          $("#showAdd").nifty("hide");
        alert(data)
        window.location.href = ""
        $(".bx-spin").hide()

        });

       },1000)

    }

   })

   //update game button
   $(".updategame").click(()=>{
      //get all the values from the form
      let gid = $("#gid").val();
      let gameid = $("#gameidx").val();
      let hash = $("#hashx").val();
      let ip = $("#ipx").val();
      let gamename = $("#gamenamex").val();
      let gamealias = $("#gamealiasx").val();
      let port = $("#portx").val();
      let sec_per_issue = $("#sec_per_issuex").val();
      let tot_num_issue = $("#tot_num_issuex").val();
      let enable = $("#enablex").val();
      let start_time = $("#start_timex").val();
      let end_time = $("#end_timex").val();
      let rand_num = $("#rand_numx").val();
      let min_interval = $("#min_intervalx").val();


      // do some validation
      if(gameid == "" || hash == "" || ip == "" || gamename == "" || gamealias == "" || port == "" || sec_per_issue == "" || tot_num_issue == "" || enable == "" || start_time == "" || end_time == ""){
        alert("All fields are required")
        return
      }else{

        $(".upp").show()

        setTimeout(()=>{

        $.post("exec/update_game_exec.php",{
        gid:gid,
        gameid:gameid,
        hash:hash,
        ip:ip,
        gamename:gamename,
        gamealias:gamealias,
        port:port,
        sec_per_issue:sec_per_issue,
        tot_num_issue:tot_num_issue,
        enable:enable,
        //last_date:last_date,
        //last_time:last_time,
        start_time:start_time,
        end_time:end_time,
        rand_num:rand_num,
        min_interval:min_interval
        
        },(data)=>{

        alert(data)
        console.log(data)
        $(".upp").hide()

        });

       },2000)

    }

   })



})

</script>

</body>
</html>