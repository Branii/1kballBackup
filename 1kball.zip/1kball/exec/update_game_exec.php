<?php
//update game info
ini_set("display_errors",1);
session_start();
require_once "../model/games.php";
$update_game = new Games;
$gid    = addslashes($_POST['gid']);
$gameid    = addslashes($_POST['gameid']);
$hash = addslashes($_POST['hash']);
$ip    = addslashes($_POST['ip']);
$gamename = addslashes($_POST['gamename']);
$gamealias    = addslashes($_POST['gamealias']);
$port = addslashes($_POST['port']);
$sec_per_issue    = addslashes($_POST['sec_per_issue']);
$tot_num_issue = addslashes($_POST['tot_num_issue']);
$enable    = addslashes($_POST['enable']);
$start_time = addslashes($_POST['start_time']);
$end_time    = addslashes($_POST['end_time']);
$rand_num = addslashes($_POST['rand_num']);
$details = addslashes($_POST['details']);

// echo $gid . " =" . $gameid . " " . $hash . " " . $ip. " "  . $gamename . " " . $gamealias . " " . $port . " " . $sec_per_issue . " " . $tot_num_issue . " " . $enable . " " .
// $start_time  . " " . $end_time . " " . $rand_num . " " . $details;
// exit;

// return the result to the view
$update_game->UpdateGame(
    $gameid,
    $hash,
    $ip,
    $gamename,
    $gamealias,
    $port,
    $sec_per_issue,
    $tot_num_issue,
    $enable,
    $start_time,
    $end_time,
    $rand_num,
    $details,
    $gid
)


?>