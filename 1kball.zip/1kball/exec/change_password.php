<?php
ini_set('display_errors', 1);
require_once "../model/user.php";
$user = new User;
$oldpass   = $_POST['oldpass'];
$newpass = $_POST['newpass'];
$uid   = $_SESSION['sessionId'];

$user->ChangePassword($uid,$oldpass,$newpass);
