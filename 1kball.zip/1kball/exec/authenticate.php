<?php
//ini_set('display_errors', 1);
session_start();
include "../model/user.php";
$new_user = new User;

require "../vendor/autoload.php";
$google2fa = new \PragmaRX\Google2FA\Google2FA();
$user_provided_code = $_POST['code'];
$secret_key = $_SESSION['code'];
$uid = $_SESSION['userid'];

if ($google2fa->verifyKey($secret_key, $user_provided_code)) {
    $_SESSION['sessionId'] = $uid;
// Code is valid
echo "1";
exit;
} else {
// Code is NOT valid
echo "0" . $uid ;
exit;
}
