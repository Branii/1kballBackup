<?php
require_once "../model/games.php";
$gameStopper = new Games;
$gameId   = $_POST['game_id'];
$duration = $_POST['duration'];
$status   = $_POST['status'];
$command  = $_POST['command'];

// echo $gameId . " " . $duration . " ". $status . " " . $command;
// exit;
// start the game 
$gameStopper -> StopGame($duration,$status,$command,$gameId);