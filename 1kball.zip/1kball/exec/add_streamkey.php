<?php
//ini_set('display_errors', 1);
session_start();
require_once "../model/games.php";

$gameid   = addslashes($_POST['gameid']);
$gamename = addslashes($_POST['gamename']);

// game url
$streamkey = (new Games)->generateStreamKey(30);
$gamehash = (new Games)->FetchGameHash($gameid);
$gameurl = "rtmp://203.161.53.136/live";// . $gamehash;
(new Games)->addStreamKey($gameid,$gamename,$gameurl,$gamehash,$streamkey);


?>