<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: *");
header("Access-Control-Allow-Headers: *");
require_once "../model/games.php";

// $steamkey = $_GET['name'];
// if($steamkey == "braniiblack"){
//     http_response_code(201);
// }else{
//     http_response_code(402);
// }

if(isset($_GET['name'])){
    $streamKey = $_GET['name'];
    (new Games)->rtmp_auth($streamKey);
}else{
   // http_response_code(402); 
}



?>