<?php
//check user for registration
$new_user = new User;
$username = $_POST['username'];
$email    = $_POST['email'];
$mobile   = $_POST['mobile'];
$password = $_POST['password'];
$new_user->Register($username,$email,$mobile,$password);
