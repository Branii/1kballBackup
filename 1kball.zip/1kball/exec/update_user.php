<?php
//ini_set('display_errors', 1);
require_once "../model/user.php";
//Add new game
$new_user = new User;

$uid = addslashes($_POST['uid']);
$username    = addslashes($_POST['username']);
$email = addslashes($_POST['email']);
$mobile    = addslashes($_POST['mobile']);
$account    = addslashes($_POST['account']);

// return the result to the view
$new_user->UpdateUserDetails($uid,$username,$email,$mobile,$account);


?>