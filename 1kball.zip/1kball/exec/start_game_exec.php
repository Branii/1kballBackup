<?php

require_once "../model/games.php";
$gameStater = new Games;
$gameId   = $_POST['game_id'];
$duration = $_POST['duration'];
$status   = $_POST['status'];
$command  = $_POST['command'];

// echo $gameId . " " . $duration . " ". $status . " " . $command;
// exit;
// start the game 
$gameStater -> StartGame($duration,$status,$command,$gameId);
