<?php
//ini_set('display_errors', 1);
session_start();
require_once "../model/games.php";
//Add new game
$new_game = new Games;

$gameid    = addslashes($_POST['gameid']);
$hash = addslashes($_POST['hash']);
$ip    = addslashes($_POST['ip']);
$gamename = addslashes($_POST['gamename']);
$gamealias    = addslashes($_POST['gamealias']);
$port =addslashes( $_POST['port']);
$sec_per_issue    = addslashes($_POST['sec_per_issue']);
$tot_num_issue = addslashes($_POST['tot_num_issue']);
$enable    = addslashes($_POST['enable']);
$start_time = addslashes($_POST['start_time']);
$end_time    = addslashes($_POST['end_time']);
$rand_num = addslashes($_POST['rand_num']);
$category = addslashes($_POST['category']);
$data_url = "http://89.47.162.79/1kball/dev/api/v1/" . $gamename;

$gameTable = "draw_" . $gameid;

// return the result to the view
$new_game->AddNewGame($gameid,$hash,$ip,$gamename,$gamealias,$port,$sec_per_issue,$tot_num_issue,$enable,$start_time,$end_time,$rand_num,$category,$gameTable)

?>