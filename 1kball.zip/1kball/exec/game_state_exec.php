<?php
require_once "../model/games.php";
$gameStopper = new Games;
$gameId   = $_POST['game_id'];
$command  = $_POST['command'];

$gameStopper->StartIncognito($command,$gameId);