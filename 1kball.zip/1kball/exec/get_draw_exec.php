<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<style>

  .page-link:hover{
     background-color:#bbb;
     color:white;
    }
    
    .page-link a:current{
     background-color:#F44E4E;
     color:white;
    }
    
    .page-link{
     margin:3px;
     float:left;
     color:#1c1e1f;
    }
    
    .page-link a:active{
      background-color: orange !important;
    }
      
  </style>

<table id="example" class="table align-items-center mb-0 table-bordered table-striped">

<?php
//ini_set('display_errors', 1);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// require_once "../model/draws.php";
// $getMissedCount = new Draws;
// $gameid = $_POST['gameid'];
// $todaysDate = $_POST['dateToday'];
// $drawTable = "draw_" . $gameid;
// $gameduration = $_POST["gameduration"];
//$missedCount = $getMissedCount->FetchSpecifiMissedCount($gameid,$todaysDate,$drawTable);

#//total game count
// $totalGameCount = 0;
// if($gameduration == "60"){
//   $totalGameCount = 1380/(60/60);
// }elseif ($gameduration == "90") {
//   $totalGameCount = 1380/(90/60);
// }elseif ($gameduration == "180") {
//   $totalGameCount = 1380/(180/60);
// }
// elseif ($gameduration == "300") {
//   $totalGameCount = 1380/(300/60);
// }
// elseif ($gameduration == "600") {
//   $totalGameCount = 1380/(600/60);
// }

#total game played
//$totalGamePlayed = $totalGameCount - $missedCount;

?>

        <!-- <thead class="bg-gray-100">
          <tr>
            <th  class="text-left text-xs font-weight-semibold opacity-7">Total Game Count: <?=$totalGameCount;?></th>
            <th  class="text-left text-xs font-weight-semibold opacity-7">Total Game Played: <?=$_SESSION['played'];?></th>
            <th  class="text-left text-xs font-weight-semibold opacity-7">Total Game Missed: <?=$_SESSION['missed'];;?></th>
            <th  colspan="3"></th>
          </tr>
        </thead> -->
        <!-- <thead class="bg-gray-100">
          <tr><th colspan="6" class="text-left text-xs font-weight-semibold opacity-7">
            </th>
          
        </thead> -->
        <thead class="bg-gray-100">
          <tr>
            <th class="text-center text-xs font-weight-semibold opacity-7">Status</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Draw Count</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Date</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Time</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Number</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Date Created</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Time Get</th>
          </tr>
        </thead>
<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);

//check user for login
require_once "../model/draws.php";
$getDraws = new Draws;
$gameid = $_POST['gameid'];
$duration = $_POST['gameduration'];
$todaysDate = $_POST['dateToday'];
$drawTable = "draw_" . $gameid;

//echo $gameDraws . " " . $gameid . " " . $duration . " " . $todaysDate . " " . $drawTable;
$data = $getDraws->FetchSpecificDrawWithDate($gameid,$todaysDate,$drawTable,$duration);

//just checking
$lastRowCount = $getDraws->getLastInsertId($todaysDate,$duration);

$counter = 0;
$missed = 0;
$played = 0;
foreach ($data as $key):
    
  $counter++;
    //global counters
    if($key['draw_date'] == null){
      $missed++;
    }
    if ($key['count'] != null) {
      $played++;
    }

    $style = "";
    $info = "";
    $draw_date = "";
    $draw_time = "";
    $draw_number = "";
    $date_created = "";
    $client = "";


    if($key['draw_date'] == null){
      $key['draw_date']  = "<span style='color:#ccc;'>---</span>";
      $draw_date = "null";
    }
    if($key['draw_time'] == null) {
      $draw_time  = "null";
    }
    if ($key['draw_number'] == null) {
      $draw_number = "null";
    }
    if ($key['date_created'] == null) {
      $date_created = "null";
    }
    if ($key['client'] == null) {
      $client = "null";
    }

    if($key['drawcount'] != null && $client == "null"){

      $style = "rgb(253,240,238,0.7)";
      $info = '<span class="badge badge-sm border border-primary text-primary bg-primary">
      <i class="bx bx-loader-alt bx-spin"></i> Waiting </span>';

      $key['draw_date']  = "<span style='color:#257CFD;'>---</span>";
      $key['draw_time']  = "<span style='color:#257CFD;'>---</span>";
      $key['draw_number']  = "<span style='color:#257CFD;'>---</span>";
      $key['date_created']  = "<span style='color:#257CFD;'>---</span>";

    }
    
    if($draw_date != "null" && $draw_time != "null" && $draw_number != "null" && $client != "null"){
      $style = "rgb(0,174,85,0.1)";
      $info = '<span class="badge badge-sm border border-success text-success bg-success">
      <svg width="9" height="9" viewBox="0 0 10 9" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" class="me-1">
        <path d="M1 4.42857L3.28571 6.71429L9 1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
      </svg> Success </span>';
      
    }
    
    if($draw_date === "null" && $key['drawcountt'] < $lastRowCount){
      $style = "rgb(252,0,62,0.1)";
      $info = '<span class="badge badge-sm border border-danger text-danger bg-danger">
      <b><i class="bx bx-x" style="color:#da1f1f;"></i></b> Missed </span>';
      
      $key['draw_date']  = "<span style='color:red;'>---</span>";
      $key['draw_time']  = "<span style='color:red;'>---</span>";
      $key['draw_number']  = "<span style='color:red;'>---</span>";
      $key['date_created']  = "<span style='color:red;'>---</span>";
    }

    $draw_date = "";
    $draw_time = "";
    $draw_number = "";
    $date_created = "";
    $client = "";
  
    //draw sate
 
    ?>
    <tr style="background-color:<?=$styles?>">
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$info?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['count']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_date']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_time']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_number']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['date_created']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><span class="badge badge-sm border border-secondary text-secondary bg-secondary"><?=$key['get_time']?></span></td> 
    </tr>
    <?php
endforeach;


?>
 </tbody>
</table>


<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.4/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.4/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.4/js/buttons.print.min.js"></script>

<script>
$(document).ready(function() {
    // $('#example').DataTable( {
    //     //dom: 'Bfrtip',
    //     buttons: [
    //         'copy', 'csv', 'excel', 'pdf', 'print'
    //     ]
    // });
});
</script>
