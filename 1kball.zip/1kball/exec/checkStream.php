<?php
ini_set('display_errors',1);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
require_once "../model/games.php";
//Add new game
$checker = new Games;
//$gameid = $_GET['gameid'];
$gameid = $_POST['gameid'];
$checker->IsStreaming($gameid);