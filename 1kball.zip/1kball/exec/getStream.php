<?php
ini_set('display_errors',1);
require_once "../model/games.php";
//Add new game
$checker = new Games;

$gameid = $_POST['gameid'];
$checker->getStream($gameid);