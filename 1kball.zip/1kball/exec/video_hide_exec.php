<?php
session_start();
//ini_set('display_errors', 1);
require_once "../model/games.php";
$gameStater = new Games;
$gameId   = $_POST['gameid'];
$gameState = $_POST['gameState'];
//echo $gameId . " ". $gameState;
$sessionId = "offline";
$gameStater->StopIncognito($gameState,$gameId,$sessionId);