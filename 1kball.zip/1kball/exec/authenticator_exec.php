<?php
//ini_set('display_errors', 1);
session_start();
include "../model/user.php";
$new_user = new User;

$status = $_POST['status'];
$userid = $_SESSION['sessionId'];

$new_user->UpdateAuthen($userid,$status);
