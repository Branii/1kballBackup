<table class="table align-items-center mb-0 table-bordered table-striped">
        <thead class="bg-gray-100">
          <tr>
          <th class="text-center text-xs font-weight-semibold opacity-7">#</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">Info</th>
            <th class="text-center text-xs font-weight-semibold opacity-7">ID</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Date</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Time</th>
            <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Number</th>
            <!-- <th class="text-center text-secondary text-xs font-weight-semibold opacity-7">Draw Count</th> -->
          </tr>
        </thead>
<?php
//check user for login
require_once "../model/draws.php";
$getDraws = new Draws;
$gameid = $_POST['gameid'];
$datetoday = $_POST['datetoday'];

// echo $gameid . " " . $datetoday;
// exit;
$data = $getDraws->FetchSpecificDrawWithDate($gameid,$datetoday);

//just checking
$counter = 0;
foreach ($data as $key):
    $counter++;


    $info = "";
                  if($key['client'] == "box"){
                    //$color = "green";
                    $info = '<span class="badge badge-sm border border-success text-success bg-success">
                    <svg width="9" height="9" viewBox="0 0 10 9" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" class="me-1">
                      <path d="M1 4.42857L3.28571 6.71429L9 1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg> Radom Box </span>';
                  }else{
                    //$color = "orangered";
                    $info = '<span class="badge badge-sm border border-danger text-danger bg-danger">
                    <svg width="12" height="12" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="me-1">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                    </svg> Server </span>';
                  }

    ?>
    
    <tr>
    <td><?=$counter?></td>
      <td><?=$info?></td>
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_count']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_date']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_time']?></td> 
      <td class="text-center text-secondary text-xs font-weight-semibold opacity-9"><?=$key['draw_number']?></td> 
    </tr>
    <?php
endforeach;

?>
 </tbody>
</table>
