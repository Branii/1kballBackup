<?php
ini_set('display_errors', 0);
session_start();
require_once "../model/games.php";
$keyid = addslashes($_POST['keyid']);

// return the result to the view
(new Games)->DeleteStreamKey($keyid);


?>