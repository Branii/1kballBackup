<?php
ini_set('display_errors', 1);
include "../model/user.php";
$new_user = new User;
$email    = $_POST['email'];
$password = $_POST['password'];

$checker = $new_user->Login($email,$password);

// return the result to the view
echo $checker;

