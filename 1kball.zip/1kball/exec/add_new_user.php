<?php
ini_set('display_errors', 1);
require_once "../model/user.php";
//Add new game
$new_user = new User;

$username    = addslashes($_POST['username']);
$email = addslashes($_POST['email']);
$mobile    = addslashes($_POST['mobile']);
$account = addslashes($_POST['account']);
$password = addslashes($_POST['password']);
$oauth = "Off";

// return the result to the view
$new_user->AddNewUser($username,$email,$mobile,$account,$password,$oauth);


?>