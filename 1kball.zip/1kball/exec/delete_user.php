<?php
ini_set('display_errors', 1);
require_once "../model/user.php";
//Add new game
$new_user = new User;

$uid = addslashes($_POST['uid']);

// return the result to the view
$new_user->DeleteUser($uid);


?>