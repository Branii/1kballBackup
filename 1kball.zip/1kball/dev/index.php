<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require "vendor/config.php";
require "HomeController.php";

app()->set404(function () {
    response()->markup("404: Page not found");
});



app()->get("/api/v1/currenttime", "HomeController@getCurrentTime");

#get all draws

app()->get("/api/vi/name", "HomeController@fetch_name");

app()->get("/", "HomeController@fetch_allGames");

app()->get("/api/v1/gamecat", "HomeController@fetch_gameCategory");

#list of all games under each category
app()->get("/api/v1/catgames/1", "HomeController@fetch_catgame1");

app()->get("/api/v1/catgames/2", "HomeController@fetch_catgame2");

app()->get("/api/v1/catgames/3", "HomeController@fetch_catgame3");

app()->get("/api/v1/catgames/4", "HomeController@fetch_catgame4");

app()->get("/api/v1/catgames/5", "HomeController@fetch_catgame5");

app()->get("/api/v1/catgames/6", "HomeController@fetch_catgame6");

app()->get("/api/v1/catgames/7", "HomeController@fetch_catgame7");

app()->get("/api/v1/catgames/8", "HomeController@fetch_catgame8");
#end of all games under each categoroy

#1kball draw endpoint
app()->get("/api/v1/1kball1min", "HomeController@fetch_1kball1min");

app()->get("/api/v1/luckypick5", "HomeController@fetch_luckypick5");

app()->get("/api/v1/speedy1min", "HomeController@fetch_speedy1min");

app()->get("/api/v1/speedy5d", "HomeController@fetch_speedy5d");

app()->get("/api/v1/lucky5d", "HomeController@fetch_lucky5d");

app()->get("/api/v1/fast3", "HomeController@fetch_fast3");

app()->get("/api/v1/speedyfast3", "HomeController@fetch_speedyfast3");

app()->get("/api/v1/luckyfast3", "HomeController@fetch_luckyfast3");

app()->get("/api/v1/1kballpc28", "HomeController@fetch_1kballpc28");

app()->get("/api/v1/speedypc28", "HomeController@fetch_speedypc28");

app()->get("/api/v1/luckypc28", "HomeController@fetch_luckypc28");

app()->get("/api/v1/lucky3d", "HomeController@fetch_lucky3d");

app()->get("/api/v1/speedypk10", "HomeController@fetch_speedypk10");

app()->get("/api/v1/luckypk10", "HomeController@fetch_luckypk10");

app()->get("/api/v1/speedy11x5", "HomeController@fetch_speedy11x5");

app()->get("/api/v1/lucky11x5", "HomeController@fetch_lucky11x5");

app()->get("/api/v1/lucky49x7", "HomeController@fetch_lucky49x7");

app()->get("/api/v1/1kball5d", "HomeController@fetch_1kball5d");

app()->get("/api/v1/luckypk103", "HomeController@fetch_luckypk103");

app()->get("/api/v1/luckykeno", "HomeController@fetch_luckykeno");

app()->get("/api/v1/speedykeno", "HomeController@fetch_speedykeno");

app()->get("/api/v1/superkeno", "HomeController@fetch_superkeno");

app()->get("/api/v1/playkeno", "HomeController@fetch_playkeno");

app()->get("/api/v1/slovakiakeno", "HomeController@fetch_slovakiakeno");

app()->get("/api/v1/greecekeno", "HomeController@fetch_greecekeno");

app()->get("/api/v1/super3", "HomeController@fetch_super3");

app()->get("/api/v1/tronscan", "HomeController@fetch_tronscan");

app()->get("/api/v1/etherscan", "HomeController@fetch_etherscan");

//Get the current draw api
#1kball draw endpoint
app()->get("/api/v1/update/{gameid}",function($gameid){
    $gemeTable = "draw_" . $gameid;

    if($gemeTable =="draw_10026"){

    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10026 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_date'];
      $data['draw_date'] = date("Ymd") . $datas['draw_count'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode($jsonArr);

    }elseif($gemeTable == "draw_10027"){

    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10027 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_date'];
      $data['draw_date'] = date("Ymd") . $datas['draw_count'];
      //$data['draw_date'] = date("Ymd") . substr(preg_replace('/[^0-9]/', '', $datas['draw_date']), 0, 8);
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode($jsonArr);

    }else{

        $result = $GLOBALS['con']->query("SELECT * FROM $gemeTable ORDER BY drawid DESC LIMIT 50")->fetchAll();
        echo json_encode($result);

    }
   
});

//frontend api checker
app()->get("/api/v1/updatechecker/{gameid}",function($gameid){
    $gemeTable = "draw_" . $gameid;
    $result = $GLOBALS['con']->query("SELECT * FROM $gemeTable ORDER BY drawid DESC LIMIT 1")->fetchAll();
    echo json_encode($result);
});

//update api table
app()->get("/api/v1/apiupdate/{gameid}",function($gameid){
    $gemeTable = "draw_" . $gameid;
    $result = $GLOBALS['con']->query("SELECT * FROM $gemeTable ORDER BY draw_date DESC LIMIT 10")->fetchAll();
    $resultx = $GLOBALS['con']->query("SELECT * FROM games WHERE game_id = $gameid")->fetchAll();
    $jsonArr = array();
    $gameName = $resultx[0]["game_name"];
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=>$gameName,"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
});

app()->get("/api/v1/1kball1minLast", "HomeController@fetch_1kball1minLast");

app()->get("/api/v1/luckypick5Last", "HomeController@fetch_luckypick5Last");

app()->get("/api/v1/speedy1minLast", "HomeController@fetch_speedy1minLast");

app()->get("/api/v1/speedy5dLast", "HomeController@fetch_speedy5dLast");

app()->get("/api/v1/lucky5dLast", "HomeController@fetch_lucky5dLast");

app()->get("/api/v1/fsat3Last", "HomeController@fetch_fsat3Last");

app()->get("/api/v1/fast3Last", "HomeController@fetch_fast3Last");

app()->get("/api/v1/luckyfast3Last", "HomeController@fetch_luckyfast3Last");

app()->get("/api/v1/1kballpc28Last", "HomeController@fetch_1kballpc28Last");

app()->get("/api/v1/speedypc28Last", "HomeController@fetch_speedypc28Last");

app()->get("/api/v1/luckypc28Last", "HomeController@fetch_luckypc28Last");

app()->get("/api/v1/lucky3dLast", "HomeController@fetch_lucky3dLast");

app()->get("/api/v1/speedypk10Last", "HomeController@fetch_speedypk10Last");

app()->get("/api/v1/luckypk10Last", "HomeController@fetch_luckypk10Last");

app()->get("/api/v1/luckypk103Last", "HomeController@fetch_luckypk103Last");

app()->get("/api/v1/luckykenoLast", "HomeController@fetch_luckykenoLast");

app()->get("/api/v1/speedy11x5Last", "HomeController@fetch_speedy11x5Last");

app()->get("/api/v1/lucky11x5Last", "HomeController@fetch_lucky11x5Last");

app()->get("/api/v1/lucky49x7Last", "HomeController@fetch_lucky49x7Last");

app()->get("/api/v1/1kball5dLast", "HomeController@fetch_1kball5dLast");

app()->get("/api/v1/tronscanLast", "HomeController@fetch_tronscanLast");

app()->get("/api/v1/tronscanLast", "HomeController@fetch_etherscanLast");

app()->run();

//end of routes
