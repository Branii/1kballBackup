<?php
require __DIR__ . "/vendor/config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
class HomeController {

  public function getCurrentTime() {
    $currentDate = date("Y-m-d");
    $currentTime = date("H:i:s");
    $result = array("currentDate" => $currentDate, "currentTime" => $currentTime);
    echo json_encode($result);
  }

  public function getDate(){
    return date("Y-m-d");
  }

  public function fetch_gameCategory() {
    $result = $GLOBALS['con']->select("game_category","*");
    echo json_encode($result);
  }

  #list of category games 

  public function fetch_catgame1() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"1","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame2() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"2","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame3() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"3","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame4() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"4","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame5() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"5","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame6() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"6","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame7() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"7","command"=>"start"]);
    echo json_encode($result);
  }
  public function fetch_catgame8() {
    $result = $GLOBALS['con']->select("games","*",
    ["category_id"=>"8","command"=>"start"]);
    echo json_encode($result);
  }

  #end list of category games 

  public function fetch_allGames() {
    $result = $GLOBALS['con']->select("games","*",[
      "ORDER"=>[
        "game_id"=>"ASC"
      ]
    ]);
    echo json_encode($result);
  }

  public function fetch_allcategory() {
    $result = $GLOBALS['con']->select("game_category","*");
    echo json_encode($result);
  }

  //game names
  public function fetch_name() {
    $result = $GLOBALS['con']->select("games",
  ["game_name","data_url"]);
    echo json_encode($result);
  }

  // public function fetch_1kball1min() {
  //   $result = $GLOBALS['con']->select("draw_100010",
  //   ["draw_count","draw_date","draw_number","draw_time","date_created","get_time"],["ORDER"=>["draw_date"=>"DESC"]],["LIMIT"=>100]);
  //   echo json_encode($result);
  // }

  public function fetch_1kball1min() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10001 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    echo json_encode($result);
  }

  public function fetch_luckypick5() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10002 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    echo json_encode($result);
  }

  public function fetch_speedy1min() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10003 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    echo json_encode($result);
  }

  public function fetch_speedy5d() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10004 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_lucky5d() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10005 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_fast3() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10006 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_speedyfast3() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10007 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_luckyfast3() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10008 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_1kballpc28() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10009 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_speedypc28() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10010 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_luckypc28() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10011 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_lucky3d() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10012 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_speedypk10() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10013 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_luckypk10() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10014 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_speedy11x5() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10015 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_lucky11x5() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10016 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_lucky49x7() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10017 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_1kball5d() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10018 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_luckykeno() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10019 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_speedykeno() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10020 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_superkeno() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10021 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_playkeno() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10022 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_slovakiakeno() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10023 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_greecekeno() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10024 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_super3() {
    $result = $GLOBALS['con']->query("SELECT * FROM draw_10025 ORDER BY drawid DESC LIMIT 50")->fetchAll();
      echo json_encode($result);
  }

  public function fetch_tronscan() {
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10026 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_date'];
      $data['draw_date'] = date("Ymd") . $datas['draw_count'];
      //$data['draw_date'] = date("Ymd") . substr(preg_replace('/[^0-9]/', '', $datas['draw_date']), 0, 8);
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode($jsonArr);
    // $result = $GLOBALS['con']->query("SELECT * FROM draw_10026 ORDER BY drawid DESC LIMIT 20")->fetchAll();
    //   echo json_encode($result);
  }

  public function fetch_etherscan() {
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10027 ORDER BY drawid DESC LIMIT 50")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_date'];
     
      $data['draw_date'] = date("Ymd") . $datas['draw_count'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode($jsonArr);
    // $result = $GLOBALS['con']->query("SELECT * FROM draw_10027 ORDER BY drawid DESC LIMIT 20")->fetchAll();
    //   echo json_encode($result);
  }

  //------//

  public function fetch_1kball1minLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10001'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10001 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=>  $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_luckypick5Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10002'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10002 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=>  $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_speedy1minLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10003'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10003 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=>  $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_speedy5dLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10004'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10004 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=>  $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_lucky5dLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10005'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10005 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_fsat3Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10006'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10006 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_fast3Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10007'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10007 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_luckyfast3Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10008'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10008 ORDER BY drawid DESC LIMIT 10")->fetchAll();

    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_1kballpc28Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10009'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10009 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_speedypc28Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10010'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10010 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_luckypc28Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10011'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10011 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = trim($datas['draw_number']);
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_lucky3dLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10012'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10012 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_speedypk10Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10013'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10013 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_luckypk10Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10014'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10014 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_speedy11x5Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10015'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10015 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_lucky11x5Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10016'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10016 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_lucky49x7Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10017'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10017 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_1kball5dLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10018'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10018 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_luckypk103Last() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10019'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10019 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_luckykenoLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10020'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10020 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_count'];
      $data['draw_date'] = $datas['draw_date'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_tronscanLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10026'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10026 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_date'];
      $data['draw_date'] = date("Ymd").$datas['draw_count'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }

  public function fetch_etherscanLast() {
    $gameName = $GLOBALS['con']->query("SELECT game_name FROM games WHERE game_id = '10027'")->fetchAll();
    $result = $GLOBALS['con']->query("SELECT draw_count,draw_date,draw_number,draw_time FROM draw_10027 ORDER BY drawid DESC LIMIT 10")->fetchAll();
    $jsonArr = array();
    foreach($result as $datas){
      $data = array();
      $data['draw_count'] = $datas['draw_date'];
      $data['draw_date'] = date("Ymd").$datas['draw_count'];
      $data['draw_time'] = $datas['draw_time'];
      $data['draw_number'] = $datas['draw_number'];
      array_push($jsonArr,$data);
    }
    echo json_encode(array("Game Name"=> $gameName[0][0],"Total Count"=>"10","Today's Date"=> date('Y-m-d'),"Data"=>$jsonArr));
  }
  

}